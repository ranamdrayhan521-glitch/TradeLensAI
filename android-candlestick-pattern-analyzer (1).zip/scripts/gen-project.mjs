// TradeLens AI — Android Studio প্রজেক্ট জেনারেটর
// ওয়েবসাইটের ডেটা (src/data) থেকে প্রকৃত প্রজেক্ট-ফাইল ডিস্কে লেখে।
import { buildSync } from "esbuild";
import { mkdirSync, writeFileSync, rmSync, mkdtempSync } from "fs";
import path from "path";
import os from "os";

const tmp = mkdtempSync(path.join(os.tmpdir(), "tradelens-"));
const outfile = path.join(tmp, "bundle.mjs");

buildSync({
  entryPoints: ["src/data/index.ts"],
  bundle: true,
  format: "esm",
  platform: "node",
  outfile,
});

const { allFiles } = await import("file://" + outfile);

const outRoot = "build_out";
rmSync(outRoot, { recursive: true, force: true });

let count = 0;
for (const f of allFiles) {
  const p = path.join(outRoot, f.path);
  mkdirSync(path.dirname(p), { recursive: true });
  writeFileSync(p, f.code + "\n", "utf8");
  count++;
}

// ── Gradle wrapper properties (jar ছাড়া — Android Studio নিজেই bootstrap করে) ──
mkdirSync(path.join(outRoot, "TradeLensAI/gradle/wrapper"), { recursive: true });
writeFileSync(
  path.join(outRoot, "TradeLensAI/gradle/wrapper/gradle-wrapper.properties"),
  [
    "distributionBase=GRADLE_USER_HOME",
    "distributionPath=wrapper/dists",
    "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.2-bin.zip",
    "networkTimeout=10000",
    "validateDistributionUrl=true",
    "zipStoreBase=GRADLE_USER_HOME",
    "zipStorePath=wrapper/dists",
    "",
  ].join("\n")
);

// ── .gitignore ──
writeFileSync(
  path.join(outRoot, "TradeLensAI/.gitignore"),
  [
    "*.iml",
    ".gradle",
    "/local.properties",
    "/.idea",
    ".DS_Store",
    "/build",
    "/captures",
    ".externalNativeBuild",
    ".cxx",
    "local.properties",
    "",
  ].join("\n")
);
writeFileSync(path.join(outRoot, "TradeLensAI/app/.gitignore"), "/build\n");

// ── READ_ME_FIRST (বাংলা নির্দেশনা) ──
writeFileSync(
  path.join(outRoot, "TradeLensAI/READ_ME_FIRST.txt"),
  [
    "════════════════════════════════════════════════════════════",
    " TradeLens AI — Android Studio প্রজেক্ট (সম্পূর্ণ সোর্স)",
    "════════════════════════════════════════════════════════════",
    "",
    "■ ANDROID STUDIO-তে চালানোর নিয়ম",
    "  ১) ZIP আনজিপ করুন।",
    "  ২) Android Studio → File → Open → এই 'TradeLensAI' ফোল্ডারটি নির্বাচন করুন।",
    "     ('app' ফোল্ডার নয় — পুরো TradeLensAI ফোল্ডার)",
    "  ৩) 'Trust project' চাপলে Gradle Sync শুরু হবে।",
    "     • gradle-wrapper.jar ইচ্ছাকৃতভাবে দেওয়া নেই (টেক্সট-জিপে বাইনারি রাখা নিরাপত্তাজনিত",
    "       কারণে নিষিদ্ধ অনেক সিস্টেমে)। Android Studio প্রথম সিঙ্কেই wrapper ডাউনলোড/",
    "       বুটস্ট্র্যাপ করে নেবে। কোনো প্রম্পটে 'Use Gradle wrapper' সিলেক্ট করে দিন।",
    "  ৪) Sync শেষে ফোন USB-ডিবাগিং/এমুলেটরে Run দিন।",
    "",
    "■ AIDE (মোবাইলে) ব্যবহার করলে",
    "  • AIDE → Open App Project → এই ফোল্ডার নির্বাচন করুন, অথবা ফাইলগুলো নতুন",
    "    প্রজেক্টে কপি করুন। Wrapper-এর দরকার নেই — AIDE নিজের টুলচেইন ব্যবহার করে।",
    "",
    "■ প্রথম রানে",
    "  ১) অ্যাপ খুলে ওভারলে পারমিশন দিন",
    "  ২) নোটিফিকেশন পারমিশন দিন (Android 13+)",
    "  ৩) 'স্ক্যান শুরু করুন' → স্ক্রিন ক্যাপচার পারমিশন দিন",
    "  ৪) ক্যান্ডেল-চার্ট অ্যাপে যান (TradingView ইত্যাদি) — চিপ ও সিগন্যাল দেখা যাবে।",
    "",
    "■ প্রয়োজন",
    "  • JDK 17 (Android Studio Hedgehog+ নিজস্ব JBR 17 নিয়ে আসে)",
    "  • Android SDK 34, minSdk 29 (Android 10+)",
    "",
    "■ আইকন",
    "  • res/drawable/ic_launcher.xml — সম্পূর্ণ ভেক্টর, PNG লাগে না।",
    "",
    "■ মোবাইল থেকে এক-ক্লিকে APK (GitHub Actions)",
    "  ১) github.com-এ ফ্রি অ্যাকাউন্ট → New repository",
    "  ২) এই ফোল্ডারের ভেতরের সব ফাইল রিপোতে আপলোড করুন (মোবাইল ব্রাউজারেই হয়)",
    "  ৩) Actions ট্যাবে 'TradeLens AI — APK Build' স্বয়ংক্রিয় চলবে (~৫–৮ মিনিট)",
    "  ৪) Artifacts → 'TradeLensAI-debug-apk' ডাউনলোড করে ইনস্টল করুন।",
    "     (.github/workflows/android-build.yml ফাইলটি এই কাজটিই করে)",
    "",
    "নোট: সম্পূর্ণ বিশ্লেষণ অন-ডিভাইস; কোনো ডেটা বাইরে পাঠায় না।",
    "শিক্ষামূলক উদ্দেশ্যে তৈরি — ট্রেডিংয়ের ঝুঁকি নিজ দায়িত্বে।",
    "",
  ].join("\n")
);

console.log("OK: " + count + " source files written to " + outRoot + "/TradeLensAI");
