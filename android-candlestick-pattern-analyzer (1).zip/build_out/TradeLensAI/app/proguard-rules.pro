# ProGuard / R8 নিয়ম — এই প্রজেক্টে minify বন্ধ (minifyEnabled false),
# তাই ফাইলটি আগামীর জন্য খালি রাখা নিরাপদ।
# ভবিষ্যতে minify চালু করলে এখানে keep-নিয়ম যোগ করবেন।
