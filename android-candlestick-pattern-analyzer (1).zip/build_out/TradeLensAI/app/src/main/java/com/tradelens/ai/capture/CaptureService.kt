package com.tradelens.ai.capture

import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.OrientationEventListener
import android.view.Surface
import android.view.WindowManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.tradelens.ai.R
import com.tradelens.ai.analysis.AnalysisReport
import com.tradelens.ai.analysis.FrameAnalyzer
import com.tradelens.ai.overlay.OverlayController

/**
 * ════════════════════════════════════════════════════════════════
 *  CaptureService — স্ক্রিন ক্যাপচার + বিশ্লেষণ + ওভারলে সমন্বয়কারী
 * ════════════════════════════════════════════════════════════════
 *
 *  ┌─ আগের প্রজেক্টের স্ক্রিন-ক্যাপচার সমস্যা যেভাবে সমাধান হলো ─┐
 *  │                                                            │
 *  │ ① startForeground() কল করা হলো getMediaProjection() এর    │
 *  │   **আগে** — উল্টোটা করলেই SecurityException               │
 *  │                                                            │
 *  │ ② createVirtualDisplay() এর আগে registerCallback() —       │
 *  │   Android 14 (API 34) এ বাধ্যতামূলক                        │
 *  │                                                            │
 *  │ ③ প্রতিটি Image finally ব্লকে close() — না করলে           │
 *  │   BufferQueue ভরে ৩–৪ ফ্রেম পরেই ক্যাপচার থেমে যায়        │
 *  │                                                            │
 *  │ ④ rowStride padding হ্যান্ডল (FrameProcessor দেখুন)         │
 *  │                                                            │
 *  │ ⑤ স্ক্রিন ঘুরলে VirtualDisplay নতুন করে তৈরি —              │
 *  │   না করলে কালো/হাফ স্ক্রিন আসত                             │
 *  └────────────────────────────────────────────────────────────┘
 *
 *  ডেটা-ফ্লো:
 *  VirtualDisplay → ImageReader → (থ্রোটল) → FrameProcessor
 *      → FrameAnalyzer → OverlayController + Notification
 */
class CaptureService : LifecycleService() {

    companion object {
        private const val TAG = "CaptureService"

        const val ACTION_START = "com.tradelens.ai.START"
        const val ACTION_STOP = "com.tradelens.ai.STOP"
        const val ACTION_TOGGLE = "com.tradelens.ai.TOGGLE"

        @Volatile var isRunning = false; private set
        @Volatile var paused = false; private set

        fun start(context: Context) {
            val i = Intent(context, CaptureService::class.java).setAction(ACTION_START)
            ContextCompat.startForegroundService(context, i)
        }

        fun stop(context: Context) {
            val i = Intent(context, CaptureService::class.java).setAction(ACTION_STOP)
            context.startService(i)
        }

        fun toggle(context: Context) {
            val i = Intent(context, CaptureService::class.java).setAction(ACTION_TOGGLE)
            context.startService(i)
        }
    }

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var notifier: CaptureNotification
    private var overlay: OverlayController? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private var displayWidth = 0
    private var displayHeight = 0
    private var densityDpi = 0

    private var scanIntervalMs = 500L
    private var lastScanAt = 0L
    private var lastStatus = ""

    private val analyzer = FrameAnalyzer()

    // Android 14: projection-এ callback রেজিস্টার করা বাধ্যতামূলক।
    // সিস্টেম/ইউজার ক্যাপচার বন্ধ করলে এখানে খবর আসে।
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.w(TAG, "MediaProjection সিস্টেম থেকে বন্ধ হয়েছে")
            stopCaptureInternal()
        }
    }

    // স্ক্রিন ঘুরলে (portrait ↔ landscape) VirtualDisplay পুনর্নির্মাণ
    private val orientationListener by lazy {
        object : OrientationEventListener(this) {
            private var lastRotation = -1
            override fun onOrientationChanged(degrees: Int) {
                val rotation = currentRotation()
                if (lastRotation == -1) { lastRotation = rotation; return }
                if (rotation != lastRotation) {
                    lastRotation = rotation
                    // মেট্রিক্স স্থির হওয়ার জন্য সামান্য অপেক্ষা
                    captureHandler?.postDelayed({ recreateVirtualDisplay() }, 400)
                }
            }
        }
    }

    // ── ImageReader ফ্রেম লিসেনার ────────────────────────────────
    // মনোযোগ: লিসেনার ব্যাকগ্রাউন্ড থ্রেডে চলে — UI সরাসরি ছোঁয়া যাবে না।
    private val frameListener = ImageReader.OnImageAvailableListener { reader ->
        // পজ অবস্থায় ফ্রেম গ্রহণ ও বাতিল (close বাধ্যতামূলক!)
        if (paused) {
            reader.acquireLatestImage()?.close()
            return@OnImageAvailableListener
        }

        // ── থ্রোটলিং: ব্যবহারকারী-নির্ধারিত ইন্টারভালে স্ক্যান ──
        val now = SystemClock.elapsedRealtime()
        if (now - lastScanAt < scanIntervalMs) {
            reader.acquireLatestImage()?.close()
            return@OnImageAvailableListener
        }
        lastScanAt = now

        val image = try {
            reader.acquireLatestImage()
        } catch (t: Throwable) {
            null
        } ?: return@OnImageAvailableListener

        var frame: Bitmap? = null
        try {
            frame = FrameProcessor.toBitmap(image)
        } catch (t: Throwable) {
            Log.e(TAG, "ফ্রেম কনভার্সন ব্যর্থ", t)
        } finally {
            // ★★★ এই close()-ই সবচেয়ে গুরুত্বপূর্ণ লাইন ★★★
            // close না করলে buffer-কিউ ভরে গিয়ে ৩–৪ ফ্রেম পরেই
            // ক্যাপচার চিরদিনের জন্য থেমে যায় — আগের প্রজেক্টের
            // মূল বাগ ছিল এইটা।
            image.close()
        }

        if (frame != null) analyseFrame(frame)
    }

    override fun onCreate() {
        super.onCreate()
        projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        notifier = CaptureNotification(this)
        overlay = OverlayController(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture()
            ACTION_STOP -> {
                stopCaptureInternal()
                stopSelf()
            }
            ACTION_TOGGLE -> togglePause()
        }
        return super.onStartCommand(intent, flags, startId)
    }

    // ═════════════════ ক্যাপচার শুরু — সঠিক ক্রম ════════════════
    private fun startCapture() {
        if (isRunning) return

        // ধাপ ০: টোকেন আছে কিনা দেখি
        val token = ProjectionStore.take()
        if (token == null) {
            notifier.update("পারমিশন টোকেন নেই — অ্যাপ খুলে আবার চেষ্টা করুন")
            stopSelf()
            return
        }

        scanIntervalMs = getSharedPreferences("tradelens", MODE_PRIVATE)
            .getInt("scan_ms", 500).toLong().coerceIn(200L, 3000L)

        try {
            // ধাপ ①: ফোরগ্রাউন্ড ঘোষণা (টাইপসহ) — getMediaProjection এর আগে!
            ServiceCompat.startForeground(
                this,
                CaptureNotification.NOTIF_ID,
                notifier.build(getString(R.string.notif_scanning)),
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                else 0
            )

            // ধাপ ②: আলাদা থ্রেড — ImageReader কলব্যাক এখানে চলবে
            captureThread = HandlerThread("tradelens-capture").apply { start() }
            captureHandler = Handler(captureThread!!.looper)

            // ধাপ ③: এবার টোকেন খরচ করে projection নিই
            mediaProjection = projectionManager.getMediaProjection(token.first, token.second)

            // ধাপ ③·৫: VirtualDisplay বানানোর **আগে** callback রেজিস্টার
            mediaProjection?.registerCallback(projectionCallback, captureHandler)

            // ধাপ ④: স্ক্রিনের প্রকৃত মাপ
            readDisplayMetrics()

            // ধাপ ⑤: ImageReader + VirtualDisplay
            createVirtualDisplaySafely()

            overlay?.attach()
            if (orientationListener.canDetectOrientation()) orientationListener.enable()

            isRunning = true
            paused = false
            notifier.update("চার্ট খোঁজা হচ্ছে — ব্রোকার/চার্ট অ্যাপ খুলুন")
        } catch (t: Throwable) {
            Log.e(TAG, "ক্যাপচার শুরু ব্যর্থ", t)
            notifier.update("ক্যাপচার ব্যর্থ: " + (t.message ?: "অজানা সমস্যা"))
            stopCaptureInternal()
        }
    }

    private fun createVirtualDisplaySafely() {
        releaseDisplayOnly()
        imageReader = ImageReader.newInstance(
            displayWidth, displayHeight, PixelFormat.RGBA_8888, /* maxImages = */ 2
        )
        imageReader!!.setOnImageAvailableListener(frameListener, captureHandler)

        val vd = mediaProjection?.createVirtualDisplay(
            "tradelens",
            displayWidth,
            displayHeight,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            captureHandler
        ) ?: throw IllegalStateException("VirtualDisplay তৈরি হয়নি")
        virtualDisplay = vd
    }

    private fun recreateVirtualDisplay() {
        if (!isRunning) return
        Log.i(TAG, "ওরিয়েন্টেশন বদলেছে — VirtualDisplay পুনর্নির্মাণ")
        readDisplayMetrics()
        try {
            createVirtualDisplaySafely()
        } catch (t: Throwable) {
            Log.e(TAG, "পুনর্নির্মাণ ব্যর্থ", t)
        }
    }

    private fun releaseDisplayOnly() {
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        try { imageReader?.close() } catch (_: Throwable) {}
        virtualDisplay = null
        imageReader = null
    }

    // ═════════════════ ফ্রেম বিশ্লেষণ ════════════════════════════
    private fun analyseFrame(frame: Bitmap) {
        val report = try {
            analyzer.analyze(frame)
        } catch (t: Throwable) {
            Log.e(TAG, "অ্যানালাইসিস ব্যর্থ", t)
            null
        } finally {
            // বড় bitmap — সাথে সাথে মেমরি ছেড়ে দিই
            frame.recycle()
        } ?: return

        // ফলাফল ওভারলেতে (OverlayController নিজেই মেইন-থ্রেডে নিয়ে যায়)
        overlay?.update(report)

        // নোটিফিকেশন শুধু স্ট্যাটাস বদলালে আপডেট — স্প্যাম নয়
        val status = statusText(report)
        if (status != lastStatus) {
            lastStatus = status
            notifier.update(status)
        }
    }

    private fun statusText(report: AnalysisReport): String {
        return when (report.status) {
            AnalysisReport.Status.NO_CHART ->
                "চার্ট পাওয়া যায়নি — ক্যান্ডেল চার্ট স্ক্রিনে আনুন"
            AnalysisReport.Status.TOO_FEW_CANDLES ->
                "ক্যান্ডেল খুব কম — চার্ট জুম-আউট করুন (অন্তত ৮টি দরকার)"
            AnalysisReport.Status.FOUND -> {
                val r = report.result
                if (r == null)
                    "" + report.candleCount + " ক্যান্ডেল স্ক্যানড — কোনো প্যাটার্ন নেই (NEUTRAL)"
                else
                    r.patternNameBn + " • " + r.confidence + "% • " + r.signal.labelBn
            }
        }
    }

    private fun togglePause() {
        paused = !paused
        overlay?.setPaused(paused)
        notifier.update(if (paused) "বিরতি — চিপে ট্যাপ করলে চালু হবে" else lastStatus.ifEmpty { "চার্ট খোঁজা হচ্ছে…" })
    }

    // ═════════════════ বন্ধকরণ — সম্পূর্ণ ক্লিনআপ ═══════════════
    private fun stopCaptureInternal() {
        isRunning = false
        paused = false
        lastStatus = ""

        try { orientationListener.disable() } catch (_: Throwable) {}
        overlay?.detach()

        releaseDisplayOnly()

        try { mediaProjection?.unregisterCallback(projectionCallback) } catch (_: Throwable) {}
        try { mediaProjection?.stop() } catch (_: Throwable) {}
        mediaProjection = null

        captureThread?.quitSafely()
        captureThread = null
        captureHandler = null

        ProjectionStore.clear()

        // নোটিফিকেশনও সরিয়ে দিই
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }

    override fun onDestroy() {
        stopCaptureInternal()
        super.onDestroy()
    }

    // ── ডিসপ্লে মাপ (API 29 ও ৩০+ দুই পথেই সঠিক) ────────────────
    private fun readDisplayMetrics() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            displayWidth = bounds.width()
            displayHeight = bounds.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            displayWidth = dm.widthPixels
            displayHeight = dm.heightPixels
        }
        densityDpi = resources.displayMetrics.densityDpi
    }

    private fun currentRotation(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            display?.rotation ?: Surface.ROTATION_0
        } else {
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
        }
    }
}

/**
 * ════════════════════════════════════════════════════════════════
 *  ProjectionStore — এই ফাইলেরই অংশ (আলাদা ফাইল লাগবে না)
 * ════════════════════════════════════════════════════════════════
 *
 * MediaProjection পারমিশনের রেজাল্ট Intent হলো একবার-ব্যবহারযোগ্য
 * "টোকেন" (এতে IBinder থাকে)। এটিকে Intent-extra হিসেবে parcel
 * করে সার্ভিসে পাঠালে অনেক ডিভাইসে টোকেনটি অকেজো হয়ে যায় —
 * তাই প্রসেস-লেভেলের এই static হোল্ডারটি প্রচলিত নিরাপদ পদ্ধতি।
 *
 * MainActivity → ProjectionStore.save(resultCode, data)
 * CaptureService → ProjectionStore.take()
 */
object ProjectionStore {
    private var resultCode: Int = 0
    private var data: Intent? = null

    fun save(code: Int, intent: Intent) {
        resultCode = code
        data = intent
    }

    fun take(): Pair<Int, Intent>? {
        val d = data ?: return null
        return resultCode to d
    }

    fun clear() {
        data = null
        resultCode = 0
    }
}
