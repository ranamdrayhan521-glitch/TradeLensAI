package com.tradelens.ai.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.tradelens.ai.analysis.AnalysisReport
import com.tradelens.ai.capture.CaptureService
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * ওভারলে ম্যানেজার — CaptureService নিজেই এটি ঘড়িয়ে রাখে।
 *
 * দুটি উইন্ডো:
 *   ① SignalLayer (OverlayView) — MATCH_PARENT, তবে FLAG_NOT_TOUCHABLE:
 *      প্যাটার্ন-বক্স/লেবেল আঁকে, কিন্তু স্পর্শ নিচের চার্ট অ্যাপে চলে যায়।
 *      আপনার ট্রেডিং-এ কোনো বাধা নেই।
 *   ② FloatingChip — ছোট ভাসমান স্ট্যাটাস-চিপ: টেনে সরান, ট্যাপে pause/resume।
 *
 * আলাদা OverlayService রাখিনি ইচ্ছাকৃতভাবে — Android 14-এ ব্যাকগ্রাউণ্ড
 * সার্ভিস থেকে উইন্ডো-আপডেট সীমাবদ্ধ; এক সার্ভিসেই সব নির্ভরযোগ্য।
 */
class OverlayController(private val service: Service) {

    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var layer: OverlayView? = null
    private var chip: View? = null
    private var chipText: TextView? = null
    private var chipDot: View? = null

    fun attach() {
        main.post {
            if (layer != null) return@post
            addSignalLayer()
            addChip()
        }
    }

    // ── ① পূর্ণ-স্ক্রিন, স্পর্শ-পাসথ্রু সিগন্যাল লেয়ার ──────────
    private fun addSignalLayer() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // NOT_TOUCHABLE ⇒ আঙুল বিনা-বাধায় নিচের অ্যাপে যায়
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        val view = OverlayView(service)
        layer = view
        wm.addView(view, params)
    }

    // ── ② টান-যোগ্য ভাসমান চিপ ──────────────────────────────────
    private fun addChip() {
        val dotBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#8CA3BC"))
        }
        val dot = View(service).apply {
            background = dotBg
            layoutParams = LinearLayout.LayoutParams(dp(9), dp(9)).apply {
                setMargins(0, 0, dp(7), 0)
            }
        }
        val tv = TextView(service).apply {
            textSize = 12.5f
            setTextColor(Color.parseColor("#D7E3F0"))
            text = "প্রস্তুত"
        }
        val capsule = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(Color.parseColor("#EB0B1119"))
            setStroke(dp(1), Color.parseColor("#331ED18A"))
        }
        val row = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(14), dp(8))
            background = capsule
            addView(dot)
            addView(tv)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(120)
        }

        // টানা + ট্যাপ শনাক্তকরণ
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        row.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX; downRawY = ev.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX
                    val dy = ev.rawY - downRawY
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        params.x = startX + dx.roundToInt()
                        params.y = startY + dy.roundToInt()
                        try { wm.updateViewLayout(row, params) } catch (_: Throwable) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) CaptureService.toggle(service) // ট্যাপ = pause/resume
                    true
                }
                else -> false
            }
        }

        chip = row
        chipText = tv
        chipDot = dot
        wm.addView(row, params)
    }

    // ── বিশ্লেষণ-ফল প্রতিফলন (যে থ্রেড থেকেই ডাকা নিরাপদ) ────────
    fun update(report: AnalysisReport) {
        main.post {
            layer?.setReport(report)
            val tv = chipText ?: return@post
            when (report.status) {
                AnalysisReport.Status.NO_CHART -> {
                    tv.text = "চার্ট খুঁজছি…"
                    setDot("#8CA3BC")
                }
                AnalysisReport.Status.TOO_FEW_CANDLES -> {
                    tv.text = "ক্যান্ডেল কম — জুম-আউট করুন"
                    setDot("#F5B74C")
                }
                AnalysisReport.Status.FOUND -> {
                    val r = report.result
                    if (r == null) {
                        tv.text = "" + report.candleCount + " ক্যান্ডেল • NEUTRAL"
                        setDot("#4FD8FF")
                    } else {
                        tv.text = r.patternNameBn + " " + r.confidence + "%"
                        setDot(
                            when {
                                r.signal.strength > 0 -> "#1ED18A"
                                r.signal.strength < 0 -> "#FF5C6C"
                                else -> "#F5B74C"
                            }
                        )
                    }
                }
            }
        }
    }

    fun setPaused(pausedNow: Boolean) {
        main.post {
            layer?.setPaused(pausedNow)
            chipText?.text = if (pausedNow) "বিরতি — ট্যাপে চালু" else "চার্ট খুঁজছি…"
            setDot(if (pausedNow) "#8CA3BC" else "#1ED18A")
        }
    }

    fun detach() {
        main.post {
            layer?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
            chip?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
            layer = null; chip = null; chipText = null; chipDot = null
        }
    }

    private fun setDot(hex: String) {
        (chipDot?.background as? GradientDrawable)?.setColor(Color.parseColor(hex))
    }

    private fun dp(v: Int): Int = (v * service.resources.displayMetrics.density).roundToInt()
}
