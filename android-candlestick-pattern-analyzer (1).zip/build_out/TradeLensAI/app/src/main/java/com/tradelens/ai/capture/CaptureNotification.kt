package com.tradelens.ai.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.tradelens.ai.R

/**
 * ফোরগ্রাউন্ড-সার্ভিসের সঙ্গী নোটিফিকেশন।
 * Android-এর নিয়ম: ফোরগ্রাউন্ড সার্ভিস চালুর প্রথম ~৫ সেকেন্ডের
 * মধ্যে startForeground() কল করে দৃশ্যমান নোটিফিকেশন দিতেই হবে,
 * নাহলে সিস্টেম সার্ভিসটি হত্যা করে (এবং Android 14+ এ ক্র্যাশ)।
 */
class CaptureNotification(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "capture_status"
        const val NOTIF_ID = 41
    }

    init {
        // Android 8 (API 26)+ এ চ্যানেল প্রথমে বানাতে হয়
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW   // শব্দ/কম্পন ছাড়া
            ).apply {
                description = context.getString(R.string.channel_desc)
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    fun build(status: String): Notification {
        // নোটিফিকেশনের "বন্ধ করুন" অ্যাকশন
        val stopPending = PendingIntent.getService(
            context,
            0,
            Intent(context, CaptureService::class.java).setAction(CaptureService.ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass) // চাইলে নিজের আইকন দিন
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(status)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, context.getString(R.string.notif_stop), stopPending)
            .build()
    }

    fun update(status: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, build(status))
    }
}
