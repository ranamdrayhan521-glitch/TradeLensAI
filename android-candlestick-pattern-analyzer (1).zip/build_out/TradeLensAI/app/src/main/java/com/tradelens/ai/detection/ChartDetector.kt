package com.tradelens.ai.detection

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect

/**
 * ডাউনস্কেল করা ফ্রেমের পিক্সেল-শ্রেণিবিন্যাস ম্যাপ।
 *   grid[y * width + x] : 0 = ব্যাকগ্রাউন্ড, 1 = বুলিশ, 2 = বিয়ারিশ
 */
class FrameMask(
    val width: Int,
    val height: Int,
    val scaleToScreen: Float,       // small-কোঅর্ডিনেট × এটি = স্ক্রিন-পিক্সেল
    val grid: ByteArray,
    val bounds: Rect,               // চার্ট-এলাকা (small কোঅর্ডিনেটে)
    val bullColor: Int,             // শনাক্ত হওয়া গড় বুলিশ রঙ (ARGB)
    val bearColor: Int
) {
    fun cls(x: Int, y: Int): Byte = grid[y * width + x]
}

/**
 * চার্ট-ডিটেক্টর — কোনো নেটিভ লাইব্রেরি ছাড়া, নিখুঁত Android-Kotlin।
 *
 * পদ্ধতি (প্রতি স্ক্যানে ~৪০–৯০ মি.সে.):
 *   ১) ফ্রেমকে ৪০০px চওড়া ছোট কপিতে নামাই (গতি + শব্দ কমে)
 *   ২) প্রতিটি পিক্সেলকে hue-পরিসর দেখে শ্রেণিবদ্ধ করি
 *      — সবুজ/টিল/সাদা = বুলিশ, লাল/ম্যাজেন্টা = বিয়ারিশ
 *   ৩) কলাম-ঘনত্ব → বাম/ডান সীমানা; রো-ঘনত্ব → উপর/নিচ সীমানা
 *   ৪) যথেষ্ট ক্যান্ডেল-পিক্সেল না পেলে null — সৎভাবে "চার্ট নেই" বলি
 *
 * পোর্টফোলিও/বাটন/টেক্সট আটকে যায় কারণ সেগুলোতে ক্যান্ডেল-রঙের
 * ঘন ব্লক থাকে না — ঘনত্ব-থ্রেশহোল্ড সেগুলো বাদ দিয়ে দেয়।
 */
object ChartDetector {

    const val SMALL_WIDTH = 400
    const val CLS_NONE: Byte = 0
    const val CLS_BULL: Byte = 1
    const val CLS_BEAR: Byte = 2

    fun buildMask(frame: Bitmap): FrameMask? {
        val w = SMALL_WIDTH
        val h = ((frame.height * w.toFloat() / frame.width).toInt()).coerceAtLeast(1)
        val scaleToScreen = frame.width.toFloat() / w

        val small = Bitmap.createScaledBitmap(frame, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        small.recycle()

        val grid = ByteArray(w * h)
        val colScore = IntArray(w)
        val rowScore = IntArray(h)
        var bullCount = 0
        var bearCount = 0
        var br = 0L; var bg = 0L; var bb = 0L
        var rr = 0L; var rg = 0L; var rb = 0L

        var i = 0
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = px[i]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val cls = classify(r, g, b)
                grid[i] = cls
                if (cls != CLS_NONE) {
                    colScore[x]++
                    rowScore[y]++
                    if (cls == CLS_BULL) { bullCount++; br += r; bg += g; bb += b }
                    else { bearCount++; rr += r; rg += g; rb += b }
                }
                i++
            }
        }

        // ক্যান্ডেল-পিক্সেলই যথেষ্ট নেই = স্ক্রিনে চার্ট নেই
        if (bullCount + bearCount < 280) return null

        // ── বাম-ডান সীমা (কলাম ঘনত্ব) ───────────────────────────
        val colThresh = (h * 0.012f).toInt().coerceAtLeast(2)
        var left = 0
        while (left < w && colScore[left] < colThresh) left++
        var right = w - 1
        while (right > left && colScore[right] < colThresh) right--
        // চার্ট অন্তত স্ক্রিনের ৩৫% চওড়া হতে হবে
        if ((right - left) < (w * 0.35f)) return null

        // ── উপর-নিচ সীমা (রো ঘনত্ব) ────────────────────────────
        val rowThresh = ((right - left) * 0.012f).toInt().coerceAtLeast(1)
        var top = 0
        while (top < h && rowScore[top] < rowThresh) top++
        var bottom = h - 1
        while (bottom > top && rowScore[bottom] < rowThresh) bottom--
        if ((bottom - top) < (h * 0.2f)) return null

        val bullColor = if (bullCount > 0)
            Color.rgb((br / bullCount).toInt(), (bg / bullCount).toInt(), (bb / bullCount).toInt())
        else Color.rgb(38, 166, 154)
        val bearColor = if (bearCount > 0)
            Color.rgb((rr / bearCount).toInt(), (rg / bearCount).toInt(), (rb / bearCount).toInt())
        else Color.rgb(239, 83, 80)

        return FrameMask(w, h, scaleToScreen, grid, Rect(left, top, right, bottom), bullColor, bearColor)
    }

    /**
     * RGB → দ্রুত hue-ভিত্তিক শ্রেণিবিন্যাস।
     * Color.RGBToHSV না ডেকে ইনলাইন গণনা — প্রতি ফ্রেমে লক্ষাধিক
     * কলে অ্যালোকেশন-চাপ এড়াই।
     */
    fun classify(r: Int, g: Int, b: Int): Byte {
        val mx = maxOf(r, maxOf(g, b))
        val mn = minOf(r, minOf(g, b))
        val d = (mx - mn).toFloat()

        // স্যাচুরেশন প্রায় শূন্য → ধূসর/সাদা
        if (d < 40f) {
            // উজ্জ্বল সাদা ক্যান্ডেল (কিছু থিমে বুলিশ = সাদা)
            if (r > 200 && g > 200 && b > 200) return CLS_BULL
            return CLS_NONE
        }
        if (mx < 70) return CLS_NONE      // খুব গাঢ় — ব্যাকগ্রাউন্ড

        val h6 = when (mx) {
            r -> ((g - b) / d) % 6f
            g -> (b - r) / d + 2f
            else -> (r - g) / d + 4f
        }
        val hue = (if (h6 < 0) h6 + 6f else h6) * 60f
        val sat = d / mx
        if (sat < 0.34f) return CLS_NONE

        return when {
            hue in 75f..190f -> CLS_BULL                 // সবুজ / টিল
            hue in 195f..255f && g >= b -> CLS_BULL      // সায়ান-নীল বুলিশ থিম
            hue <= 26f || hue >= 330f -> CLS_BEAR        // লাল / গভীর গোলাপি
            hue in 255f..315f -> CLS_BEAR                // ম্যাজেন্টা বিয়ারিশ থিম
            else -> CLS_NONE
        }
    }
}
