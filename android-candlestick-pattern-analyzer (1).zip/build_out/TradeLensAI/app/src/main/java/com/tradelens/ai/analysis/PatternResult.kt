package com.tradelens.ai.analysis

/**
 * ট্রেডিং সংকেত — ৫ স্তর।
 * strength স্বাক্ষরিত: +2 শক্তিশালী ক্রয় … −2 শক্তিশালী বিক্রয়।
 */
enum class Signal(val labelBn: String, val strength: Int) {
    STRONG_BUY("শক্তিশালী ক্রয়", 2),
    BUY("ক্রয়", 1),
    NEUTRAL("অপেক্ষা করুন", 0),
    SELL("বিক্রয়", -1),
    STRONG_SELL("শক্তিশালী বিক্রয়", -2)
}

/**
 * একটি শনাক্ত হওয়া প্যাটার্নের সম্পূর্ণ ফলাফল।
 * confidence = ০–১০০ — জ্যামিতিক মিল, প্রবণতা-প্রেক্ষাপট ও
 * ক্যান্ডেল-আকারের ওজন মিলিয়ে গণনা করা।
 */
data class PatternResult(
    val patternName: String,     // ইংরেজি নাম (Bullish Engulfing)
    val patternNameBn: String,   // বাংলা নাম (বুলিশ এনগালফিং)
    val signal: Signal,          // দিকনির্দেশনা
    val confidence: Int,         // 0..100
    val candleCount: Int,        // প্যাটার্নে জড়িত ক্যান্ডেল-সংখ্যা
    val descriptionBn: String,   // এক লাইনে ব্যাখ্যা
    val quality: Float           // আদর্শ আকৃতির সাথে মিল (0..1)
)
