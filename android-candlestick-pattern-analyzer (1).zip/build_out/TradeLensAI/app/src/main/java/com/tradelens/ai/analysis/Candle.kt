package com.tradelens.ai.analysis

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** ক্যান্ডেলের দিক */
enum class Direction { BULLISH, BEARISH, NEUTRAL }

/**
 * একটি ক্যান্ডেলের সম্পূর্ণ জ্যামিতিক তথ্য।
 *
 * মানগুলো "চার্ট-ইউনিট" — অর্থাৎ আসল টাকার দাম নয়, চিত্রের
 * উচ্চতা-ভিত্তিক মান। প্যাটার্ন শনাক্তকরণে নমুনার অনুপাতই
 * (বডি বনাম উইক বনাম রেঞ্জ) গুরুত্বপূর্ণ, দাম নয় — তাই এই
 * পদ্ধতি যে কোনো ব্রোকার, যে কোনো টাইমফ্রেমে সমান সঠিক।
 *
 * শর্ত: high ≥ low সবসময়; open/close এর মধ্যে থাকে।
 */
data class Candle(
    val index: Int,          // তালিকার অবস্থান (শেষ উপাদান = সর্বশেষ ক্যান্ডেল)
    val open: Float,
    val high: Float,
    val low: Float,
    val close: Float,
    val direction: Direction
) {
    /** বডির আকার */
    val body: Float get() = abs(close - open)

    /** উইকসহ পূর্ণ উচ্চতা */
    val range: Float get() = high - low

    /** উপরের উইক */
    val upperWick: Float get() = high - max(open, close)

    /** নিচের উইক */
    val lowerWick: Float get() = min(open, close) - low

    /** বডির উপর/নিচ/মাঝ প্রান্ত (দিক-নির্বিশেষে) */
    val bodyHigh: Float get() = max(open, close)
    val bodyLow: Float get() = min(open, close)
    val bodyMid: Float get() = (open + close) / 2f

    val isBullish: Boolean get() = direction == Direction.BULLISH
    val isBearish: Boolean get() = direction == Direction.BEARISH

    /** বডি রেঞ্জের কত অংশ (0..1) — দোজি = ~0, মারুবোজু = ~1 */
    val bodyRatio: Float get() = if (range <= 0f) 0f else body / range
    val upperWickRatio: Float get() = if (range <= 0f) 0f else upperWick / range
    val lowerWickRatio: Float get() = if (range <= 0f) 0f else lowerWick / range
}
