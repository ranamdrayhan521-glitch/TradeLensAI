package com.tradelens.ai.detection

import kotlin.math.max
import kotlin.math.min

/**
 * একটি শনাক্ত হওয়া ক্যান্ডেলের পিক্সেল-জ্যামিতি (small কোঅর্ডিনেটে)।
 *   top/bottom  → উইকসহ পূর্ণ উচ্চতা
 *   bodyTop/bodyBottom → শুধু বডি
 */
data class CandleBox(
    val left: Int,
    val right: Int,
    val top: Int,
    val bottom: Int,
    val bodyTop: Int,
    val bodyBottom: Int,
    val cls: Byte          // CLS_BULL / CLS_BEAR / CLS_NONE (দোজি-জাতীয়)
) {
    val width: Int get() = right - left + 1
    val centerX: Float get() = (left + right) / 2f
}

/**
 * ক্যান্ডেল-এক্সট্রাক্টর — মাস্ক থেকে আলাদা আলাদা ক্যান্ডেল।
 *
 * ধাপ:
 *   ১) প্রতি কলামে সর্বোচ্চ/সর্বনিম্ন ক্যান্ডেল-পিক্সেল (উইক-সীমা)
 *   ২) ফাঁকা/খুব পাতলা কলাম সহ্য করে কলাম-গ্রুপ → ক্যান্ডেল বক্স
 *   ৩) পিক্সেল-গণনায় দিক: সবুজ সংখ্যাগরিষ্ঠ = বুলিশ, লাল = বিয়ারিশ,
 *      টাই হলে (দোজি) → CLS_NONE — ভুল অনুমান নয়, সৎ শ্রেণি
 *   ৪) বডি শনাক্ত: যেসব রো-তে বক্সের ≥৫৫% কলাম ভরা — সেগুলোর সীমা
 *   ৫) ৬টির কম ক্যান্ডেল পেলে null — অপ্রমাণিত বিশ্লেষণ দিই না
 */
object CandleExtractor {

    private const val MAX_CANDLES = 36
    private const val COLUMN_GAP_TOLERANCE = 1
    private const val BODY_ROW_COVERAGE = 0.55f

    fun extract(mask: FrameMask): List<CandleBox>? {
        val b = mask.bounds

        // ── ধাপ ১: কলাম-ভিত্তিক উইক-সীমা ────────────────────────
        val topSpan = IntArray(mask.width) { -1 }
        val bottomSpan = IntArray(mask.width) { -1 }
        for (x in b.left..b.right) {
            var t = -1
            var bot = -1
            for (y in b.top..b.bottom) {
                if (mask.cls(x, y) != ChartDetector.CLS_NONE) {
                    if (t == -1) t = y
                    bot = y
                }
            }
            topSpan[x] = t
            bottomSpan[x] = bot
        }

        // ── ধাপ ২: কলাম-গ্রুপিং → ক্যান্ডেল বক্স ────────────────
        val boxes = ArrayList<CandleBox>()
        var x = b.left
        while (x <= b.right) {
            if (topSpan[x] == -1) { x++; continue }

            val start = x
            var end = x
            var gap = 0
            var cx = x + 1
            while (cx <= b.right) {
                if (topSpan[cx] != -1) { end = cx; gap = 0 }
                else { gap++; if (gap > COLUMN_GAP_TOLERANCE) break }
                cx++
            }

            val bw = end - start + 1
            if (bw >= 2) {
                var top = Int.MAX_VALUE
                var bottom = Int.MIN_VALUE
                var bull = 0
                var bear = 0
                for (col in start..end) {
                    if (topSpan[col] == -1) continue
                    top = min(top, topSpan[col])
                    bottom = max(bottom, bottomSpan[col])
                    for (y in topSpan[col]..bottomSpan[col]) {
                        when (mask.cls(col, y)) {
                            ChartDetector.CLS_BULL -> bull++
                            ChartDetector.CLS_BEAR -> bear++
                        }
                    }
                }

                if (bottom - top >= 2) {
                    // ── ধাপ ৩: দিক নির্ধারণ ─────────────────────
                    val cls = when {
                        bull > bear * 1.15f -> ChartDetector.CLS_BULL
                        bear > bull * 1.15f -> ChartDetector.CLS_BEAR
                        else -> ChartDetector.CLS_NONE     // টাই = দোজি-ধর্মী
                    }
                    // ── ধাপ ৪: বডি-সীমা ─────────────────────────
                    val bodyTop = bodyEdge(mask, start, end, top, bottom, true)
                    val bodyBottom = bodyEdge(mask, start, end, top, bottom, false)
                    boxes.add(CandleBox(start, end, top, bottom, bodyTop, bodyBottom, cls))
                }
            }
            x = cx
        }

        // ── ধাপ ৫: নির্ভরযোগ্যতা-গেট ────────────────────────────
        if (boxes.size < 6) return null
        return if (boxes.size > MAX_CANDLES)
            boxes.subList(boxes.size - MAX_CANDLES, boxes.size)
        else boxes
    }

    /**
     * বডির উপর/নিচ সীমা: যে রো থেকে বক্সের ≥৫৫% কলামে রঙ পাওয়া যায়
     * সেটিই বডির প্রান্ত — কারণ উইক-রোতে মাঝের ১–২ কলামে মাত্র রঙ থাকে।
     */
    private fun bodyEdge(
        mask: FrameMask,
        start: Int, end: Int,
        top: Int, bottom: Int,
        fromTop: Boolean
    ): Int {
        val need = ((end - start + 1) * BODY_ROW_COVERAGE).toInt().coerceAtLeast(1)
        val height = (bottom - top).coerceAtLeast(1)

        if (fromTop) {
            for (y in top..bottom) {
                var filled = 0
                for (col in start..end) if (mask.cls(col, y) != ChartDetector.CLS_NONE) filled++
                if (filled >= need) return y
            }
            return top + height / 4
        } else {
            for (y in bottom downTo top) {
                var filled = 0
                for (col in start..end) if (mask.cls(col, y) != ChartDetector.CLS_NONE) filled++
                if (filled >= need) return y
            }
            return bottom - height / 4
        }
    }
}
