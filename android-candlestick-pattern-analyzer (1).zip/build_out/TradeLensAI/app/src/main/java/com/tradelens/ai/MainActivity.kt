package com.tradelens.ai

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.content.Intent
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.tradelens.ai.capture.CaptureService
import com.tradelens.ai.capture.ProjectionStore

/**
 * TradeLens AI — মূল স্ক্রিন।
 *
 * দায়িত্ব:
 *   ১) ওভারলে পারমিশন (SYSTEM_ALERT_WINDOW) নেওয়া
 *   ২) নোটিফিকেশন পারমিশন (Android 13+) নেওয়া
 *   ৩) স্ক্যান শুরুতে MediaProjection পারমিশন লঞ্চ করা
 *   ৪) রেজাল্ট-টোকেন ProjectionStore-এ জমা দিয়ে সার্ভিস চালু করা
 *
 * ★ গুরুত্বপূর্ণ: MediaProjection পারমিশনের Intent একটি
 * "একবার-ব্যবহারযোগ্য টোকেন"। প্রতিবার স্ক্যান শুরুতে নতুন করে
 * createScreenCaptureIntent() দেখাতেই হবে — পুরনো টোকেন
 * পুনর্ব্যবহার করলে Android 14+ এ ক্যাপচার নীরবে ব্যর্থ হয়।
 * (আগের প্রজেক্টের সমস্যাটা ঠিক এখানেই ছিল।)
 */
class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("tradelens", MODE_PRIVATE) }

    private lateinit var tvOverlayStatus: TextView
    private lateinit var tvNotifStatus: TextView
    private lateinit var tvInterval: TextView
    private lateinit var tvEngineStatus: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnNotif: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var seekInterval: SeekBar

    // ── নোটিফিকেশন পারমিশন (Android 13+) ──────────────────────
    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            refreshUi()
        }

    // ── MediaProjection পারমিশন ────────────────────────────────
    // onActivityResult ডিপ্রিকেটেড — Activity Result API ব্যবহার করি।
    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                // টোকেনটি Intent আকারে সার্ভিসে পাঠালে parcel-এ নষ্ট হতে পারে,
                // তাই প্রসেস-লেভেল স্ট্যাটিক হোল্ডারে রাখি — এটি সবচেয়ে
                // নির্ভরযোগ্য ও প্রচলিত পদ্ধতি।
                ProjectionStore.save(result.resultCode, result.data!!)
                CaptureService.start(this)
                toast("স্ক্যান চালু হয়েছে — এবার চার্ট অ্যাপে যান")
            } else {
                toast("স্ক্রিন ক্যাপচার বাতিল করা হয়েছে")
            }
            refreshUi()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        tvNotifStatus = findViewById(R.id.tvNotifStatus)
        tvInterval = findViewById(R.id.tvInterval)
        tvEngineStatus = findViewById(R.id.tvEngineStatus)
        btnOverlay = findViewById(R.id.btnOverlay)
        btnNotif = findViewById(R.id.btnNotif)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        seekInterval = findViewById(R.id.seekInterval)

        // স্ক্যান ইন্টারভাল: ২০০–১৫০০ মি.সে. (কম = দ্রুত, বেশি CPU)
        seekInterval.progress = prefs.getInt("scan_ms", 500) - 200
        updateIntervalLabel(prefs.getInt("scan_ms", 500))
        seekInterval.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val ms = progress + 200
                prefs.edit().putInt("scan_ms", ms).apply()
                updateIntervalLabel(ms)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        btnOverlay.setOnClickListener {
            // ওভারলে পারমিশন Settings থেকে দিতে হয় — runtime-ডায়ালগ নেই
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + packageName)
                )
            )
        }

        btnNotif.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33) {
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        btnStart.setOnClickListener { startScan() }
        btnStop.setOnClickListener {
            CaptureService.stop(this)
            refreshUi()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    // ── স্ক্যান শুরু — এখানেই পারমিশনের সঠিক ক্রম ──────────────
    private fun startScan() {
        if (!Settings.canDrawOverlays(this)) {
            toast("আগে ওভারলে পারমিশন দিন")
            return
        }
        // প্রতিবার একদম নতুন capture-intent তৈরি করি।
        // পুরনো intent/টোকেন save করে রাখলেই আগের মতো ব্যর্থ হতো।
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    private fun updateIntervalLabel(ms: Int) {
        tvInterval.text = "স্ক্যান ইন্টারভাল: " + ms + " ms  (কম = দ্রুত বিশ্লেষণ, বেশি CPU)"
    }

    private fun refreshUi() {
        val overlayOk = Settings.canDrawOverlays(this)
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED

        tvOverlayStatus.text = if (overlayOk)
            "ওভারলে পারমিশন: দেওয়া আছে" else "ওভারলে পারমিশন: দেওয়া হয়নি"
        tvOverlayStatus.setTextColor(if (overlayOk) Color.parseColor("#1ED18A") else Color.parseColor("#FF5C6C"))

        tvNotifStatus.text = if (notifOk)
            "নোটিফিকেশন পারমিশন: দেওয়া আছে" else "নোটিফিকেশন পারমিশন: দেওয়া হয়নি (Android 13+)"
        tvNotifStatus.setTextColor(if (notifOk) Color.parseColor("#1ED18A") else Color.parseColor("#FF5C6C"))

        btnOverlay.isEnabled = !overlayOk
        btnNotif.isEnabled = !notifOk
        btnStart.isEnabled = overlayOk && !CaptureService.isRunning
        btnStop.isEnabled = CaptureService.isRunning

        tvEngineStatus.text = when {
            CaptureService.isRunning && CaptureService.paused ->
                "ইঞ্জিন: বিরতিতে — স্ক্রিনের চিপে ট্যাপ করলে চালু হবে"
            CaptureService.isRunning ->
                "ইঞ্জিন: চলছে — এখন চার্ট/ব্রোকার অ্যাপে যান"
            else -> "ইঞ্জিন: বন্ধ"
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
