package com.tradelens.ai.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.LinearInterpolator
import com.tradelens.ai.analysis.AnalysisReport
import kotlin.math.roundToInt

/**
 * সিগন্যাল-লেয়ারের আসল আঁকিবুঁকি।
 *
 * আঁকা হয়:
 *   • শনাক্ত প্যাটার্নের ক্যান্ডেলগুলো ঘিরে পালসিং বৃত্তাকার বক্স
 *   • বক্সের উপরে ডার্ক-পিলে প্যাটার্নের বাংলা নাম + কনফিডেন্স %
 *   • সংকেত-দিক অনুযায়ী তীর (উপরে = ক্রয়, নিচে = বিক্রয়)
 *   • সর্বশেষ ক্যান্ডেলে উল্লম্ব ড্যাশড লাইন
 *   • নিচে-বামে সামারি ব্যাজ: "সংকেত: শক্তিশালী ক্রয় • ৮৭%"
 *
 * কিছুই ইমেজ নয় — সব Canvas প্রিমিটিভ, তাই ফ্রেম-রেটে কোনো চাপ নেই।
 */
class OverlayView(context: Context) : View(context) {

    private var report: AnalysisReport? = null
    private var paused = false
    private var pulse = 0.85f

    private val boxStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(2.2f)
    }
    private val boxFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val pillBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = dpF(12.5f)
        isFakeBoldText = true
    }
    private val smallText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B9CBDD")
        textSize = dpF(11f)
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1f)
        color = Color.parseColor("#554FD8FF")
        pathEffect = DashPathEffect(floatArrayOf(dpF(7f), dpF(6f)), 0f)
    }

    // মৃদু পালস — ফ্রেম-আপডেট ছাড়াই বক্স "জীবন্ত" লাগে
    private val pulseAnim = ValueAnimator.ofFloat(0.62f, 1f).apply {
        duration = 950
        repeatMode = ValueAnimator.REVERSE
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            pulse = it.animatedValue as Float
            invalidate()
        }
        start()
    }

    fun setReport(r: AnalysisReport) {
        report = r
        invalidate()
    }

    fun setPaused(p: Boolean) {
        paused = p
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val r = report ?: return
        if (paused) return
        if (r.status != AnalysisReport.Status.FOUND) return

        // ── ১) প্যাটার্ন-হাইলাইট বক্সগুলো ────────────────────────
        for (h in r.highlights) {
            val base = h.color
            boxFill.color = withAlpha(base, (26 * pulse).roundToInt() + 8)
            canvas.drawRoundRect(h.rect, dpF(9f), dpF(9f), boxFill)

            boxStroke.color = withAlpha(base, (255 * pulse).roundToInt())
            canvas.drawRoundRect(h.rect, dpF(9f), dpF(9f), boxStroke)

            drawLabel(canvas, h)
            drawArrow(canvas, h)
        }

        // ── ২) সর্বশেষ ক্যান্ডেলের ড্যাশড লাইন ───────────────────
        r.lastCandleX?.let { x ->
            canvas.drawLine(x, dpF(30f), x, height - dpF(30f), dashPaint)
        }

        // ── ৩) সামারি ব্যাজ ─────────────────────────────────────
        drawSummary(canvas, r)
    }

    // বক্সের উপরে ডার্ক-পিলে বাংলা লেবেল
    private fun drawLabel(canvas: Canvas, h: AnalysisReport.Highlight) {
        val label = h.label + "  " + h.confidence + "%"
        textPaint.textSize = dpF(12.5f)
        val tw = textPaint.measureText(label)
        val padH = dpF(10f)
        val pillH = dpF(26f)
        var left = h.rect.left
        if (left + tw + padH * 2 > width) left = width - tw - padH * 2 - dpF(4f)
        if (left < dpF(4f)) left = dpF(4f)
        var top = h.rect.top - pillH - dpF(6f)
        if (top < dpF(6f)) top = h.rect.bottom + dpF(6f)

        pillBg.color = Color.parseColor("#E60B1119")
        canvas.drawRoundRect(left, top, left + tw + padH * 2, top + pillH, pillH / 2, pillH / 2, pillBg)
        boxStroke.color = h.color
        boxStroke.strokeWidth = dpF(1f)
        canvas.drawRoundRect(left, top, left + tw + padH * 2, top + pillH, pillH / 2, pillH / 2, boxStroke)
        boxStroke.strokeWidth = dpF(2.2f)

        canvas.drawText(label, left + padH, top + pillH - dpF(8.5f), textPaint)
    }

    // সংকেত-দিকের তীর
    private fun drawArrow(canvas: Canvas, h: AnalysisReport.Highlight) {
        val size = dpF(9f)
        val cx = h.rect.right - dpF(6f)
        val path = Path()
        boxFill.color = h.color
        if (h.sentiment > 0) {
            val cy = h.rect.bottom + dpF(10f)
            path.moveTo(cx, cy - size)
            path.lineTo(cx - size * 0.75f, cy + size * 0.5f)
            path.lineTo(cx + size * 0.75f, cy + size * 0.5f)
        } else if (h.sentiment < 0) {
            val cy = h.rect.top - dpF(10f)
            path.moveTo(cx, cy + size)
            path.lineTo(cx - size * 0.75f, cy - size * 0.5f)
            path.lineTo(cx + size * 0.75f, cy - size * 0.5f)
        } else return
        path.close()
        canvas.drawPath(path, boxFill)
    }

    private fun drawSummary(canvas: Canvas, r: AnalysisReport) {
        val res = r.result
        val trendTxt = when (r.candleTrend) {
            1 -> "ট্রেন্ড: আপ"; -1 -> "ট্রেন্ড: ডাউন"; else -> "ট্রেন্ড: সাইড"
        }
        val line1 = if (res == null) "সংকেত: NEUTRAL" else "সংকেত: " + res.signal.labelBn + " • " + res.confidence + "%"
        val line2 = "" + r.candleCount + " ক্যান্ডেল • " + trendTxt

        smallText.textSize = dpF(11.5f)
        val w1 = smallText.measureText(line1)
        val w2 = smallText.measureText(line2)
        val bw = maxOf(w1, w2) + dpF(22f)
        val bh = dpF(46f)
        val left = dpF(12f)
        val bottom = height - dpF(52f)

        pillBg.color = Color.parseColor("#D90B1119")
        canvas.drawRoundRect(left, bottom - bh, left + bw, bottom, dpF(10f), dpF(10f), pillBg)

        val accent = when {
            res == null -> Color.parseColor("#8CA3BC")
            res.signal.strength > 0 -> Color.parseColor("#1ED18A")
            res.signal.strength < 0 -> Color.parseColor("#FF5C6C")
            else -> Color.parseColor("#F5B74C")
        }
        boxFill.color = accent
        canvas.drawRoundRect(left, bottom - bh, left + dpF(3.5f), bottom, dpF(2f), dpF(2f), boxFill)

        canvas.drawText(line1, left + dpF(11f), bottom - bh + dpF(18f), smallText)
        canvas.drawText(line2, left + dpF(11f), bottom - bh + dpF(35f), smallText)
    }

    private fun withAlpha(color: Int, alpha: Int): Int {
        return Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
    }

    private fun dpF(v: Float): Float = v * resources.displayMetrics.density

    override fun onDetachedFromWindow() {
        pulseAnim.cancel()
        super.onDetachedFromWindow()
    }
}
