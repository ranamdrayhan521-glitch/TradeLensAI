package com.tradelens.ai.capture

import android.graphics.Bitmap
import android.media.Image

/**
 * ImageReader-এর raw Image → পরিষ্কার Bitmap।
 *
 * ★★ আগের স্ক্রিন-ক্যাপচার সমস্যার মূল কারণ এখানে ★★
 *
 * ImageReader-এর buffer-এ প্রতিটি সারির (row) শেষে অতিরিক্ত
 * padding বাইট থাকে, যাকে বলে rowStride।
 *
 *   rowStride = (প্রকৃত পিক্সেল × pixelStride) + padding
 *
 * padding বাদ না দিয়ে buffer সরাসরি Bitmap-এ ঢাললে ছবি
 * তির্যকভাবে ভেঙে যায় / স্ট্রেচ হয় / একদম কালো আসে।
 *
 * সমাধান: padding-সহ চওড়া Bitmap-এ আগে কপি করি, তারপর
 * অতিরিক্ত অংশ কেটে (crop) আসল Bitmap বের করি। এই দুই লাইনের
 * কৌশলটিই ৯০% "screen capture ভাঙা" সমস্যার নিরাময়।
 */
object FrameProcessor {

    fun toBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            // প্রতি সারিতে কত বাড়তি পিক্সেল-জায়গা আছে
            val rowPadding = rowStride - pixelStride * image.width
            val paddedWidth = image.width + rowPadding / pixelStride

            // ধাপ ১: padding-সহ চওড়া Bitmap-এ buffer কপি
            val padded = Bitmap.createBitmap(
                paddedWidth, image.height, Bitmap.Config.ARGB_8888
            )
            buffer.rewind()
            padded.copyPixelsFromBuffer(buffer)

            // ধাপ ২: বাঁ পাশের আসল অংশ কেটে নিই
            val clean = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            if (clean !== padded) padded.recycle()
            clean
        } catch (t: Throwable) {
            null
        }
    }
}
