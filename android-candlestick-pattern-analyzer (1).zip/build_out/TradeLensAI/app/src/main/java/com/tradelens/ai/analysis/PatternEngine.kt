package com.tradelens.ai.analysis

import kotlin.math.abs

/**
 * ════════════════════════════════════════════════════════════════
 *  PatternEngine — ৪৪টি ক্যান্ডেলস্টিক প্যাটার্ন-নিয়ম
 * ════════════════════════════════════════════════════════════════
 *
 *  নকশা-নীতি:
 *   • সব তুলনা "অনুপাতে" (বডি/রেঞ্জ/উইক) — দাম ও টাইমফ্রেম-নিরপেক্ষ
 *   • প্রতিটি নিয়ম Float? ফেরত দেয়: null = মিলেনি,
 *     0.0–1.0 = আদর্শ আকৃতির সাথে মিলের মান (quality)
 *   • রিভার্সাল-নিয়মগুলোতে প্রবণতা-গেট আছে: হাতুড়ে শুধু ডাউনট্রেন্ডে
 *     অর্থবহ — এটাই ভুয়া সংকেত কমায়
 *   • confidence = 40 + quality×55 (সর্বোচ্চ 97); ৫০-র নিচে বাতিল
 *   • কিছুই মিললে null — অ্যাপ তখন সৎভাবে NEUTRAL দেখায়,
 *     জোর করে প্যাটার্ন বানায় না
 *
 *  শ্রেণিবিন্যাস:
 *   একক ১৩ • দ্বৈত ১৪ • ত্রৈ ১৫ • পাঁচ-ক্যান্ডেল ২ = মোট ৪৪ নিয়ম
 */
class PatternEngine {

    companion object {
        /**
         * প্রবণতা নির্ণয়: প্রাসঙ্গিক ক্যান্ডেলগুলোর বডি-মধ্যবিন্দুর
         * সাম্প্রতিক-বনাম-পুরনো গড়ের পার্থক্য।
         * skip = সাম্প্রতিকতম কতটি বাদ দেবো (প্যাটার্নের নিজের ক্যান্ডেল)।
         * ফেরত: +1 আপট্রেন্ড, -1 ডাউনট্রেন্ড, 0 সাইডওয়েজ।
         */
        fun trendOf(all: List<Candle>, skip: Int, lookback: Int = 6): Int {
            if (all.size < skip + lookback) return 0
            val half = lookback / 2
            var recent = 0f
            var older = 0f
            var rangeSum = 0f
            for (k in 0 until lookback) {
                val c = all[all.size - 1 - skip - k]
                rangeSum += c.range
                if (k < half) recent += c.bodyMid else older += c.bodyMid
            }
            val scale = (rangeSum / lookback).coerceAtLeast(0.0001f)
            val drift = (recent - older) / half
            return when {
                drift > 0.28f * scale -> 1
                drift < -0.28f * scale -> -1
                else -> 0
            }
        }
    }

    /** সাম্প্রতিক ক্যান্ডেল-স্লাইস: c(0)=সর্বশেষ, c(1)=আগেরটি … */
    private class Slice(val all: List<Candle>) {
        private val n = all.size
        fun c(back: Int): Candle = all[n - 1 - back]

        fun avgRange(skip: Int, count: Int = 8): Float {
            var sum = 0f; var cnt = 0; var k = skip
            while (cnt < count && k < n) { sum += c(k).range; k++; cnt++ }
            return if (cnt == 0) 1f else (sum / cnt).coerceAtLeast(0.0001f)
        }

        fun avgBody(skip: Int, count: Int = 8): Float {
            var sum = 0f; var cnt = 0; var k = skip
            while (cnt < count && k < n) { sum += c(k).body; k++; cnt++ }
            return if (cnt == 0) 1f else (sum / cnt).coerceAtLeast(0.0001f)
        }
    }

    private class Rule(
        val nameEn: String,
        val nameBn: String,
        val signal: Signal,
        val candleCount: Int,
        val descBn: String,
        val test: (Slice) -> Float?
    )

    // ── প্রধান এন্ট্রি-পয়েন্ট ──────────────────────────────────
    fun analyze(candles: List<Candle>): PatternResult? {
        if (candles.size < 8) return null
        val slice = Slice(candles)
        var best: PatternResult? = null

        for (rule in rules) {
            // প্যাটার্নের ক্যান্ডেল + প্রেক্ষাপটের অন্তত ৪টি লাগবে
            if (candles.size < rule.candleCount + 4) continue
            val q = try { rule.test(slice) } catch (t: Throwable) { null } ?: continue
            if (q <= 0f) continue

            val conf = (40f + q * 55f).toInt().coerceAtMost(97)
            if (conf < 50) continue

            var sig = rule.signal
            if (conf >= 88) {
                sig = when (sig) {
                    Signal.BUY -> Signal.STRONG_BUY
                    Signal.SELL -> Signal.STRONG_SELL
                    else -> sig
                }
            }
            val result = PatternResult(
                rule.nameEn, rule.nameBn, sig, conf,
                rule.candleCount, rule.descBn, q
            )
            if (best == null || result.confidence > best!!.confidence) best = result
        }
        return best
    }

    // ── ভাগ করা আকৃতি-পরীক্ষক ───────────────────────────────────
    private fun clamp01(v: Float) = v.coerceIn(0f, 1f)

    private fun near(a: Float, b: Float, tol: Float) = abs(a - b) <= tol

    /** হাতুড়ে-আকৃতি: নিচের উইক ≥ ২×বডি, উপরের উইক ছোট */
    private fun hammerShape(c: Candle): Float? {
        if (c.body <= 0.0001f) return null
        if (c.bodyRatio < 0.05f) return null
        if (c.lowerWick < c.body * 2f) return null
        if (c.upperWick > c.body * 0.9f) return null
        val tail = clamp01(((c.lowerWick / c.body) - 2f) / 3f)
        val crown = clamp01(1f - c.upperWick / (c.body * 0.9f))
        return 0.45f + tail * 0.35f + crown * 0.2f
    }

    /** উল্টো-হাতুড়ে আকৃতি: উপরের উইক ≥ ২×বডি, নিচের উইক ছোট */
    private fun invertedHammerShape(c: Candle): Float? {
        if (c.body <= 0.0001f) return null
        if (c.bodyRatio < 0.05f) return null
        if (c.upperWick < c.body * 2f) return null
        if (c.lowerWick > c.body * 0.9f) return null
        val tail = clamp01(((c.upperWick / c.body) - 2f) / 3f)
        val base = clamp01(1f - c.lowerWick / (c.body * 0.9f))
        return 0.45f + tail * 0.35f + base * 0.2f
    }

    // ═══════════════════ ৪৪টি নিয়ম ═════════════════════════════
    private val rules: List<Rule> = listOf(

        // ══ একক ক্যান্ডেল (১৩) ═════════════════════════════════

        Rule("Doji", "দোজি", Signal.NEUTRAL, 1,
            "ক্রেতা-বিক্রেতার পূর্ণ সমতা — সিদ্ধান্তহীনতা; ট্রেন্ড-বদলের সম্ভাবনা।") t@{ s ->
            val c = s.c(0)
            if (c.bodyRatio > 0.08f) return@t null
            if (c.range < s.avgRange(1) * 0.45f) return@t null
            0.55f + (0.08f - c.bodyRatio) / 0.08f * 0.3f
        },

        Rule("Long-Legged Doji", "লং-লেগড দোজি", Signal.NEUTRAL, 1,
            "দুই দিকেই লম্বা উইক — চরম দ্বিধা; প্রায়ই উলটো-টার্নের আগে।") t@{ s ->
            val c = s.c(0)
            if (c.bodyRatio > 0.1f) return@t null
            if (c.upperWickRatio < 0.3f || c.lowerWickRatio < 0.3f) return@t null
            0.6f
        },

        Rule("Dragonfly Doji", "ড্রাগনফ্লাই দোজি", Signal.BUY, 1,
            "দাম নিচে নেমে পুরো ফিরে এসেছে — বিক্রেতারা হারিয়েছে (ডাউনট্রেন্ডে শক্তিশালী)।") t@{ s ->
            val c = s.c(0)
            if (trendOf(s.all, 1) != -1) return@t null
            if (c.bodyRatio > 0.12f) return@t null
            if (c.lowerWickRatio < 0.6f || c.upperWickRatio > 0.12f) return@t null
            0.55f + c.lowerWickRatio * 0.4f
        },

        Rule("Gravestone Doji", "গ্রেভস্টোন দোজি", Signal.SELL, 1,
            "দাম উপরে উঠে পুরো ধসে এসেছে — ক্রেতাদের ব্যর্থতা (আপট্রেন্ডে সতর্কতা)।") t@{ s ->
            val c = s.c(0)
            if (trendOf(s.all, 1) != 1) return@t null
            if (c.bodyRatio > 0.12f) return@t null
            if (c.upperWickRatio < 0.6f || c.lowerWickRatio > 0.12f) return@t null
            0.55f + c.upperWickRatio * 0.4f
        },

        Rule("Hammer", "হাতুড়ে (Hammer)", Signal.BUY, 1,
            "ডাউনট্রেন্ডে লম্বা নিচের উইক — বিক্রি-চাপ ক্রেতারা শুষে নিয়েছে।") t@{ s ->
            val c = s.c(0)
            if (trendOf(s.all, 1) != -1) return@t null
            if (c.range < s.avgRange(1) * 0.5f) return@t null
            val q = hammerShape(c) ?: return@t null
            clamp01(q + if (c.isBullish) 0.06f else 0f)
        },

        Rule("Hanging Man", "হ্যাংগিং ম্যান", Signal.SELL, 1,
            "আপট্রেন্ডে হাতুড়ে-আকৃতি — ক্রেতাদের ধাক্কা দুর্বল হচ্ছে।") t@{ s ->
            val c = s.c(0)
            if (trendOf(s.all, 1) != 1) return@t null
            val q = hammerShape(c) ?: return@t null
            clamp01(q * 0.95f)
        },

        Rule("Inverted Hammer", "ইনভার্টেড হাতুড়ে", Signal.BUY, 1,
            "ডাউনট্রেন্ডে উপরের লম্বা উইক — ক্রেতাদের প্রথম প্রতিরোধ।") t@{ s ->
            val c = s.c(0)
            if (trendOf(s.all, 1) != -1) return@t null
            val q = invertedHammerShape(c) ?: return@t null
            clamp01(q * 0.9f + if (c.isBullish) 0.05f else 0f)
        },

        Rule("Shooting Star", "শুটিং স্টার", Signal.SELL, 1,
            "আপট্রেন্ডে উপরের লম্বা উইক — উর্ধ্ব অগ্রযাত্রা প্রত্যাখ্যাত।") t@{ s ->
            val c = s.c(0)
            if (trendOf(s.all, 1) != 1) return@t null
            val q = invertedHammerShape(c) ?: return@t null
            clamp01(q + if (c.isBearish) 0.06f else 0f)
        },

        Rule("Bullish Marubozu", "বুলিশ মারুবোজু", Signal.BUY, 1,
            "পুরো বডি, উইক প্রায় নেই — ক্রেতাদের পূর্ণ দখলে ঝুঁকিহীন অগ্রযাত্রা।") t@{ s ->
            val c = s.c(0)
            if (!c.isBullish || c.bodyRatio < 0.9f) return@t null
            if (c.body < s.avgBody(1) * 1.4f) return@t null
            clamp01(0.5f + (c.bodyRatio - 0.9f) * 3f + if (trendOf(s.all, 1) == 1) 0.08f else 0f)
        },

        Rule("Bearish Marubozu", "বিয়ারিশ মারুবোজু", Signal.SELL, 1,
            "পুরো লাল বডি — বিক্রেতাদের পূর্ণ দখল।") t@{ s ->
            val c = s.c(0)
            if (!c.isBearish || c.bodyRatio < 0.9f) return@t null
            if (c.body < s.avgBody(1) * 1.4f) return@t null
            clamp01(0.5f + (c.bodyRatio - 0.9f) * 3f + if (trendOf(s.all, 1) == -1) 0.08f else 0f)
        },

        Rule("Spinning Top", "স্পিনিং টপ", Signal.NEUTRAL, 1,
            "ছোট বডি, দুই পাশে উইক — দুই পক্ষের লড়াই সমান।") t@{ s ->
            val c = s.c(0)
            if (c.bodyRatio > 0.32f) return@t null
            if (c.upperWick < c.body || c.lowerWick < c.body) return@t null
            if (c.range < s.avgRange(1) * 0.4f) return@t null
            0.58f
        },

        Rule("Bullish Belt Hold", "বুলিশ বেল্ট হোল্ড", Signal.BUY, 1,
            "লো-এ খুলে টানা উপরে — ডাউনট্রেন্ডে ধরে রাখার চাপ।") t@{ s ->
            val c = s.c(0)
            if (trendOf(s.all, 1) != -1) return@t null
            if (!c.isBullish || c.lowerWickRatio > 0.05f) return@t null
            if (c.bodyRatio < 0.55f || c.range < s.avgRange(1) * 0.8f) return@t null
            0.58f + (c.bodyRatio - 0.55f) * 0.5f
        },

        Rule("Bearish Belt Hold", "বিয়ারিশ বেল্ট হোল্ড", Signal.SELL, 1,
            "হাই-এ খুলে টানা নিচে — বিক্রির টানা চাপ।") t@{ s ->
            val c = s.c(0)
            if (trendOf(s.all, 1) != 1) return@t null
            if (!c.isBearish || c.upperWickRatio > 0.05f) return@t null
            if (c.bodyRatio < 0.55f || c.range < s.avgRange(1) * 0.8f) return@t null
            0.58f + (c.bodyRatio - 0.55f) * 0.5f
        },

        // ══ দ্বৈত ক্যান্ডেল (১৪) ═══════════════════════════════

        Rule("Bullish Engulfing", "বুলিশ এনগালফিং", Signal.BUY, 2,
            "সবুজ ক্যান্ডেল আগের লালটিকে পুরো গিলেছে — ক্রেতাদের কাছে দখল।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (!a.isBearish || !b.isBullish) return@t null
            if (b.open > a.close || b.close < a.open) return@t null
            if (trendOf(s.all, 2) == 1) return@t null
            val engulf = (b.body - a.body) / (a.body + 0.0001f)
            val size = clamp01(b.body / (s.avgRange(2) * 0.55f))
            clamp01(0.42f + clamp01(engulf) * 0.28f + size * 0.34f)
        },

        Rule("Bearish Engulfing", "বিয়ারিশ এনগালফিং", Signal.SELL, 2,
            "লাল ক্যান্ডেল আগের সবুজটিকে পুরো গিলেছে — বিক্রেতাদের দখল।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (!a.isBullish || !b.isBearish) return@t null
            if (b.open < a.close || b.close > a.open) return@t null
            if (trendOf(s.all, 2) == -1) return@t null
            val engulf = (b.body - a.body) / (a.body + 0.0001f)
            val size = clamp01(b.body / (s.avgRange(2) * 0.55f))
            clamp01(0.42f + clamp01(engulf) * 0.28f + size * 0.34f)
        },

        Rule("Bullish Harami", "বুলিশ হারামি", Signal.BUY, 2,
            "লম্বা লালের ভিতরে ছোট ক্যান্ডেল — বিক্রির গতি থেমে গেছে।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (trendOf(s.all, 2) != -1) return@t null
            if (!a.isBearish || a.bodyRatio < 0.5f) return@t null
            if (a.body < s.avgBody(2) * 1.15f) return@t null
            val tol = a.body * 0.1f
            if (b.bodyHigh > a.bodyHigh + tol || b.bodyLow < a.bodyLow - tol) return@t null
            if (b.body > a.body * 0.55f) return@t null
            clamp01(0.55f + (1f - b.body / (a.body + 0.0001f)) * 0.3f)
        },

        Rule("Bearish Harami", "বিয়ারিশ হারামি", Signal.SELL, 2,
            "লম্বা সবুজের ভিতরে ছোট ক্যান্ডেল — কেনার গতি থেমেছে।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (trendOf(s.all, 2) != 1) return@t null
            if (!a.isBullish || a.bodyRatio < 0.5f) return@t null
            if (a.body < s.avgBody(2) * 1.15f) return@t null
            val tol = a.body * 0.1f
            if (b.bodyHigh > a.bodyHigh + tol || b.bodyLow < a.bodyLow - tol) return@t null
            if (b.body > a.body * 0.55f) return@t null
            clamp01(0.55f + (1f - b.body / (a.body + 0.0001f)) * 0.3f)
        },

        Rule("Bullish Harami Cross", "বুলিশ হারামি ক্রস", Signal.BUY, 2,
            "হারামি + দোজি — বিক্রির সম্পূর্ণ টলোমালো অবস্থা।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (trendOf(s.all, 2) != -1) return@t null
            if (!a.isBearish || a.bodyRatio < 0.5f) return@t null
            if (b.bodyRatio > 0.1f) return@t null
            val tol = a.body * 0.1f
            if (b.bodyMid > a.bodyHigh + tol || b.bodyMid < a.bodyLow - tol) return@t null
            0.68f
        },

        Rule("Bearish Harami Cross", "বিয়ারিশ হারামি ক্রস", Signal.SELL, 2,
            "হারামি + দোজি — কেনার অনিশ্চয়তা চরমে।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (trendOf(s.all, 2) != 1) return@t null
            if (!a.isBullish || a.bodyRatio < 0.5f) return@t null
            if (b.bodyRatio > 0.1f) return@t null
            val tol = a.body * 0.1f
            if (b.bodyMid > a.bodyHigh + tol || b.bodyMid < a.bodyLow - tol) return@t null
            0.68f
        },

        Rule("Piercing Line", "পিয়ার্সিং লাইন", Signal.BUY, 2,
            "নিচে খুলে আগের লাল বডির অর্ধেকের উপরে ক্লোজ — শক্ত প্রত্যাবর্তন।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (trendOf(s.all, 2) != -1) return@t null
            if (!a.isBearish || !b.isBullish) return@t null
            if (b.open > a.close + a.body * 0.15f) return@t null
            if (b.close <= a.bodyMid || b.close >= a.open) return@t null
            val depth = (b.close - a.bodyMid) / (a.body / 2f + 0.0001f)
            clamp01(0.52f + clamp01(depth) * 0.35f)
        },

        Rule("Dark Cloud Cover", "ডার্ক ক্লাউড কভার", Signal.SELL, 2,
            "উপরে খুলে আগের সবুজ বডির অর্ধেকের নিচে ক্লোজ — মেঘোদ্ভাব।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (trendOf(s.all, 2) != 1) return@t null
            if (!a.isBullish || !b.isBearish) return@t null
            if (b.open < a.close - a.body * 0.15f) return@t null
            if (b.close >= a.bodyMid || b.close <= a.open) return@t null
            val depth = (a.bodyMid - b.close) / (a.body / 2f + 0.0001f)
            clamp01(0.52f + clamp01(depth) * 0.35f)
        },

        Rule("Tweezer Bottom", "টুইজার বটম", Signal.BUY, 2,
            "দুই ক্যান্ডেলের লো প্রায় সমান — দ্বিবার সেই দাম প্রত্যাখ্যাত।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (trendOf(s.all, 2) != -1) return@t null
            if (!a.isBearish || !b.isBullish) return@t null
            if (!near(a.low, b.low, s.avgRange(2) * 0.12f)) return@t null
            0.62f
        },

        Rule("Tweezer Top", "টুইজার টপ", Signal.SELL, 2,
            "দুই ক্যান্ডেলের হাই প্রায় সমান — ওই দামে দ্বিধা স্পষ্ট।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (trendOf(s.all, 2) != 1) return@t null
            if (!a.isBullish || !b.isBearish) return@t null
            if (!near(a.high, b.high, s.avgRange(2) * 0.12f)) return@t null
            0.62f
        },

        Rule("Matching Low", "ম্যাচিং লো", Signal.BUY, 2,
            "দুই লাল ক্যান্ডেল একই ক্লোজে — সেখানেই সাপোর্ট পাওয়া গেছে।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (trendOf(s.all, 2) != -1) return@t null
            if (!a.isBearish || !b.isBearish) return@t null
            if (!near(a.close, b.close, s.avgRange(2) * 0.08f)) return@t null
            0.56f
        },

        Rule("Kicking Bullish", "কিকিং (বুলিশ)", Signal.STRONG_BUY, 2,
            "লাল মারুবোজুর পর গ্যাপ-আপ সবুজ মারুবোজু — আকস্মিক শক্তি-পাল্টা।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (!a.isBearish || a.bodyRatio < 0.85f) return@t null
            if (!b.isBullish || b.bodyRatio < 0.85f) return@t null
            if (b.low < a.high) return@t null
            0.82f
        },

        Rule("Kicking Bearish", "কিকিং (বিয়ারিশ)", Signal.STRONG_SELL, 2,
            "সবুজ মারুবোজুর পর গ্যাপ-ডাউন লাল মারুবোজু — হঠাৎ বিক্রি-ঢল।") t@{ s ->
            val a = s.c(1); val b = s.c(0)
            if (!a.isBullish || a.bodyRatio < 0.85f) return@t null
            if (!b.isBearish || b.bodyRatio < 0.85f) return@t null
            if (b.high > a.low) return@t null
            0.82f
        },

        // ══ ত্রৈ ক্যান্ডেল (১৫) ════════════════════════════════

        Rule("Morning Star", "মর্নিং স্টার", Signal.BUY, 3,
            "লম্বা লাল → ছোট তারা → শক্ত সবুজ: ডাউনট্রেন্ডের ক্লাসিক উলটো।") t@{ s ->
            val c2 = s.c(2); val star = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) != -1) return@t null
            if (!c2.isBearish || c2.bodyRatio < 0.45f) return@t null
            if (c2.body < s.avgBody(3) * 1.2f) return@t null
            if (star.body > c2.body * 0.4f) return@t null
            if (star.bodyHigh > c2.close + c2.body * 0.3f) return@t null
            if (!c0.isBullish || c0.close <= c2.bodyMid) return@t null
            val pen = clamp01((c0.close - c2.bodyMid) / (c2.body / 2f + 0.0001f))
            0.58f + pen * 0.32f
        },

        Rule("Evening Star", "ইভিনিং স্টার", Signal.SELL, 3,
            "লম্বা সবুজ → তারা → শক্ত লাল: আপট্রেন্ডের ক্লাসিক উলটো।") t@{ s ->
            val c2 = s.c(2); val star = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) == -1) return@t null
            if (!c2.isBullish || c2.bodyRatio < 0.45f) return@t null
            if (c2.body < s.avgBody(3) * 1.2f) return@t null
            if (star.body > c2.body * 0.4f) return@t null
            if (star.bodyLow < c2.close - c2.body * 0.3f) return@t null
            if (!c0.isBearish || c0.close >= c2.bodyMid) return@t null
            val pen = clamp01((c2.bodyMid - c0.close) / (c2.body / 2f + 0.0001f))
            0.58f + pen * 0.32f
        },

        Rule("Morning Doji Star", "মর্নিং দোজি স্টার", Signal.BUY, 3,
            "তারাটি দোজি — আরও শক্তিশালী মর্নিং স্টার।") t@{ s ->
            val c2 = s.c(2); val star = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) != -1) return@t null
            if (!c2.isBearish || c2.body < s.avgBody(3) * 1.1f) return@t null
            if (star.bodyRatio > 0.12f) return@t null
            if (!c0.isBullish || c0.close <= c2.bodyMid) return@t null
            0.74f
        },

        Rule("Evening Doji Star", "ইভিনিং দোজি স্টার", Signal.SELL, 3,
            "তারাটি দোজি — আরও শক্তিশালী ইভিনিং স্টার।") t@{ s ->
            val c2 = s.c(2); val star = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) != 1) return@t null
            if (!c2.isBullish || c2.body < s.avgBody(3) * 1.1f) return@t null
            if (star.bodyRatio > 0.12f) return@t null
            if (!c0.isBearish || c0.close >= c2.bodyMid) return@t null
            0.74f
        },

        Rule("Abandoned Baby (Bull)", "অ্যাবান্ডন্ড বেবি (বুলিশ)", Signal.STRONG_BUY, 3,
            "দোজি-তারা উইকেও কারো সাথে মেশেনি — সম্পূর্ণ বিচ্ছিন্ন উলটো।") t@{ s ->
            val c2 = s.c(2); val star = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) != -1) return@t null
            if (!c2.isBearish || c2.bodyRatio < 0.5f) return@t null
            if (star.bodyRatio > 0.1f) return@t null
            if (!c0.isBullish || c0.bodyRatio < 0.5f) return@t null
            val tol = s.avgRange(3) * 0.05f
            if (star.high > c2.low + tol || star.high > c0.low + tol) return@t null
            0.82f
        },

        Rule("Abandoned Baby (Bear)", "অ্যাবান্ডন্ড বেবি (বিয়ারিশ)", Signal.STRONG_SELL, 3,
            "উপরে বিচ্ছিন্ন দোজি-তারা — সম্পূর্ণ বিচ্ছিন্ন উলটো।") t@{ s ->
            val c2 = s.c(2); val star = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) != 1) return@t null
            if (!c2.isBullish || c2.bodyRatio < 0.5f) return@t null
            if (star.bodyRatio > 0.1f) return@t null
            if (!c0.isBearish || c0.bodyRatio < 0.5f) return@t null
            val tol = s.avgRange(3) * 0.05f
            if (star.low < c2.high - tol || star.low < c0.high - tol) return@t null
            0.82f
        },

        Rule("Tri-Star Bottom", "ট্রাই-স্টার বটম", Signal.BUY, 3,
            "ডাউনট্রেন্ডে পরপর তিনটি দোজি — বিক্রির শেষাংশ।") t@{ s ->
            if (trendOf(s.all, 3) != -1) return@t null
            for (i in 0..2) if (s.c(i).bodyRatio > 0.12f) return@t null
            0.6f
        },

        Rule("Tri-Star Top", "ট্রাই-স্টার টপ", Signal.SELL, 3,
            "আপট্রেন্ডে পরপর তিনটি দোজি — কেনার শেষাংশ।") t@{ s ->
            if (trendOf(s.all, 3) != 1) return@t null
            for (i in 0..2) if (s.c(i).bodyRatio > 0.12f) return@t null
            0.6f
        },

        Rule("Three White Soldiers", "থ্রি হোয়াইট সোলজার্স", Signal.STRONG_BUY, 3,
            "পরপর তিন শক্ত সবুজ, প্রতিটি আগেরটার বডিতে খুলে উর্ধ্বমুখী।") t@{ s ->
            val a = s.c(2); val b = s.c(1); val c = s.c(0)
            if (!a.isBullish || !b.isBullish || !c.isBullish) return@t null
            val avgB = s.avgBody(3)
            if (a.body < avgB * 0.7f || b.body < avgB * 0.7f || c.body < avgB * 0.7f) return@t null
            if (b.close <= a.close || c.close <= b.close) return@t null
            val tol = a.body * 0.2f
            if (b.open < a.bodyLow - tol || b.open > a.bodyHigh + tol) return@t null
            if (c.open < b.bodyLow - tol || c.open > b.bodyHigh + tol) return@t null
            if (b.upperWick > b.body * 0.7f || c.upperWick > c.body * 0.7f) return@t null
            0.78f
        },

        Rule("Three Black Crows", "থ্রি ব্ল্যাক ক্রো", Signal.STRONG_SELL, 3,
            "পরপর তিন শক্ত লাল, প্রতিটি আগেরটার বডিতে খুলে নিম্নমুখী।") t@{ s ->
            val a = s.c(2); val b = s.c(1); val c = s.c(0)
            if (!a.isBearish || !b.isBearish || !c.isBearish) return@t null
            val avgB = s.avgBody(3)
            if (a.body < avgB * 0.7f || b.body < avgB * 0.7f || c.body < avgB * 0.7f) return@t null
            if (b.close >= a.close || c.close >= b.close) return@t null
            val tol = a.body * 0.2f
            if (b.open < a.bodyLow - tol || b.open > a.bodyHigh + tol) return@t null
            if (c.open < b.bodyLow - tol || c.open > b.bodyHigh + tol) return@t null
            if (b.lowerWick > b.body * 0.7f || c.lowerWick > c.body * 0.7f) return@t null
            0.78f
        },

        Rule("Three Inside Up", "থ্রি ইনসাইড আপ", Signal.BUY, 3,
            "হারামির পর ভাঙন — প্রথম ক্যান্ডেলের ওপেন ছাড়িয়ে ক্লোজ।") t@{ s ->
            val c2 = s.c(2); val c1 = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) != -1) return@t null
            if (!c2.isBearish || c2.bodyRatio < 0.5f) return@t null
            if (!c1.isBullish) return@t null
            val tol = c2.body * 0.1f
            if (c1.bodyHigh > c2.bodyHigh + tol || c1.bodyLow < c2.bodyLow - tol) return@t null
            if (!c0.isBullish || c0.close <= c2.open) return@t null
            0.7f
        },

        Rule("Three Inside Down", "থ্রি ইনসাইড ডাউন", Signal.SELL, 3,
            "বিয়ারিশ হারামির উলটো নিশ্চিতকরণ।") t@{ s ->
            val c2 = s.c(2); val c1 = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) != 1) return@t null
            if (!c2.isBullish || c2.bodyRatio < 0.5f) return@t null
            if (!c1.isBearish) return@t null
            val tol = c2.body * 0.1f
            if (c1.bodyHigh > c2.bodyHigh + tol || c1.bodyLow < c2.bodyLow - tol) return@t null
            if (!c0.isBearish || c0.close >= c2.open) return@t null
            0.7f
        },

        Rule("Three Outside Up", "থ্রি আউটসাইড আপ", Signal.BUY, 3,
            "এনগালফিংয়ের পর সবুজ নিশ্চিতকরণ — উলটো নিশ্চিত।") t@{ s ->
            val c2 = s.c(2); val c1 = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) == 1) return@t null
            if (!c2.isBearish || !c1.isBullish) return@t null
            if (c1.open > c2.close || c1.close < c2.open) return@t null
            if (!c0.isBullish || c0.close <= c1.close) return@t null
            0.72f
        },

        Rule("Three Outside Down", "থ্রি আউটসাইড ডাউন", Signal.SELL, 3,
            "বিয়ারিশ এনগালফিংয়ের পর লাল নিশ্চিতকরণ।") t@{ s ->
            val c2 = s.c(2); val c1 = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) == -1) return@t null
            if (!c2.isBullish || !c1.isBearish) return@t null
            if (c1.open < c2.close || c1.close > c2.open) return@t null
            if (!c0.isBearish || c0.close >= c1.close) return@t null
            0.72f
        },

        Rule("Stick Sandwich", "স্টিক স্যান্ডউইচ", Signal.BUY, 3,
            "লাল-সবুজ-লাল, প্রথম-শেষের ক্লোজ সমান — সেই দামেই সাপোর্ট।") t@{ s ->
            val c2 = s.c(2); val c1 = s.c(1); val c0 = s.c(0)
            if (trendOf(s.all, 3) != -1) return@t null
            if (!c2.isBearish || !c1.isBullish || !c0.isBearish) return@t null
            if (!near(c2.close, c0.close, s.avgRange(3) * 0.1f)) return@t null
            0.62f
        },

        // ══ পাঁচ-ক্যান্ডেল ধারাবাহিকতা (২) ═════════════════════

        Rule("Rising Three Methods", "রাইজিং থ্রি মেথডস", Signal.BUY, 5,
            "লম্বা সবুজের ভিতরে তিন ছোট লাল, আবার সবুজ-ভাঙন — আপট্রেন্ড অব্যাহত।") t@{ s ->
            if (trendOf(s.all, 5) != 1) return@t null
            val big = s.c(4)
            if (!big.isBullish || big.bodyRatio < 0.5f) return@t null
            if (big.body < s.avgBody(5) * 1.15f) return@t null
            for (i in 1..3) {
                val m = s.c(i)
                if (m.body > big.body * 0.55f) return@t null
                if (m.bodyLow < big.bodyLow || m.bodyHigh > big.bodyHigh) return@t null
            }
            val c0 = s.c(0)
            if (!c0.isBullish || c0.close <= big.close) return@t null
            0.7f
        },

        Rule("Falling Three Methods", "ফলিং থ্রি মেথডস", Signal.SELL, 5,
            "লম্বা লালের ভিতরে তিন ছোট সবুজ, আবার লাল-ভাঙন — ডাউনট্রেন্ড অব্যাহত।") t@{ s ->
            if (trendOf(s.all, 5) != -1) return@t null
            val big = s.c(4)
            if (!big.isBearish || big.bodyRatio < 0.5f) return@t null
            if (big.body < s.avgBody(5) * 1.15f) return@t null
            for (i in 1..3) {
                val m = s.c(i)
                if (m.body > big.body * 0.55f) return@t null
                if (m.bodyLow < big.bodyLow || m.bodyHigh > big.bodyHigh) return@t null
            }
            val c0 = s.c(0)
            if (!c0.isBearish || c0.close >= big.close) return@t null
            0.7f
        }
    )
}
