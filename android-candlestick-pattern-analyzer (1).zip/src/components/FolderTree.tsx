import { Folder, FolderOpen, FileCode2, FileCog, FileText, FileType2 } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";
import { projectTree, type TreeNode } from "../data";

function FileIcon({ name }: { name: string }) {
  if (name.endsWith(".kt")) return <FileCode2 className="w-4 h-4 text-emerald-400" />;
  if (name.endsWith(".xml")) return <FileType2 className="w-4 h-4 text-rose-400" />;
  if (name.endsWith(".properties")) return <FileText className="w-4 h-4 text-slate-400" />;
  return <FileCog className="w-4 h-4 text-cyan-400" />;
}

function Node({
  node,
  depth,
  onSelect,
  active,
}: {
  node: TreeNode;
  depth: number;
  onSelect: (id: string) => void;
  active: string | null;
}) {
  const isActive = node.fileId && node.fileId === active;
  return (
    <div>
      <div
        className={
          "group flex items-center gap-2 py-[5px] rounded-lg pr-3 " +
          (node.fileId ? "cursor-pointer hover:bg-white/[0.045] " : "") +
          (isActive ? "bg-emerald-400/[0.09] " : "")
        }
        style={{ paddingLeft: depth * 20 + 10 }}
        onClick={() => node.fileId && onSelect(node.fileId)}
      >
        {node.type === "dir" ? (
          depth < 2 ? (
            <FolderOpen className="w-4 h-4 text-amber-400/90" />
          ) : (
            <Folder className="w-4 h-4 text-amber-400/70" />
          )
        ) : (
          <FileIcon name={node.name} />
        )}
        <span
          className={
            "font-mono text-[13px] " +
            (node.type === "dir"
              ? "text-slate-200 font-semibold"
              : isActive
                ? "text-emerald-300"
                : "text-slate-400")
          }
        >
          {node.name}
        </span>
        {node.note && (
          <span className="hidden sm:inline text-[11px] text-slate-600 font-normal ml-1">— {node.note}</span>
        )}
        {node.fileId && (
          <span className="ml-auto text-[10px] font-mono uppercase tracking-wider text-emerald-500/0 group-hover:text-emerald-500 transition-colors">
            কোড →
          </span>
        )}
      </div>
      {node.children?.map((c) => (
        <Node key={c.name} node={c} depth={depth + 1} onSelect={onSelect} active={active} />
      ))}
    </div>
  );
}

export default function FolderTree({ onSelect, active }: { onSelect: (id: string) => void; active: string | null }) {
  return (
    <section id="structure" className="relative py-24 lg:py-32 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHead
          no="০৩"
          label="Project Layout"
          title="পুরো ফোল্ডার স্ট্রাকচার — কোন ফাইল কোথায় যাবে"
          desc="AIDE-তে প্রজেক্ট-ভিউতে ঠিক এই গাছটি গড়ে তুলুন। যে কোনো ফাইলে ক্লিক করলে নিচের কোড এক্সপ্লোরারে সেই ফাইলের পুরো কোড ও বসানোর নির্দেশনা চলে আসবে।"
        />

        <Reveal delay={0.1}>
          <div className="mt-12 rounded-2xl border border-white/[0.08] bg-panel overflow-hidden">
            <div className="flex items-center gap-2 px-5 py-3.5 border-b border-white/[0.06] bg-white/[0.02]">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/70" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/70" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/70" />
              <span className="ml-3 text-[12px] font-mono text-slate-500">AIDE → Project View → TradeLensAI</span>
            </div>
            <div className="p-3 sm:p-5 overflow-x-auto thin-scroll">
              <div className="min-w-[520px]">
                <Node node={projectTree} depth={0} onSelect={onSelect} active={active} />
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
