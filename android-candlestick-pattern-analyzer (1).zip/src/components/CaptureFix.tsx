import { Bug, CheckCheck } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";
import { captureFixes } from "../data";

export default function CaptureFix() {
  return (
    <section id="fix" className="relative py-24 lg:py-32 scroll-mt-16 bg-[#080d13] border-y border-white/[0.05]">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHead
          no="০২"
          label="Root-Cause Analysis"
          title="আগের স্ক্রিন-ক্যাপচার সমস্যা — ৬টি মূল কারণ ও স্থায়ী সমাধান"
          desc="আপনার আগের প্রজেক্টে যে সমস্যা হয়েছিল, তার মূল কারণগুলো Android প্ল্যাটফর্ম-নিয়মের সাথে মেলে। নিচের প্রতিটি ফিক্স এই গাইডের কোডে সংযুক্ত করা আছে — কোথায়, তাও বলা আছে।"
        />

        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {captureFixes.map((f, i) => (
            <Reveal key={f.no} delay={i * 0.06}>
              <div className="h-full rounded-2xl border border-white/[0.08] bg-panel p-6 hover-lift group">
                <div className="flex items-center justify-between mb-5">
                  <span className="font-display font-bold text-2xl text-white/15 group-hover:text-emerald-400/50 transition-colors">
                    {f.no}
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-[10.5px] font-mono uppercase tracking-[0.14em] text-rose-300/80 bg-rose-500/[0.08] border border-rose-500/20 rounded-full px-2.5 py-1">
                    <Bug className="w-3 h-3" /> সমস্যা
                  </span>
                </div>
                <p className="text-[14.5px] leading-relaxed text-slate-300 font-medium mb-4">{f.problem}</p>
                <div className="border-t border-white/[0.06] pt-4 flex gap-2.5">
                  <CheckCheck className="w-4 h-4 mt-0.5 shrink-0 text-emerald-400" />
                  <p className="text-[13px] leading-relaxed text-slate-400">{f.fix}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1}>
          <div className="mt-10 rounded-2xl border border-emerald-400/20 bg-emerald-400/[0.045] p-6 lg:p-7">
            <div className="flex flex-wrap items-center gap-3 mb-3">
              <span className="text-[11px] font-mono uppercase tracking-[0.2em] text-emerald-300">সঠিক ক্রমটি</span>
              <span className="h-px flex-1 bg-emerald-400/15" />
            </div>
            <p className="font-mono text-[13px] sm:text-[14px] leading-[2] text-slate-300">
              Activity: নতুন createScreenCaptureIntent() → রেজাল্ট ProjectionStore-এ save<br />
              Service: ① startForeground(type=<span className="text-emerald-300">mediaProjection</span>) → ② getMediaProjection() → ③ registerCallback() → ④ ImageReader → ⑤ createVirtualDisplay() → ফ্রেমে ⑥ <span className="text-emerald-300">finally: image.close()</span>
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
