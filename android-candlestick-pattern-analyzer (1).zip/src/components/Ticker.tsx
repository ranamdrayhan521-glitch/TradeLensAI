import { Sparkle } from "lucide-react";
import { tickerNames } from "../lib/patterns";

export default function Ticker() {
  const items = [...tickerNames, ...tickerNames];
  return (
    <div className="relative border-y border-white/[0.06] bg-[#080d13] py-4 overflow-hidden">
      <div className="ticker-track flex items-center gap-8 whitespace-nowrap w-max">
        {items.map((name, i) => (
          <span key={i} className="inline-flex items-center gap-3 text-[13.5px] text-slate-500">
            <Sparkle className="w-3.5 h-3.5 text-emerald-500/70" />
            {name}
          </span>
        ))}
      </div>
      <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-[#05080c] to-transparent" />
      <div className="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-[#05080c] to-transparent" />
    </div>
  );
}
