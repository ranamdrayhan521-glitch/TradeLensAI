import { motion } from "framer-motion";
import {
  Smartphone,
  Camera,
  Crosshair,
  TrendingUp,
  BrainCircuit,
  Layers3,
} from "lucide-react";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";

const nodes = [
  {
    icon: Smartphone,
    title: "টার্গেট স্ক্রিন",
    sub: "ব্রোকার / চার্ট অ্যাপ",
    desc: "TradingView বা যে কোনো চার্ট — অ্যাপটি কেবল পিক্সেল দেখে, ভেতরে কিছু ছোঁয় না।",
    color: "text-slate-300 border-slate-400/25 bg-slate-400/[0.07]",
  },
  {
    icon: Camera,
    title: "CaptureService",
    sub: "MediaProjection → ImageReader",
    desc: "ফোরগ্রাউন্ড সার্ভিসে VirtualDisplay; থ্রোটল করা ফ্রেম Bitmap-এ (rowStride-ফিক্সড)।",
    color: "text-emerald-300 border-emerald-400/30 bg-emerald-400/[0.07]",
  },
  {
    icon: Crosshair,
    title: "ChartDetector",
    sub: "HSV পিক্সেল-শ্রেণিবিন্যাস",
    desc: "৪০০px ম্যাপে ক্যান্ডেল-রঙের ঘনত্ব বিশ্লেষণ — চার্ট-আয়তন নিখুঁতভাবে বের হয়।",
    color: "text-cyan-300 border-cyan-400/30 bg-cyan-400/[0.07]",
  },
  {
    icon: TrendingUp,
    title: "CandleExtractor",
    sub: "বডি / উইক / দিক",
    desc: "কলাম-গ্রুপিং থেকে আলাদা ক্যান্ডেল; রো-কভারেজ পদ্ধতিতে বডি-উইক পৃথক হয়।",
    color: "text-violet-300 border-violet-400/30 bg-violet-400/[0.07]",
  },
  {
    icon: BrainCircuit,
    title: "PatternEngine",
    sub: "৪৪ নিয়ম + প্রবণতা-গেট",
    desc: "জ্যামিতিক অনুপাতে প্রতিটি প্যাটার্ন মিলে; মিল না থাকলে সৎ NEUTRAL।",
    color: "text-amber-300 border-amber-400/30 bg-amber-400/[0.07]",
  },
  {
    icon: Layers3,
    title: "Overlay",
    sub: "টাচ-পাসথ্রু সিগন্যাল + চিপ",
    desc: "চার্টের উপর পালসিং বক্স-লেবেল; আঙুল বাধাহীন। ভাসমান চিপে pause/resume।",
    color: "text-rose-300 border-rose-400/30 bg-rose-400/[0.07]",
  },
];

export default function Architecture() {
  return (
    <section id="architecture" className="relative py-24 lg:py-32 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHead
          no="০১"
          label="System Pipeline"
          title="এক ফ্রেমের যাত্রা — স্ক্রিন থেকে সিগন্যাল"
          desc="পুরো সিস্টেম ৫টি স্বতন্ত্র স্তরে ভাগ করা — প্রতিটি স্তর একক দায়িত্বে, আলাদা টেস্টযোগ্য। কোনো স্তর ব্যর্থ হলে পাইপলাইন স্পষ্ট স্ট্যাটাস দেয়, ক্র্যাশ করে না।"
        />

        <Reveal>
          <div className="mt-14 grid grid-cols-1 md:grid-cols-3 xl:grid-cols-6 gap-4">
            {nodes.map((n, i) => (
              <motion.div
                key={n.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ y: -6 }}
                className="relative rounded-2xl border border-white/[0.08] bg-panel p-5 hover-lift"
              >
                <div className="text-[10px] font-mono text-slate-600 mb-4">{String(i + 1).padStart(2, "0")}</div>
                <div className={"w-11 h-11 rounded-xl border flex items-center justify-center mb-4 " + n.color}>
                  <n.icon className="w-5 h-5" strokeWidth={2} />
                </div>
                <div className="font-semibold text-white text-[15.5px] mb-0.5">{n.title}</div>
                <div className="text-[11px] font-mono text-slate-500 mb-3">{n.sub}</div>
                <p className="text-[13px] leading-relaxed text-slate-400">{n.desc}</p>

                {i < nodes.length - 1 && (
                  <div className="hidden xl:block absolute top-1/2 -right-4 w-4 h-0.5 flow-line opacity-70" />
                )}
              </motion.div>
            ))}
          </div>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="mt-10 rounded-2xl border border-white/[0.07] bg-panel-2 px-6 py-5 flex flex-wrap items-center gap-x-10 gap-y-3">
            <span className="text-[12px] font-mono uppercase tracking-[0.16em] text-slate-500">প্রতি স্ক্যানে</span>
            {[
              "ফ্রেম ক্যাপচার ~১৫ মি.সে.",
              "ডিটেকশন ~৪০ মি.সে.",
              "এক্সট্রাকশন ~২০ মি.সে.",
              "৪৪ নিয়ম মিলানো <৫ মি.সে.",
              "মোট ≈ ১ স্ক্যান / ৫০০ মি.সে.",
            ].map((s) => (
              <span key={s} className="text-[13px] text-slate-400 font-mono">{s}</span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
