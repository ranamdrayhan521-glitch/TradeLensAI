import { CloudCog, Smartphone, ShieldAlert, PackageCheck, ArrowDownToLine } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";

const ghSteps = [
  "github.com-এ ফ্রি অ্যাকাউন্ট খুলুন → New repository → নাম দিন TradeLensAI",
  "রিপো খুলে 'uploading an existing file' লিংকে ক্লিক করুন",
  "ZIP আনজিপ করে TradeLensAI ফোল্ডারের ভেতরের সব ফাইল টেনে ছাড়ুন → Commit",
  "Actions ট্যাবে গিয়ে 'Build APK' রান হওয়া দেখুন (~৫–৮ মিনিট)",
  "শেষ হলে Artifacts → 'TradeLensAI-debug-apk' → ডাউনলোড → ইনস্টল",
];

const aideSteps = [
  "ইচ্ছাকৃত ZArchiver/MT Manager দিয়ে ZIP আনজিপ করুন",
  "AIDE → Open App Project → TradeLensAI ফোল্ডার খুলুন",
  "উপরে Run বাটন চাপুন — বিল্ড শেষে নিজে নিজেই ইনস্টল হয়ে যাবে",
];

export default function OneClickApk() {
  return (
    <section id="apk" className="relative py-24 lg:py-28 scroll-mt-16 bg-[#080d13] border-y border-white/[0.05]">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHead
          label="One-Click Install"
          title="কম্পিউটার ও টার্মিনাল ছাড়াই — মোবাইলে APK পাওয়ার ২টি পথ"
          desc="সৎ উত্তর আগে: এই ওয়েব-পরিবেশে Android টুলচেইন (JDK + SDK) নেই, তাই এখান থেকে সরাসরি কম্পাইল করা APK বানানো যায় না — আর কেউ আপনার কাস্টম কোডের 'রেডিমেড APK' বিনা-বিল্ডে দিলে সেটি বিশ্বাসযোগ্যও নয়। তবে নিচের দুই পথের যেকোনো একটিতে ফোন থেকেই প্রায় এক-ক্লিকে আসল APK পাবেন — প্রথমটার জন্য workflow ফাইলটি আমি ZIP-এ যোগ করে দিয়েছি।"
        />

        <div className="mt-12 grid lg:grid-cols-2 gap-5">
          <Reveal>
            <div className="h-full rounded-2xl border border-cyan-400/25 bg-gradient-to-br from-cyan-400/[0.06] to-panel p-7 hover-lift">
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                  <span className="w-11 h-11 rounded-xl bg-cyan-400/12 border border-cyan-400/30 flex items-center justify-center">
                    <CloudCog className="w-5.5 h-5.5 text-cyan-300" />
                  </span>
                  <div>
                    <h3 className="font-bold text-white text-[16.5px]">পথ ১ — ক্লাউডে বিল্ড (GitHub Actions)</h3>
                    <p className="text-[12px] text-slate-500 mt-0.5">সবচেয়ে ভারী কাজ ক্লাউড করে — ফোনের ব্রাউজার যথেষ্ট</p>
                  </div>
                </div>
                <span className="shrink-0 text-[10.5px] font-semibold uppercase tracking-wider text-cyan-300 border border-cyan-400/30 bg-cyan-400/[0.08] rounded-full px-2.5 py-1">প্রস্তাবিত</span>
              </div>
              <ol className="space-y-3">
                {ghSteps.map((s, i) => (
                  <li key={s} className="flex gap-3 text-[13.5px] leading-relaxed text-slate-400">
                    <span className="shrink-0 w-6 h-6 rounded-lg bg-cyan-400/10 border border-cyan-400/25 flex items-center justify-center text-[11px] font-bold text-cyan-300 font-display">{i + 1}</span>
                    {s}
                  </li>
                ))}
              </ol>
              <div className="mt-6 rounded-xl border border-white/[0.07] bg-[#080d14] px-4 py-3 flex gap-2.5">
                <PackageCheck className="w-4 h-4 mt-0.5 shrink-0 text-cyan-300" />
                <p className="text-[12.5px] leading-relaxed text-slate-500">
                  workflow ফাইল (<span className="font-mono text-slate-400">.github/workflows/android-build.yml</span>) ZIP-এর ভেতরেই আছে — আপলোডের কিছুক্ষণ পরেই বিল্ড নিজে শুরু হয়। বিল্ড লগও দেখতে পারবেন।
                </p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.08}>
            <div className="h-full rounded-2xl border border-emerald-400/25 bg-gradient-to-br from-emerald-400/[0.05] to-panel p-7 hover-lift">
              <div className="flex items-center gap-3 mb-5">
                <span className="w-11 h-11 rounded-xl bg-emerald-400/12 border border-emerald-400/30 flex items-center justify-center">
                  <Smartphone className="w-5.5 h-5.5 text-emerald-300" />
                </span>
                <div>
                  <h3 className="font-bold text-white text-[16.5px]">পথ ২ — AIDE দিয়ে সরাসরি ফোনে</h3>
                  <p className="text-[12px] text-slate-500 mt-0.5">সবচেয়ে দ্রুত — Run চাপলেই বিল্ড + ইনস্টল</p>
                </div>
              </div>
              <ol className="space-y-3">
                {aideSteps.map((s, i) => (
                  <li key={s} className="flex gap-3 text-[13.5px] leading-relaxed text-slate-400">
                    <span className="shrink-0 w-6 h-6 rounded-lg bg-emerald-400/10 border border-emerald-400/25 flex items-center justify-center text-[11px] font-bold text-emerald-300 font-display">{i + 1}</span>
                    {s}
                  </li>
                ))}
              </ol>
              <div className="mt-6 rounded-xl border border-white/[0.07] bg-[#080d14] px-4 py-3 flex gap-2.5">
                <ArrowDownToLine className="w-4 h-4 mt-0.5 shrink-0 text-emerald-300" />
                <p className="text-[12.5px] leading-relaxed text-slate-500">
                  AIDE ফ্রি সংস্করণেই এই প্রজেক্ট বিল্ড হয় (কোনো নেটিভ লাইব্রেরি/নমুনা কী লাগে না)। প্রথম সিঙ্কে ডিপেন্ডেন্সি ডাউনলোডের জন্য ওয়াইফাই দরকার।
                </p>
              </div>
            </div>
          </Reveal>
        </div>

        <Reveal delay={0.12}>
          <div className="mt-6 rounded-2xl border border-amber-400/20 bg-amber-400/[0.05] px-6 py-5 flex gap-3">
            <ShieldAlert className="w-5 h-5 mt-0.5 shrink-0 text-amber-300" />
            <p className="text-[13.5px] leading-[1.8] text-amber-100/80">
              <span className="font-semibold text-amber-200">ইনস্টলের আগে:</span> ফোনের Settings → Security → "Install unknown apps"-এ ব্রাউজার/AIDE-কে অনুমতি দিন। এটি <span className="font-semibold">ডিবাগ-সাইন্ড APK</span> — শুধু নিজের ব্যবহার ও পরীক্ষার জন্য; বিতরণ করতে চাইলে Android Studio থেকে সাইন্ড রিলিজ বানাতে হবে। সোর্সের প্রতিটি ফাইল নিচের এক্সপ্লোরারে স্বচ্ছভাবে দেখা যায় — গোপন কিছুই নেই।
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
