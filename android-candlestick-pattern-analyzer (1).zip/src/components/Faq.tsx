import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";
import { faqs } from "../data";
import { toBn } from "../lib/highlight";

export default function Faq() {
  const [open, setOpen] = useState(0);

  return (
    <section id="faq" className="relative py-24 lg:py-32 scroll-mt-16">
      <div className="max-w-4xl mx-auto px-5 lg:px-8">
        <SectionHead
          no="০৭"
          label="Troubleshooting"
          title="সমস্যা হলে এখানে আগে দেখুন"
          desc="রিয়েল-ওয়ার্ল্ড ব্যবহারে যে সমস্যাগুলো সবচেয়ে বেশি আসে — প্রতিটির সরাসরি সমাধান।"
        />

        <div className="mt-12 space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={i} delay={i * 0.04}>
                <div
                  className={
                    "rounded-2xl border transition-colors overflow-hidden " +
                    (isOpen ? "border-emerald-400/25 bg-panel" : "border-white/[0.08] bg-panel hover:border-white/20")
                  }
                >
                  <button
                    onClick={() => setOpen(isOpen ? -1 : i)}
                    className="w-full flex items-center gap-4 px-6 py-5 text-left"
                  >
                    <span className="font-display font-bold text-[13px] text-emerald-400/70 w-7 shrink-0">
                      {toBn(String(i + 1).padStart(2, "0"))}
                    </span>
                    <span className="flex-1 text-[15.5px] font-semibold text-white leading-snug">{f.q}</span>
                    <motion.span animate={{ rotate: isOpen ? 45 : 0 }} transition={{ duration: 0.22 }}>
                      <Plus className="w-5 h-5 text-slate-500" />
                    </motion.span>
                  </button>
                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
                      >
                        <p className="px-6 pb-6 pl-[68px] text-[14px] leading-[1.85] text-slate-400">
                          {f.a}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
