import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Search, TrendingUp, TrendingDown, Minus } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";
import MiniChart from "./MiniChart";
import { libraryPatterns } from "../lib/patterns";
import { toBn } from "../lib/highlight";

const biasMeta = {
  bullish: { label: "বুলিশ", cls: "text-emerald-300 border-emerald-400/30 bg-emerald-400/[0.08]", Icon: TrendingUp },
  bearish: { label: "বিয়ারিশ", cls: "text-rose-300 border-rose-400/30 bg-rose-400/[0.08]", Icon: TrendingDown },
  neutral: { label: "নিরপেক্ষ", cls: "text-amber-300 border-amber-400/30 bg-amber-400/[0.08]", Icon: Minus },
};

type Filter = "all" | "bullish" | "bearish" | "neutral";

export default function PatternLibrary() {
  const [filter, setFilter] = useState<Filter>("all");
  const [q, setQ] = useState("");

  const list = useMemo(() => {
    return libraryPatterns.filter((p) => {
      if (filter !== "all" && p.bias !== filter) return false;
      if (q) {
        const needle = q.toLowerCase();
        return (
          p.name.toLowerCase().includes(needle) ||
          p.nameBn.includes(q) ||
          p.desc.includes(q)
        );
      }
      return true;
    });
  }, [filter, q]);

  return (
    <section id="patterns" className="relative py-24 lg:py-32 scroll-mt-16 bg-[#080d13] border-y border-white/[0.05]">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHead
          no="০৬"
          label="Pattern Library"
          title={`ইঞ্জিনে যুক্ত প্যাটার্নসমূহ — ${toBn(libraryPatterns.length)}টি চিত্রায়িত`}
          desc="ধূসর ক্যান্ডেলগুলো প্রেক্ষাপট-প্রবণতা, উজ্জ্বলগুলো প্যাটার্ন নিজে। PatternEngine.kt-এ প্রতিটির নিখুঁত জ্যামিতিক লজিক কোডে লেখা আছে — এই লাইব্রেরি দেখলেই বুঝবেন ইঞ্জিন ঠিক কী খুঁজে।"
        />

        <Reveal delay={0.08}>
          <div className="mt-10 flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="প্যাটার্ন খুঁজুন… (engulfing / হাতুড়ে)"
                className="w-72 max-w-full rounded-xl border border-white/10 bg-panel pl-10 pr-4 py-2.5 text-[13.5px] text-slate-200 placeholder:text-slate-600 outline-none focus:border-emerald-400/40"
              />
            </div>
            <div className="flex items-center gap-2">
              {(
                [
                  ["all", "সবগুলো"],
                  ["bullish", "বুলিশ"],
                  ["bearish", "বিয়ারিশ"],
                  ["neutral", "নিরপেক্ষ"],
                ] as [Filter, string][]
              ).map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setFilter(key)}
                  className={
                    "rounded-full px-4 py-2 text-[13px] font-medium border transition-colors " +
                    (filter === key
                      ? "text-white border-emerald-400/50 bg-emerald-400/[0.12]"
                      : "text-slate-400 border-white/10 hover:border-white/25")
                  }
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </Reveal>

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {list.map((p, i) => {
            const bm = biasMeta[p.bias];
            return (
              <motion.div
                key={p.id}
                layout
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.45, delay: Math.min(i * 0.03, 0.3) }}
                className="rounded-2xl border border-white/[0.08] bg-panel p-5 hover-lift"
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <h3 className="font-display font-semibold text-[14.5px] text-white truncate">{p.name}</h3>
                  <span className={"shrink-0 inline-flex items-center gap-1 text-[10.5px] font-semibold border rounded-full px-2.5 py-1 " + bm.cls}>
                    <bm.Icon className="w-3 h-3" />
                    {bm.label}
                  </span>
                </div>
                <div className="text-[12.5px] text-emerald-300/90 mb-4">{p.nameBn} <span className="text-slate-600">• {toBn(p.count)} ক্যান্ডেল</span></div>
                <div className="rounded-xl border border-white/[0.06] bg-[#080d14] px-2 py-1 mb-4">
                  <MiniChart candles={p.candles} />
                </div>
                <p className="text-[12.5px] leading-relaxed text-slate-500">{p.desc}</p>
              </motion.div>
            );
          })}
        </div>

        {list.length === 0 && (
          <div className="mt-10 text-center text-slate-500 text-[14px]">কোনো প্যাটার্ন পাওয়া যায়নি — অন্য নাম লিখে দেখুন।</div>
        )}
      </div>
    </section>
  );
}
