import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChartCandlestick, Menu, X, Braces } from "lucide-react";

const links = [
  { href: "#download", label: "ZIP ডাউনলোড" },
  { href: "#apk", label: "এক-ক্লিক APK" },
  { href: "#architecture", label: "আর্কিটেকচার" },
  { href: "#fix", label: "স্ক্রিন-ক্যাপচার ফিক্স" },
  { href: "#structure", label: "ফোল্ডার স্ট্রাকচার" },
  { href: "#setup", label: "AIDE সেটআপ" },
  { href: "#code", label: "কোড এক্সপ্লোরার" },
  { href: "#patterns", label: "প্যাটার্ন লাইব্রেরি" },
  { href: "#faq", label: "সমাধান" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed top-0 inset-x-0 z-50 border-b border-white/[0.06] bg-[#06090e]/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <div className="h-16 flex items-center justify-between gap-4">
          <a href="#top" className="flex items-center gap-3 shrink-0">
            <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400/25 to-cyan-400/10 border border-emerald-400/30 flex items-center justify-center">
              <ChartCandlestick className="w-5 h-5 text-emerald-400" strokeWidth={2.2} />
            </span>
            <span className="font-display font-bold text-lg tracking-tight text-white">
              TradeLens<span className="text-emerald-400"> AI</span>
            </span>
            <span className="hidden sm:inline-block text-[10px] font-mono uppercase tracking-[0.18em] text-slate-500 border border-white/10 rounded-full px-2.5 py-1">
              Android Guide
            </span>
          </a>

          <nav className="hidden lg:flex items-center gap-1">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-[13.5px] text-slate-400 hover:text-emerald-300 px-3 py-2 rounded-lg hover:bg-white/[0.04] transition-colors"
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href="#download"
              className="hidden md:inline-flex items-center gap-2 text-[13px] font-semibold text-[#04281b] bg-emerald-400 hover:bg-emerald-300 rounded-full px-4 py-2 transition-colors"
            >
              <Braces className="w-4 h-4" />
              ZIP ডাউনলোড
            </a>
            <button
              onClick={() => setOpen(!open)}
              className="lg:hidden w-10 h-10 rounded-xl border border-white/10 flex items-center justify-center text-slate-300"
              aria-label="মেনু"
            >
              {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="lg:hidden overflow-hidden border-t border-white/[0.06] bg-[#06090e]/95"
          >
            <div className="px-5 py-3 flex flex-col">
              {links.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="py-3 text-[15px] text-slate-300 border-b border-white/[0.04] last:border-0"
                >
                  {l.label}
                </a>
              ))}
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
