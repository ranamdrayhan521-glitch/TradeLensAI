import { Download, FolderArchive, MonitorSmartphone, Smartphone, FileCheck2, PackageOpen } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";
import { toBn } from "../lib/highlight";

const zipContents = [
  "আইকন, রিসোর্স, ম্যানিফেস্টসহ সম্পূর্ণ Gradle প্রজেক্ট",
  "২৩টি সোর্স-ফাইল — হুবহু এই সাইটের কোড",
  "GitHub Actions workflow — পুশ করলেই ক্লাউডে APK তৈরি",
  "Gradle wrapper কনফিগ (jar Android Studio নিজেই বুটস্ট্র্যাপ করে)",
  "READ_ME_FIRST.txt — বাংলা ওপেনিং-নির্দেশনা",
];

export default function DownloadZip() {
  return (
    <section id="download" className="relative py-24 lg:py-28 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHead
          label="Ready-to-Build"
          title="সরাসরি ডাউনলোড করুন — Android Studio প্রজেক্ট (ZIP)"
          desc="কোডুলার বা ব্লক ফাইল নয় — স্ট্যান্ডার্ড Android Studio / Gradle প্রজেক্ট। আনজিপ করে Open দিলেই বিল্ড; AIDE-তেও একই ফোল্ডার খোলা যায়।"
        />

        <Reveal delay={0.1}>
          <div className="mt-12 grid lg:grid-cols-[1.15fr,1fr] gap-6 items-stretch">
            {/* ── ডাউনলোড কার্ড ── */}
            <div className="relative rounded-3xl border border-emerald-400/25 bg-gradient-to-br from-emerald-400/[0.08] via-panel to-panel p-8 lg:p-10 overflow-hidden">
              <div className="absolute -top-24 -right-24 w-72 h-72 rounded-full bg-emerald-400/10 blur-3xl" />
              <div className="relative">
                <div className="flex items-center gap-3 mb-5">
                  <span className="w-12 h-12 rounded-2xl bg-emerald-400/15 border border-emerald-400/30 flex items-center justify-center">
                    <FolderArchive className="w-6 h-6 text-emerald-300" />
                  </span>
                  <div>
                    <div className="font-mono text-[14px] text-white font-semibold">TradeLensAI-Android-Studio.zip</div>
                    <div className="text-[12px] text-slate-500 mt-0.5">v1.0 • ~৪৫ KB • {toBn(26)}টি ফাইল</div>
                  </div>
                </div>

                <ul className="space-y-2.5 mb-8">
                  {zipContents.map((c) => (
                    <li key={c} className="flex gap-2.5 text-[13.5px] text-slate-400">
                      <FileCheck2 className="w-4 h-4 mt-0.5 shrink-0 text-emerald-400" />
                      {c}
                    </li>
                  ))}
                </ul>

                <a
                  href="/TradeLensAI-Android-Studio.zip"
                  download="TradeLensAI-Android-Studio.zip"
                  className="inline-flex items-center gap-3 rounded-full bg-emerald-400 text-[#04281b] font-bold px-8 py-4 text-[15.5px] hover:bg-emerald-300 transition-colors shadow-[0_14px_44px_-10px_rgba(30,209,138,0.55)]"
                >
                  <Download className="w-5 h-5" />
                  ZIP ডাউনলোড করুন
                </a>

                <p className="mt-5 text-[12px] text-slate-600">
                  নিরাপদ সোর্স-কোড আর্কাইভ — কোনো বাইনারি/APK/এক্সিকিউটেবল নেই।
                </p>
              </div>
            </div>

            {/* ── খোলার নির্দেশনা ── */}
            <div className="grid gap-4">
              <div className="rounded-2xl border border-white/[0.08] bg-panel p-6 hover-lift">
                <div className="flex items-center gap-2.5 mb-4">
                  <MonitorSmartphone className="w-5 h-5 text-cyan-300" />
                  <h3 className="font-bold text-white text-[15.5px]">Android Studio (PC)</h3>
                </div>
                <ol className="space-y-2.5 text-[13.5px] leading-relaxed text-slate-400 list-none">
                  <li><span className="text-cyan-300 font-mono">১.</span> ZIP আনজিপ করুন</li>
                  <li><span className="text-cyan-300 font-mono">২.</span> File → Open → <span className="font-mono text-slate-200">TradeLensAI</span> ফোল্ডার সিলেক্ট করুন</li>
                  <li><span className="text-cyan-300 font-mono">৩.</span> Trust → Sync — wrapper-jar IDE নিজেই বুটস্ট্র্যাপ করবে</li>
                  <li><span className="text-cyan-300 font-mono">৪.</span> Run — ফোনে/এমুলেটরে অ্যাপ চালু</li>
                </ol>
              </div>

              <div className="rounded-2xl border border-white/[0.08] bg-panel p-6 hover-lift">
                <div className="flex items-center gap-2.5 mb-4">
                  <Smartphone className="w-5 h-5 text-emerald-300" />
                  <h3 className="font-bold text-white text-[15.5px]">AIDE (মোবাইলে)</h3>
                </div>
                <ol className="space-y-2.5 text-[13.5px] leading-relaxed text-slate-400 list-none">
                  <li><span className="text-emerald-300 font-mono">১.</span> ফোনের ফাইলম্যানেজার/MT Manager দিয়ে ZIP আনজিপ করুন</li>
                  <li><span className="text-emerald-300 font-mono">২.</span> AIDE → Open App Project → <span className="font-mono text-slate-200">TradeLensAI</span> খুলুন</li>
                  <li><span className="text-emerald-300 font-mono">৩.</span> Refresh/Sync করে Run দিন — wrapper লাগে না</li>
                </ol>
              </div>

              <div className="rounded-2xl border border-amber-400/20 bg-amber-400/[0.05] px-5 py-4 flex gap-2.5">
                <PackageOpen className="w-4.5 h-4.5 mt-0.5 shrink-0 text-amber-300" />
                <p className="text-[12.5px] leading-relaxed text-amber-200/80">
                  ফোল্ডার-স্ট্রাকচার ZIP-এর ভেতরে হুবহু নিচের "ফোল্ডার স্ট্রাকচার" সেকশনের মতো — কোনো ফাইল দেখতে সাইটের কোড এক্সপ্লোরার ব্যবহার করতে পারেন।
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
