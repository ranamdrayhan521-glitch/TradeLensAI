import { Lightbulb, FileCode2 } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";
import { setupSteps, fileById } from "../data";

export default function SetupSteps({ onSelect }: { onSelect: (id: string) => void }) {
  return (
    <section id="setup" className="relative py-24 lg:py-32 scroll-mt-16 bg-[#080d13] border-y border-white/[0.05]">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHead
          no="০৪"
          label="AIDE Setup"
          title="AIDE অ্যাপে ধাপে ধাপে প্রজেক্ট তৈরি"
          desc="৮টি ধাপ — কোনো কম্পিউটার লাগবে না, ফোনেই সম্পূর্ণ বিল্ড। প্রতিটি ধাপের নিচে জড়িত ফাইলের চিপ আছে; চিপে ক্লিক করলে সেই ফাইলের কোডে সরাসরি যাবেন।"
        />

        <div className="mt-14 relative">
          <div className="absolute left-[27px] top-4 bottom-4 w-px bg-gradient-to-b from-emerald-400/40 via-cyan-400/20 to-transparent hidden sm:block" />
          <div className="space-y-5">
            {setupSteps.map((s, i) => (
              <Reveal key={s.no} delay={i * 0.04}>
                <div className="relative flex gap-5">
                  <div className="hidden sm:flex w-14 shrink-0 justify-center">
                    <span className="w-14 h-14 rounded-2xl border border-emerald-400/25 bg-panel flex items-center justify-center font-display font-bold text-xl text-emerald-300 z-10">
                      {s.no}
                    </span>
                  </div>
                  <div className="flex-1 rounded-2xl border border-white/[0.08] bg-panel p-6 hover-lift">
                    <div className="flex items-center gap-3 mb-3">
                      <span className="sm:hidden font-display font-bold text-lg text-emerald-300">{s.no}।</span>
                      <h3 className="text-lg font-bold text-white">{s.title}</h3>
                    </div>
                    <p className="text-[14.5px] leading-relaxed text-slate-400">{s.desc}</p>

                    {s.fileIds.length > 0 && (
                      <div className="mt-4 flex flex-wrap gap-2">
                        {s.fileIds.map((id) => {
                          const f = fileById.get(id);
                          if (!f) return null;
                          return (
                            <button
                              key={id}
                              onClick={() => onSelect(id)}
                              className="inline-flex items-center gap-1.5 text-[12px] font-mono text-cyan-300 border border-cyan-400/25 bg-cyan-400/[0.06] hover:bg-cyan-400/[0.14] rounded-full px-3 py-1.5 transition-colors"
                            >
                              <FileCode2 className="w-3.5 h-3.5" />
                              {f.file}
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {s.tip && (
                      <div className="mt-4 flex gap-2.5 rounded-xl border border-amber-400/20 bg-amber-400/[0.05] px-4 py-3">
                        <Lightbulb className="w-4 h-4 mt-0.5 shrink-0 text-amber-300" />
                        <p className="text-[13px] leading-relaxed text-amber-200/85">{s.tip}</p>
                      </div>
                    )}
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
