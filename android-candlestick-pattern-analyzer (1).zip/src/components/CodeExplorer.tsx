import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Wrench,
  FileCog,
  Smartphone,
  ScanSearch,
  Layers,
  Crosshair,
  BrainCircuit,
  FileCode2,
  Copy,
  Check,
  MapPin,
  ChevronLeft,
  ChevronRight,
  FolderTree,
} from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";
import CodeBlock from "./CodeBlock";
import { allFiles, groups } from "../data";
import { toBn } from "../lib/highlight";

const groupIcons: Record<string, typeof Wrench> = {
  wrench: Wrench,
  "file-cog": FileCog,
  smartphone: Smartphone,
  scan: ScanSearch,
  layers: Layers,
  crosshair: Crosshair,
  brain: BrainCircuit,
};

function useCopy() {
  const [copied, setCopied] = useState<string | null>(null);
  const copy = async (text: string, key: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(key);
    setTimeout(() => setCopied(null), 1800);
  };
  return { copied, copy };
}

export default function CodeExplorer({
  selectedId,
  onSelect,
}: {
  selectedId: string;
  onSelect: (id: string) => void;
}) {
  const file = allFiles.find((f) => f.id === selectedId) ?? allFiles[0];
  const idx = allFiles.findIndex((f) => f.id === file.id);
  const { copied, copy } = useCopy();

  const lineCount = useMemo(() => file.code.split("\n").length, [file]);

  return (
    <section id="code" className="relative py-24 lg:py-32 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <SectionHead
          no="০৫"
          label="Code Explorer"
          title={`সম্পূর্ণ কোড — ${toBn(allFiles.length)}টি ফাইল, প্রতিটির স্থান-নির্দেশনাসহ`}
          desc="প্রতিটি ফাইলের উপরে দেখুন 'কোথায় রাখবেন' বক্স — AIDE-তে ঠিক সেই পদ্ধতিতে ফাইল বানিয়ে কোড কপি করে বসান। কোনো ফাইল বাদ গেলে import error আসবে, তাই ক্রম অনুযায়ী বসান।"
        />

        <Reveal delay={0.1}>
          <div className="mt-12 grid lg:grid-cols-[330px,1fr] gap-5 items-start">
            {/* ── ফাইল তালিকা ── */}
            <div className="rounded-2xl border border-white/[0.08] bg-panel overflow-hidden lg:sticky lg:top-24">
              <div className="px-5 py-3.5 border-b border-white/[0.06] bg-white/[0.02] flex items-center gap-2">
                <FolderTree className="w-4 h-4 text-emerald-400" />
                <span className="text-[13px] font-semibold text-slate-200">প্রজেক্ট ফাইলসমূহ</span>
                <span className="ml-auto text-[11px] font-mono text-slate-600">{toBn(allFiles.length)}টি</span>
              </div>
              <div className="max-h-[60vh] lg:max-h-[calc(100vh-260px)] overflow-y-auto thin-scroll p-2.5">
                {groups.map((g) => {
                  const GIcon = groupIcons[g.icon] ?? FileCode2;
                  const gf = allFiles.filter((f) => f.group === g.id);
                  return (
                    <div key={g.id} className="mb-3">
                      <div className="flex items-center gap-2 px-2.5 py-2 text-[11px] font-mono uppercase tracking-[0.14em] text-slate-500">
                        <GIcon className="w-3.5 h-3.5 text-emerald-500/80" />
                        {g.title}
                      </div>
                      {gf.map((f) => {
                        const active = f.id === file.id;
                        return (
                          <button
                            key={f.id}
                            onClick={() => onSelect(f.id)}
                            className={
                              "w-full text-left flex items-center gap-2.5 rounded-xl px-3 py-2.5 transition-colors " +
                              (active
                                ? "bg-emerald-400/[0.1] border border-emerald-400/25"
                                : "border border-transparent hover:bg-white/[0.04]")
                            }
                          >
                            <FileCode2 className={"w-4 h-4 shrink-0 " + (active ? "text-emerald-400" : "text-slate-500")} />
                            <span className="min-w-0">
                              <span className={"block font-mono text-[12.5px] truncate " + (active ? "text-emerald-200" : "text-slate-300")}>
                                {f.file}
                              </span>
                              <span className="block text-[11px] text-slate-600 truncate">{f.desc.slice(0, 34)}…</span>
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ── ভিউয়ার ── */}
            <div className="rounded-2xl border border-white/[0.08] bg-panel overflow-hidden min-w-0">
              <div className="px-5 py-4 border-b border-white/[0.06] bg-white/[0.02]">
                <div className="flex items-center gap-3 flex-wrap">
                  <span className="font-mono font-semibold text-[15px] text-white">{file.file}</span>
                  <span className="text-[10.5px] font-mono uppercase tracking-[0.14em] text-cyan-300 border border-cyan-400/25 bg-cyan-400/[0.07] rounded-full px-2.5 py-1">
                    {file.lang}
                  </span>
                  <span className="text-[11px] font-mono text-slate-600">{toBn(lineCount)} লাইন</span>
                  <div className="ml-auto flex items-center gap-2">
                    <button
                      onClick={() => copy(file.path, "path")}
                      className="inline-flex items-center gap-1.5 text-[11.5px] font-mono text-slate-400 hover:text-white border border-white/10 rounded-lg px-2.5 py-1.5 transition-colors"
                      title="পাথ কপি"
                    >
                      {copied === "path" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      পাথ
                    </button>
                    <button
                      onClick={() => copy(file.code, "code")}
                      className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-[#04281b] bg-emerald-400 hover:bg-emerald-300 rounded-lg px-3.5 py-1.5 transition-colors"
                    >
                      {copied === "code" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copied === "code" ? "কপি হয়েছে" : "কোড কপি"}
                    </button>
                  </div>
                </div>
                <div className="mt-2.5 font-mono text-[11.5px] text-slate-500 break-all">
                  {file.path}
                </div>
              </div>

              <div className="px-5 py-4 border-b border-white/[0.06] space-y-3 bg-white/[0.01]">
                <p className="text-[13.5px] leading-relaxed text-slate-400">{file.desc}</p>
                <div className="flex gap-2.5 rounded-xl border border-cyan-400/20 bg-cyan-400/[0.05] px-4 py-3">
                  <MapPin className="w-4 h-4 mt-0.5 shrink-0 text-cyan-300" />
                  <p className="text-[13px] leading-relaxed text-cyan-100/85">
                    <span className="font-semibold text-cyan-300">কোথায় রাখবেন: </span>
                    {file.place}
                  </p>
                </div>
              </div>

              <div className="max-h-[72vh] overflow-auto code-scroll">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={file.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.18 }}
                  >
                    <CodeBlock code={file.code} lang={file.lang} />
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="px-5 py-3.5 border-t border-white/[0.06] bg-white/[0.02] flex items-center justify-between">
                <button
                  disabled={idx === 0}
                  onClick={() => onSelect(allFiles[idx - 1].id)}
                  className="inline-flex items-center gap-1.5 text-[13px] text-slate-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" /> আগের ফাইল
                </button>
                <span className="text-[11.5px] font-mono text-slate-600">
                  {toBn(idx + 1)} / {toBn(allFiles.length)}
                </span>
                <button
                  disabled={idx === allFiles.length - 1}
                  onClick={() => onSelect(allFiles[idx + 1].id)}
                  className="inline-flex items-center gap-1.5 text-[13px] text-slate-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-colors"
                >
                  পরের ফাইল <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
