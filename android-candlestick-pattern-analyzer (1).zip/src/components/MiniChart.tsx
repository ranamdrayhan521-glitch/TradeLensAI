import type { MiniCandle } from "../lib/patterns";

const BULL = "#1ed18a";
const BEAR = "#ff5c6c";

export default function MiniChart({
  candles,
  width = 150,
  height = 96,
}: {
  candles: MiniCandle[];
  width?: number;
  height?: number;
}) {
  const all = candles;
  const hi = Math.max(...all.map((k) => k.h));
  const lo = Math.min(...all.map((k) => k.l));
  const span = hi - lo || 1;
  const padT = 6;
  const padB = 6;
  const innerH = height - padT - padB;
  const slot = width / all.length;
  const bodyW = Math.max(3, slot * 0.52);

  const y = (v: number) => padT + ((hi - v) / span) * innerH;

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className="w-full h-auto"
      style={{ display: "block" }}
    >
      {[0.25, 0.5, 0.75].map((f) => (
        <line
          key={f}
          x1={0}
          x2={width}
          y1={padT + innerH * f}
          y2={padT + innerH * f}
          stroke="rgba(140,180,255,0.08)"
          strokeDasharray="2 4"
        />
      ))}
      {all.map((k, i) => {
        const cx = slot * i + slot / 2;
        const bull = k.c >= k.o;
        const color = bull ? BULL : BEAR;
        const top = y(Math.max(k.o, k.c));
        const bot = y(Math.min(k.o, k.c));
        const h = Math.max(1.5, bot - top);
        const op = k.ctx ? 0.32 : 1;
        return (
          <g key={i} opacity={op}>
            <line
              x1={cx}
              x2={cx}
              y1={y(k.h)}
              y2={y(k.l)}
              stroke={color}
              strokeWidth={1.3}
            />
            <rect
              x={cx - bodyW / 2}
              y={top}
              width={bodyW}
              height={h}
              rx={1.2}
              fill={color}
            />
          </g>
        );
      })}
    </svg>
  );
}
