import { useMemo } from "react";
import { tokenize, toLines } from "../lib/highlight";
import type { Lang } from "../data/types";

const colorMap: Record<string, string> = {
  kw: "text-violet-300",
  str: "text-emerald-300",
  com: "text-slate-500 italic",
  num: "text-amber-300",
  type: "text-cyan-300",
  fn: "text-sky-300",
  ann: "text-pink-400",
  tag: "text-rose-400",
  attr: "text-cyan-200",
  op: "text-slate-400",
  plain: "text-slate-300",
};

export default function CodeBlock({ code, lang }: { code: string; lang: Lang }) {
  const lines = useMemo(() => toLines(tokenize(code, lang)), [code, lang]);

  return (
    <div className="code-scroll overflow-auto text-[12.5px] leading-[1.65] font-mono">
      <table className="w-full border-collapse">
        <tbody>
          {lines.map((toks, i) => (
            <tr key={i} className="hover:bg-white/[0.025]">
              <td className="sticky left-0 select-none bg-[#0a0f16] pr-4 pl-4 text-right align-top text-slate-600 w-[52px] min-w-[52px] border-r border-white/[0.05]">
                {i + 1}
              </td>
              <td className="pl-4 pr-6 whitespace-pre align-top">
                {toks.length === 0 ? (
                  <span> </span>
                ) : (
                  toks.map((t, j) => (
                    <span key={j} className={colorMap[t.t]}>
                      {t.s}
                    </span>
                  ))
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
