import Reveal from "./Reveal";

export default function SectionHead({
  no,
  label,
  title,
  desc,
}: {
  no?: string;
  label: string;
  title: string;
  desc?: string;
}) {
  return (
    <Reveal>
      <div className="max-w-3xl">
        <div className="flex items-center gap-4 mb-5">
          {no && <span className="font-display font-bold text-sm text-emerald-400/90 tracking-widest">{no}</span>}
          <span className="h-px w-14 bg-gradient-to-r from-emerald-400/60 to-transparent" />
          <span className="text-[11px] font-mono uppercase tracking-[0.22em] text-slate-500">{label}</span>
        </div>
        <h2 className="text-3xl sm:text-4xl lg:text-[42px] font-bold text-white leading-[1.15] tracking-tight">
          {title}
        </h2>
        {desc && <p className="mt-5 text-[16px] leading-relaxed text-slate-400">{desc}</p>}
      </div>
    </Reveal>
  );
}
