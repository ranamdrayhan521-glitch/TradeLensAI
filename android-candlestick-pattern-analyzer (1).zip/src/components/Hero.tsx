import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowDown, FolderCode, Play, ScanLine, ShieldCheck, Timer } from "lucide-react";
import { toBn } from "../lib/highlight";

/* ─── হিরো ক্যানভাস: জেনারেটেড ক্যান্ডেল + লাইভ JS প্যাটার্ন-ডিটেক্টর ─── */

interface KCandle { o: number; h: number; l: number; c: number }
interface Marker { from: number; count: number; label: string; bull: boolean; born: number }

function randn() {
  return (Math.random() + Math.random() + Math.random() - 1.5) / 0.868;
}

function detectPattern(cs: KCandle[]): { label: string; bull: boolean; back: number } | null {
  const n = cs.length;
  if (n < 3) return null;
  const body = (k: KCandle) => Math.abs(k.c - k.o);
  const a = cs[n - 2];
  const b = cs[n - 1];

  // এনগালফিং
  if (a.c < a.o && b.c > b.o && b.o <= a.c && b.c >= a.o && body(b) > body(a) * 1.1)
    return { label: "বুলিশ এনগালফিং", bull: true, back: 2 };
  if (a.c > a.o && b.c < b.o && b.o >= a.c && b.c <= a.o && body(b) > body(a) * 1.1)
    return { label: "বিয়ারিশ এনগালফিং", bull: false, back: 2 };

  // হাতুড়ে
  const lw = Math.min(b.o, b.c) - b.l;
  const uw = b.h - Math.max(b.o, b.c);
  if (body(b) > 0.05 && lw > body(b) * 2.4 && uw < body(b) * 0.6)
    return { label: "হাতুড়ে (Hammer)", bull: true, back: 1 };
  if (body(b) > 0.05 && uw > body(b) * 2.4 && lw < body(b) * 0.6)
    return { label: "শুটিং স্টার", bull: false, back: 1 };

  // তিন সোলজার্স / ক্রো
  const c2 = cs[n - 3];
  if (c2.c > c2.o && a.c > a.o && b.c > b.o && b.c > a.c && a.c > c2.c)
    return { label: "থ্রি হোয়াইট সোলজার্স", bull: true, back: 3 };
  if (c2.c < c2.o && a.c < a.o && b.c < b.o && b.c < a.c && a.c < c2.c)
    return { label: "থ্রি ব্ল্যাক ক্রো", bull: false, back: 3 };

  // দোজি
  if (b.h - b.l > 0.1 && body(b) < (b.h - b.l) * 0.12)
    return { label: "দোজি — সিদ্ধান্তহীনতা", bull: true, back: 1 };

  return null;
}

function HeroCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let W = 0;
    let H = 0;
    let raf = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const candles: KCandle[] = [];
    let last = 100;
    let markers: Marker[] = [];
    let cooldown = 0;
    let acc = 0;
    let prevT = performance.now();
    const CANDLE_MS = 130;
    const BULL = "rgba(30,209,138,";
    const BEAR = "rgba(255,92,108,";

    function pushCandle() {
      const o = last;
      const drift = randn() * 1.35;
      const c = Math.max(2, o + drift);
      const h = Math.max(o, c) + Math.abs(randn()) * 0.55;
      const l = Math.min(o, c) - Math.abs(randn()) * 0.55;
      candles.push({ o, h, l, c });
      last = c;

      cooldown--;
      const d = cooldown <= 0 ? detectPattern(candles) : null;
      if (d) {
        markers.push({
          from: candles.length - d.back,
          count: d.back,
          label: d.label,
          bull: d.bull,
          born: performance.now(),
        });
        cooldown = 34;
        if (markers.length > 6) markers = markers.slice(-6);
      }
    }

    for (let i = 0; i < 140; i++) pushCandle();

    function resize() {
      if (!canvas || !ctx) return;
      W = canvas.clientWidth;
      H = canvas.clientHeight;
      canvas.width = W * dpr;
      canvas.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    window.addEventListener("resize", resize);

    function frame(t: number) {
      const dt = t - prevT;
      prevT = t;
      acc += dt;
      if (acc > CANDLE_MS) {
        acc = 0;
        pushCandle();
      }

      ctx!.clearRect(0, 0, W, H);

      const cw = 14;
      const padR = 24;
      const visible = Math.ceil((W - padR) / cw) + 2;
      const start = Math.max(0, candles.length - visible);
      const view = candles.slice(start);

      let hi = -Infinity;
      let lo = Infinity;
      for (const k of view) {
        hi = Math.max(hi, k.h);
        lo = Math.min(lo, k.l);
      }
      const pad = (hi - lo) * 0.12 + 0.001;
      hi += pad;
      lo -= pad;
      const y = (v: number) => 20 + ((hi - v) / (hi - lo)) * (H - 48);

      // গ্রিড
      ctx!.strokeStyle = "rgba(120,170,255,0.06)";
      ctx!.lineWidth = 1;
      for (let i = 1; i < 5; i++) {
        const gy = (H / 5) * i;
        ctx!.beginPath();
        ctx!.moveTo(0, gy);
        ctx!.lineTo(W, gy);
        ctx!.stroke();
      }

      // EMA-9 লাইন
      let ema = view[0]?.c ?? 0;
      ctx!.beginPath();
      ctx!.strokeStyle = "rgba(79,216,255,0.4)";
      ctx!.lineWidth = 1.4;
      view.forEach((k, i) => {
        ema = ema * 0.82 + k.c * 0.18;
        const x = i * cw + cw / 2;
        if (i === 0) ctx!.moveTo(x, y(ema));
        else ctx!.lineTo(x, y(ema));
      });
      ctx!.stroke();

      // ক্যান্ডেল
      view.forEach((k, i) => {
        const x = i * cw + cw / 2;
        const bull = k.c >= k.o;
        const col = bull ? BULL : BEAR;
        ctx!.strokeStyle = col + "0.9)";
        ctx!.lineWidth = 1.2;
        ctx!.beginPath();
        ctx!.moveTo(x, y(k.h));
        ctx!.lineTo(x, y(k.l));
        ctx!.stroke();
        const top = y(Math.max(k.o, k.c));
        const bot = y(Math.min(k.o, k.c));
        ctx!.fillStyle = col + "0.85)";
        const bw = cw * 0.58;
        ctx!.beginPath();
        ctx!.roundRect(x - bw / 2, top, bw, Math.max(1.6, bot - top), 2);
        ctx!.fill();
      });

      // মার্কার (প্যাটার্ন হাইলাইট)
      const now = performance.now();
      markers = markers.filter((m) => now - m.born < 6200);
      for (const m of markers) {
        const age = now - m.born;
        const alpha = age < 5200 ? 1 : 1 - (age - 5200) / 1000;
        const i0 = m.from - start;
        if (i0 < -3) continue;
        const seg = view.slice(Math.max(0, i0), Math.max(0, i0) + m.count);
        if (seg.length === 0) continue;
        let mh = -Infinity;
        let ml = Infinity;
        for (const k of seg) {
          mh = Math.max(mh, k.h);
          ml = Math.min(ml, k.l);
        }
        const x0 = Math.max(0, i0) * cw - 4;
        const x1 = (Math.max(0, i0) + m.count) * cw + 4;
        const y0 = y(mh) - 8;
        const y1 = y(ml) + 8;
        const col = m.bull ? "30,209,138" : "255,92,108";
        const pulse = 0.75 + Math.sin(now / 260) * 0.25;

        ctx!.strokeStyle = `rgba(${col},${(alpha * pulse).toFixed(3)})`;
        ctx!.lineWidth = 1.6;
        ctx!.beginPath();
        ctx!.roundRect(x0, y0, x1 - x0, y1 - y0, 7);
        ctx!.stroke();
        ctx!.fillStyle = `rgba(${col},${(alpha * 0.07).toFixed(3)})`;
        ctx!.fill();

        // লেবেল পিল
        const label = m.label;
        ctx!.font = '600 11px "Hind Siliguri", sans-serif';
        const tw = ctx!.measureText(label).width;
        const pw = tw + 22;
        const ph = 21;
        const px = Math.min(Math.max(6, x0), W - pw - 6);
        const py = Math.max(8, y0 - ph - 7);
        ctx!.fillStyle = `rgba(8,13,20,${(alpha * 0.94).toFixed(3)})`;
        ctx!.strokeStyle = `rgba(${col},${(alpha * 0.7).toFixed(3)})`;
        ctx!.lineWidth = 1;
        ctx!.beginPath();
        ctx!.roundRect(px, py, pw, ph, ph / 2);
        ctx!.fill();
        ctx!.stroke();
        ctx!.fillStyle = `rgba(235,245,255,${alpha.toFixed(3)})`;
        ctx!.fillText(label, px + 11, py + 14.5);
      }

      // স্ক্যানলাইন
      const sx = ((t / 42) % (W + 160)) - 80;
      const grad = ctx!.createLinearGradient(sx - 50, 0, sx + 50, 0);
      grad.addColorStop(0, "rgba(79,216,255,0)");
      grad.addColorStop(0.5, "rgba(79,216,255,0.08)");
      grad.addColorStop(1, "rgba(79,216,255,0)");
      ctx!.fillStyle = grad;
      ctx!.fillRect(sx - 50, 0, 100, H);
      ctx!.strokeStyle = "rgba(79,216,255,0.30)";
      ctx!.beginPath();
      ctx!.moveTo(sx, 0);
      ctx!.lineTo(sx, H);
      ctx!.stroke();

      raf = requestAnimationFrame(frame);
    }
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={ref} className="absolute inset-0 w-full h-full" />;
}

/* ─── হিরো UI ─── */

const chipSamples = [
  { name: "বুলিশ এনগালফিং", conf: 87, sig: "ক্রয়" },
  { name: "মর্নিং স্টার", conf: 82, sig: "ক্রয়" },
  { name: "ইভিনিং স্টার", conf: 79, sig: "বিক্রয়" },
  { name: "হাতুড়ে", conf: 74, sig: "ক্রয়" },
  { name: "থ্রি সোলজার্স", conf: 91, sig: "শক্তিশালী ক্রয়" },
  { name: "শুটিং স্টার", conf: 76, sig: "বিক্রয়" },
];

function LiveChipMock() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % chipSamples.length), 2200);
    return () => clearInterval(t);
  }, []);
  const s = chipSamples[i];
  const sell = s.sig.includes("বিক্রয়");
  return (
    <div className="inline-flex items-center gap-2.5 rounded-full border border-emerald-400/25 bg-[#0b1119]/90 pl-3 pr-4 py-2 shadow-[0_10px_40px_-12px_rgba(0,0,0,0.8)]">
      <span className={`w-2.5 h-2.5 rounded-full pulse-dot ${sell ? "bg-rose-400" : "bg-emerald-400"}`} />
      <span className="text-[13px] text-slate-200">
        {s.name} <span className="text-cyan-300 font-mono">{toBn(s.conf)}%</span>
      </span>
      <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${sell ? "bg-rose-500/15 text-rose-300" : "bg-emerald-500/15 text-emerald-300"}`}>
        {s.sig}
      </span>
    </div>
  );
}

export default function Hero() {
  return (
    <section id="top" className="relative min-h-[100svh] flex items-center overflow-hidden bg-ink">
      <div className="absolute inset-0 bg-grid opacity-60" />
      <HeroCanvas />
      <div className="absolute inset-0 bg-gradient-to-r from-[#06090e] via-[#06090e]/82 to-[#06090e]/25" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#06090e] to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-8 pt-28 pb-20 w-full">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-3xl"
        >
          <div className="flex items-center gap-2 flex-wrap mb-7">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-mono uppercase tracking-[0.16em] text-emerald-300 border border-emerald-400/25 bg-emerald-400/[0.06] rounded-full px-3 py-1.5">
              <ScanLine className="w-3.5 h-3.5" /> MediaProjection API
            </span>
            <span className="inline-flex items-center gap-1.5 text-[11px] font-mono uppercase tracking-[0.16em] text-cyan-300 border border-cyan-400/25 bg-cyan-400/[0.06] rounded-full px-3 py-1.5">
              <Timer className="w-3.5 h-3.5" /> Floating Overlay
            </span>
            <span className="inline-flex items-center gap-1.5 text-[11px] font-mono uppercase tracking-[0.16em] text-amber-300 border border-amber-400/25 bg-amber-400/[0.06] rounded-full px-3 py-1.5">
              <ShieldCheck className="w-3.5 h-3.5" /> ১০০% বৈধ ও অন-ডিভাইস
            </span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-[64px] font-bold leading-[1.08] tracking-tight text-white mb-6">
            আপনার স্ক্রিনেই
            <br />
            <span className="text-grad">লাইভ ক্যান্ডেল-বিশ্লেষণ।</span>
          </h1>

          <p className="text-lg text-slate-400 leading-relaxed max-w-xl mb-5">
            MediaProjection দিয়ে স্ক্রিন ক্যাপচার, ভাসমান ওভারলেতে সরাসরি সিগন্যাল,
            এবং <span className="text-slate-200 font-semibold">{toBn(44)}টি প্যাটার্ন-নিয়মের</span> সম্পূর্ণ
            ইঞ্জিন — নিচে আর্কিটেকচার, ফোল্ডার স্ট্রাকচার এবং AIDE-তে বসানোর মতো
            <span className="text-emerald-300"> প্রতিটি ফাইলের পুরো কোড</span> দেওয়া আছে।
          </p>

          <div className="mb-10">
            <LiveChipMock />
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <a
              href="#code"
              className="inline-flex items-center gap-2.5 rounded-full bg-emerald-400 text-[#04281b] font-bold px-7 py-3.5 text-[15px] hover:bg-emerald-300 transition-colors shadow-[0_12px_40px_-10px_rgba(30,209,138,0.55)]"
            >
              <FolderCode className="w-5 h-5" />
              কোড এক্সপ্লোরার খুলুন
            </a>
            <a
              href="#setup"
              className="inline-flex items-center gap-2.5 rounded-full border border-white/15 text-slate-200 font-semibold px-7 py-3.5 text-[15px] hover:bg-white/[0.05] transition-colors"
            >
              <Play className="w-4.5 h-4.5 text-cyan-300" />
              AIDE সেটআপ শুরু করুন
            </a>
          </div>

          <div className="mt-14 grid grid-cols-3 max-w-md gap-6">
            {[
              { n: "৫", l: "আর্কিটেকচার স্তর" },
              { n: "৪৪", l: "প্যাটার্ন-নিয়ম" },
              { n: "২৩", l: "সম্পূর্ণ ফাইল" },
            ].map((s) => (
              <div key={s.l}>
                <div className="text-3xl font-bold font-display text-white">{s.n}</div>
                <div className="text-[13px] text-slate-500 mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      <motion.a
        href="#architecture"
        aria-label="নিচে যান"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-7 left-1/2 -translate-x-1/2 z-10 w-11 h-11 rounded-full border border-white/12 flex items-center justify-center text-slate-400 hover:text-emerald-300 hover:border-emerald-400/30 transition-colors"
      >
        <motion.span animate={{ y: [0, 5, 0] }} transition={{ repeat: Infinity, duration: 1.6 }}>
          <ArrowDown className="w-5 h-5" />
        </motion.span>
      </motion.a>
    </section>
  );
}
