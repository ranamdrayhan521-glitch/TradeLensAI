import { ChartCandlestick, ShieldCheck, AlertTriangle } from "lucide-react";

export default function Footer() {
  return (
    <footer id="legal" className="relative border-t border-white/[0.06] bg-[#05080c]">
      <div className="max-w-7xl mx-auto px-5 lg:px-8 py-14">
        <div className="grid md:grid-cols-[1.2fr,1fr,1fr] gap-10 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400/25 to-cyan-400/10 border border-emerald-400/30 flex items-center justify-center">
                <ChartCandlestick className="w-5 h-5 text-emerald-400" />
              </span>
              <span className="font-display font-bold text-lg text-white">
                TradeLens<span className="text-emerald-400"> AI</span>
              </span>
            </div>
            <p className="text-[13.5px] leading-relaxed text-slate-500 max-w-sm">
              MediaProjection স্ক্রিন-বিশ্লেষণ, ফ্লোটিং ওভারলে এবং ৪৪-নিয়মের ক্যান্ডেলস্টিক
              প্যাটার্ন-ইঞ্জিনসহ সম্পূর্ণ Android ট্রেডিং অ্যাসিস্ট্যান্টের উন্মুক্ত আর্কিটেকচার ও কোড-গাইড।
            </p>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-4 text-emerald-300">
              <ShieldCheck className="w-4.5 h-4.5" />
              <span className="text-[13px] font-semibold uppercase tracking-wider">বৈধতা ও নিরাপত্তা</span>
            </div>
            <ul className="space-y-2.5 text-[13px] leading-relaxed text-slate-500">
              <li>• ক্যাপচার শুধু ব্যবহারকারীর স্পষ্ট অনুমতিতে, প্রতি সেশনে নতুন করে।</li>
              <li>• কোনো ব্রোকার অ্যাপের ভেতরের ডেটা/API/মেমরি স্পর্শ করে না।</li>
              <li>• সব বিশ্লেষণ ১০০% অন-ডিভাইস — কোনো ছবি বা ডেটা কোথাও পাঠায় না।</li>
              <li>• কোনো স্বয়ংক্রিয় ট্রেড নেই; সিদ্ধান্ত সম্পূর্ণ ব্যবহারকারীর।</li>
            </ul>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-4 text-amber-300">
              <AlertTriangle className="w-4.5 h-4.5" />
              <span className="text-[13px] font-semibold uppercase tracking-wider">ঝুঁকি সতর্কতা</span>
            </div>
            <ul className="space-y-2.5 text-[13px] leading-relaxed text-slate-500">
              <li>• এটি শিক্ষামূলক বিশ্লেষণ-সহায়ক, আর্থিক পরামর্শ নয়।</li>
              <li>• ক্যান্ডেল-প্যাটার্ন সম্ভাবনার ইঙ্গিত দেয়, নিশ্চয়তা নয়।</li>
              <li>• ট্রেডিংয়ে মূলধন হারানোর উল্লেখযোগ্য ঝুঁকি আছে — নিজ গবেষণা করুন।</li>
              <li>• লো-ভলাটিলিটি/অগভীর চার্টে সংকেত কম নির্ভরযোগ্য হয়।</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/[0.05] pt-6 flex flex-wrap items-center justify-between gap-3">
          <span className="text-[12px] font-mono text-slate-600">TradeLens AI — Open Architecture &amp; Code Guide</span>
          <span className="text-[12px] text-slate-600">Kotlin • MediaProjection • WindowManager • Canvas</span>
        </div>
      </div>
    </footer>
  );
}
