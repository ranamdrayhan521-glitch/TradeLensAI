import { useCallback, useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Ticker from "./components/Ticker";
import DownloadZip from "./components/DownloadZip";
import OneClickApk from "./components/OneClickApk";
import Architecture from "./components/Architecture";
import CaptureFix from "./components/CaptureFix";
import FolderTree from "./components/FolderTree";
import SetupSteps from "./components/SetupSteps";
import CodeExplorer from "./components/CodeExplorer";
import PatternLibrary from "./components/PatternLibrary";
import Faq from "./components/Faq";
import Footer from "./components/Footer";

export default function App() {
  const [selectedFile, setSelectedFile] = useState("capture-service");

  const selectFile = useCallback((id: string) => {
    setSelectedFile(id);
    const el = document.getElementById("code");
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  return (
    <div className="noise min-h-screen bg-ink text-slate-200 font-bengali antialiased">
      <Navbar />
      <main>
        <Hero />
        <Ticker />
        <DownloadZip />
        <OneClickApk />
        <Architecture />
        <CaptureFix />
        <FolderTree onSelect={selectFile} active={selectedFile} />
        <SetupSteps onSelect={selectFile} />
        <CodeExplorer selectedId={selectedFile} onSelect={setSelectedFile} />
        <PatternLibrary />
        <Faq />
      </main>
      <Footer />
    </div>
  );
}
