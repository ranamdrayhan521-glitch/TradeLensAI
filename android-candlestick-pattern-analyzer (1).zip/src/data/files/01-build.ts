import type { FileDoc } from "../types";

export const buildFiles: FileDoc[] = [
  {
    id: "settings-gradle",
    file: "settings.gradle",
    path: "TradeLensAI/settings.gradle",
    lang: "groovy",
    group: "build",
    desc: "প্রজেক্টের নাম, মডিউল তালিকা ও রিপোজিটরি কনফিগারেশন। AIDE-তে repositoriesMode কে PREFER_SETTINGS রাখা হয়েছে যাতে ডিপেন্ডেন্সি ডাউনলোডে সমস্যা না হয়।",
    place: "AIDE প্রজেক্ট তৈরির পর রুট ফোল্ডারে (app ফোল্ডারের বাইরে) থাকা settings.gradle ফাইলটি খুলে পুরোটা বদলে দিন।",
    code: `// ═══════════════════════════════════════════════════════════
//  TradeLensAI — প্রজেক্ট সেটিংস
//  AIDE-তে ডিপেন্ডেন্সি সিঙ্ক ঝামেলা এড়াতে PREFER_SETTINGS ব্যবহৃত
// ═══════════════════════════════════════════════════════════
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "TradeLensAI"
include(":app")`,
  },
  {
    id: "root-gradle",
    file: "build.gradle (Project)",
    path: "TradeLensAI/build.gradle",
    lang: "groovy",
    group: "build",
    desc: "রুট-লেভেল প্লাগিন সংস্করণ। AGP 8.1.4 + Kotlin 1.9.24 — AIDE-এর নতুন সংস্করণে (Java 17 সাপোর্টসহ) নিরাপদে বিল্ড হয়।",
    place: "রুট ফোল্ডারের build.gradle ফাইলটি খুলে পুরো বিষয়বস্তু বদলে দিন (Top-level build file)।",
    code: `// ═══════════════════════════════════════════════════════════
//  Top-level build file — শুধু প্লাগিন ভার্সন এখানে ঘোষণা হয়
// ═══════════════════════════════════════════════════════════
plugins {
    id 'com.android.application' version '8.1.4' apply false
    id 'org.jetbrains.kotlin.android' version '1.9.24' apply false
}`,
  },
  {
    id: "app-gradle",
    file: "build.gradle (App)",
    path: "TradeLensAI/app/build.gradle",
    lang: "groovy",
    group: "build",
    desc: "অ্যাপ মডিউলের বিল্ড কনফিগ — SDK লেভেল, Java 17, ডিপেন্ডেন্সি। minSdk 29 রাখা হয়েছে কারণ MediaProjection ফোরগ্রাউন্ড-টাইপ Android 10 (API 29) থেকে বাধ্যতামূলক।",
    place: "app ফোল্ডারের ভিতরের build.gradle খুলে পুরোটা বদলে দিন। package name বদলালে namespace ও applicationId-ও বদলাতে হবে।",
    code: `plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace 'com.tradelens.ai'
    compileSdk 34

    defaultConfig {
        applicationId "com.tradelens.ai"

        // MediaProjection ফোরগ্রাউন্ড-টাইপ API 29 থেকে বাধ্যতামূলক,
        // তাই minSdk = 29 (Android 10+)
        minSdk 29
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }

    buildTypes {
        debug {
            minifyEnabled false
        }
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = '17'
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.13.1'
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'com.google.android.material:material:1.12.0'
    implementation 'androidx.lifecycle:lifecycle-service:2.8.4'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0'

    // ── ঐচ্ছিক (ভবিষ্যৎ আপগ্রেড) ─────────────────────────────
    // প্রাইস-অ্যাক্সিসের সংখ্যা OCR করে আসল দাম পড়তে চাইলে
    // নিচের লাইনটি আনকমেন্ট করুন। প্যাটার্ন বিশ্লেষণের জন্য এটি
    // মোটেও প্রয়োজন নেই (জ্যামিতি-ভিত্তিক বিশ্লেষণ হয়)।
    // implementation 'com.google.mlkit:text-recognition:16.0.0'
}`,
  },
  {
    id: "gradle-props",
    file: "gradle.properties",
    path: "TradeLensAI/gradle.properties",
    lang: "text",
    group: "build",
    desc: "Gradle মেমরি ও AndroidX সেটিংস। AIDE সাধারণত এটি নিজেই বানিয়ে দেয় — তবু AndroidX লাইনগুলো আছে কিনা যাচাই করুন।",
    place: "রুট ফোল্ডারে gradle.properties থাকলে লাইনগুলো মিলিয়ে নিন, না থাকলে নতুন ফাইল বানান।",
    code: `# Gradle JVM মেমরি (AIDE-তে 2GB-এর বেশি দেবেন না)
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8

# AndroidX বাধ্যতামূলক — আমাদের সব ডিপেন্ডেন্সি AndroidX-ভিত্তিক
android.useAndroidX=true
android.nonTransitiveRClass=true

kotlin.code.style=official`,
  },
  {
    id: "proguard",
    file: "proguard-rules.pro",
    path: "TradeLensAI/app/proguard-rules.pro",
    lang: "text",
    group: "build",
    desc: "ProGuard নিয়ম-ফাইল। minifyEnabled=false রাখায় বিষয়বস্তু প্রায় খালি, তবে app/build.gradle এটি রেফারেন্স করে — ফাইলটি না থাকলে বিল্ড error দেবে।",
    place: "app ফোল্ডারে (app/build.gradle-এর পাশে) proguard-rules.pro নামে ফাইল বানান। AIDE সাধারণত নিজেই বানিয়ে দেয়।",
    code: `# ProGuard / R8 নিয়ম — এই প্রজেক্টে minify বন্ধ (minifyEnabled false),
# তাই ফাইলটি আগামীর জন্য খালি রাখা নিরাপদ।
# ভবিষ্যতে minify চালু করলে এখানে keep-নিয়ম যোগ করবেন।`,
  },
];
