import type { FileDoc } from "../types";

export const workflowFiles: FileDoc[] = [
  {
    id: "gh-actions",
    file: "android-build.yml",
    path: "TradeLensAI/.github/workflows/android-build.yml",
    lang: "text",
    group: "build",
    desc: "GitHub Actions workflow — রিপোজিটরিতে কোড ঢোকামাত্র ক্লাউডে স্বয়ংক্রিয়ভাবে APK বিল্ড হয়ে Artifacts-এ ডাউনলোডযোগ্য হয়। ফোনের ব্রাউজার থেকেই চালানো যায়; কম্পিউটার, টার্মিনাল বা JDK কিছুই লাগে না। সম্পূর্ণ ফ্রি (পাবলিক রিপোতে আনলিমিটেড)।",
    place: "এই ফাইলটি ZIP-এ আগে থেকেই সঠিক জায়গায় (.github/workflows/) আছে — GitHub-এ আপলোড করলে আলাদা কিছু করতে হবে না। নিজে তৈরি করতে চাইলে রিপোর মূলে .github/workflows/ ফোল্ডার বানিয়ে রাখুন।",
    code: `name: TradeLens AI — APK Build

# রিপোজিটরিতে কোড পুশ করলেই (বা Actions ট্যাবে "Run workflow" চাপলেই)
# ক্লাউডে Android APK বিল্ড হবে — সম্পূর্ণ ফ্রি, কম্পিউটারবিহীন।
on:
  push:
    branches: [main, master]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      # ধাপ ১: আপনার প্রজেক্টের সোর্স নামানো
      - name: সোর্স কোড আনা
        uses: actions/checkout@v4

      # ধাপ ২: Java 17 — AGP 8.1-এর প্রয়োজন
      - name: JDK 17 সেটআপ
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      # ধাপ ৩: Android SDK (compileSdk 34)
      - name: Android SDK সেটআপ
        uses: android-actions/setup-android@v3

      # ধাপ ৪: Gradle 8.2 — wrapper-jar ছাড়াই কাজ করবে
      - name: Gradle সেটআপ
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: "8.2"

      # ধাপ ৫: ডিবাগ APK বিল্ড (স্বয়ংক্রিয় ডিবাগ-সাইন্ড)
      - name: APK বিল্ড
        run: gradle assembleDebug --stacktrace

      # ধাপ ৬: APK আর্টিফ্যাক্ট হিসেবে ডাউনলোডযোগ্য করা
      - name: APK প্রকাশ
        uses: actions/upload-artifact@v4
        with:
          name: TradeLensAI-debug-apk
          path: app/build/outputs/apk/debug/*.apk`,
  },
];
