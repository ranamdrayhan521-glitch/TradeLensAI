import type { FileDoc } from "../types";

export const manifestResFiles: FileDoc[] = [
  {
    id: "manifest",
    file: "AndroidManifest.xml",
    path: "TradeLensAI/app/src/main/AndroidManifest.xml",
    lang: "xml",
    group: "res",
    desc: "অ্যাপের সব পারমিশন ও কম্পোনেন্ট ঘোষণা। FOREGROUND_SERVICE_MEDIA_PROJECTION (Android 14+) এবং service-এ foregroundServiceType=\"mediaProjection\" — এই দুটো ছাড়া ক্যাপচার করতেই SecurityException ক্র্যাশ হবে।",
    place: "app/src/main/AndroidManifest.xml খুলে পুরোটা বদলে দিন। আইকন হিসেবে res/drawable/ic_launcher.xml (ভেক্টর — পরের ফাইলটি) ব্যবহৃত হয়েছে, তাই কোনো PNG/Mipmap না থাকলেও বিল্ড হবে।",
    code: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- ══ পারমিশন ঘোষণা (৪টি) ══════════════════════════════ -->

    <!-- ১) অন্য অ্যাপের (ব্রোকার/চার্ট) উপরে ভাসমান ওভারলে আঁকা -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

    <!-- ২) ফোরগ্রাউন্ড সার্ভিস চালানো (Android 9+) -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />

    <!-- ৩) ★ সবচেয়ে গুরুত্বপূর্ণ ★
         Android 14 (API 34) থেকে মিডিয়া প্রজেকশনের জন্য আলাদা
         ফোরগ্রাউন্ড-টাইপ পারমিশন বাধ্যতামূলক। এটি না থাকলে
         ক্যাপচার শুরু হওয়ার সাথে সাথেই ক্র্যাশ। -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />

    <!-- ৪) স্ট্যাটাস নোটিফিকেশন দেখানো (Android 13+) -->
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">

        <!-- মূল স্ক্রিন: পারমিশন সেটআপ + স্টার্ট/স্টপ -->
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTask">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!--
          একমাত্র ফোরগ্রাউন্ড সার্ভিস — স্ক্রিন ক্যাপচার, অ্যানালাইসিস
          ও ওভারলে তিনটিই এখানে সমন্বিত হয়। Android 14-এ আলাদা
          ওভারলে-সার্ভিস রাখলে background-সীমাবদ্ধতায় সমস্যা হয়,
          তাই সচেতনভাবে একটি সার্ভিসেই সব রাখা হয়েছে।
          foregroundServiceType="mediaProjection" অপরিহার্য।
        -->
        <service
            android:name=".capture.CaptureService"
            android:exported="false"
            android:foregroundServiceType="mediaProjection" />

    </application>
</manifest>`,
  },
  {
    id: "strings",
    file: "strings.xml",
    path: "TradeLensAI/app/src/main/res/values/strings.xml",
    lang: "xml",
    group: "res",
    desc: "সব বাংলা টেক্সট স্ট্রিং — নোটিফিকেশন চ্যানেল, বাটন লেবেল ইত্যাদি।",
    place: "res/values/strings.xml খুলে <resources> ট্যাগের ভিতরে এই লাইনগুলো বসান (app_name ছাড়া বাকি নতুনগুলো যোগ করুন)।",
    code: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">TradeLens AI</string>
    <string name="channel_name">স্ক্রিন অ্যানালাইসিস</string>
    <string name="channel_desc">চার্ট স্ক্যানের লাইভ স্ট্যাটাস</string>
    <string name="notif_scanning">ক্যান্ডেল চার্ট খোঁজা হচ্ছে…</string>
    <string name="notif_stop">বন্ধ করুন</string>
</resources>`,
  },
  {
    id: "themes",
    file: "themes.xml",
    path: "TradeLensAI/app/src/main/res/values/themes.xml",
    lang: "xml",
    group: "res",
    desc: "ডার্ক ট্রেডিং থিম। AIDE ডিফল্ট থিম (সাধারণত Theme.Material) এর জায়গায় এটি বসালেই অ্যাপের লুক হবে প্রফেশনাল ডার্ক-গ্রিন।",
    place: "res/values/themes.xml ফাইলে (AIDE টেমপ্লেটে themes.xml না থাকলে styles.xml) AppTheme স্টাইলটি রাখুন। ম্যানিফেস্টে android:theme=\"@style/AppTheme\" দেওয়া আছে।",
    code: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- ডার্ক ট্রেডিং থিম — টার্মিনাল-সবুজ অ্যাকসেন্ট -->
    <style name="AppTheme" parent="Theme.Material3.Dark.NoActionBar">
        <item name="colorPrimary">#1ED18A</item>
        <item name="colorOnPrimary">#04281B</item>
        <item name="colorSecondary">#4FD8FF</item>
        <item name="android:statusBarColor">#06090E</item>
        <item name="android:navigationBarColor">#06090E</item>
        <item name="android:windowBackground">#06090E</item>
    </style>
</resources>`,
  },
  {
    id: "layout-main",
    file: "activity_main.xml",
    path: "TradeLensAI/app/src/main/res/layout/activity_main.xml",
    lang: "xml",
    group: "res",
    desc: "মূল স্ক্রিনের লেআউট — তিনটি পারমিশন স্ট্যাটাস, স্ক্যান-ইন্টারভাল স্লাইডার, স্টার্ট/স্টপ বাটন ও ছোট গাইড। একদম সাদাসিধে রাখা হয়েছে যাতে AIDE-তে কোনো অতিরিক্ত ডিপেন্ডেন্সি ছাড়াই কাজ করে।",
    place: "res/layout/activity_main.xml খুলে পুরোটা বদলে দিন। MainActivity.kt এর findViewById আইডিগুলো এই ফাইলের সাথে মিলে যায়।",
    code: `<?xml version="1.0" encoding="utf-8"?>
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:fillViewport="true">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="22dp">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="TradeLens AI"
            android:textColor="#1ED18A"
            android:textSize="28sp"
            android:textStyle="bold" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="2dp"
            android:text="স্ক্রিন-ভিত্তিক ক্যান্ডেল অ্যানালাইসিস ইঞ্জিন"
            android:textColor="#8CA3BC"
            android:textSize="14sp" />

        <!-- ══ পারমিশন স্ট্যাটাস ══ -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="26dp"
            android:text="ধাপ ১ — পারমিশন দিন"
            android:textColor="#D7E3F0"
            android:textSize="17sp"
            android:textStyle="bold" />

        <TextView
            android:id="@+id/tvOverlayStatus"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:textColor="#8CA3BC"
            android:textSize="14sp" />

        <Button
            android:id="@+id/btnOverlay"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="6dp"
            android:text="ওভারলে পারমিশন দিন" />

        <TextView
            android:id="@+id/tvNotifStatus"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="14dp"
            android:textColor="#8CA3BC"
            android:textSize="14sp" />

        <Button
            android:id="@+id/btnNotif"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="6dp"
            android:text="নোটিফিকেশন পারমিশন দিন" />

        <!-- ══ স্ক্যান ইন্টারভাল ══ -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="26dp"
            android:text="ধাপ ২ — স্ক্যান গতি"
            android:textColor="#D7E3F0"
            android:textSize="17sp"
            android:textStyle="bold" />

        <TextView
            android:id="@+id/tvInterval"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:textColor="#8CA3BC"
            android:textSize="13sp" />

        <SeekBar
            android:id="@+id/seekInterval"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="4dp"
            android:max="1300"
            android:progress="300" />

        <!-- ══ স্টার্ট / স্টপ ══ -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="26dp"
            android:text="ধাপ ৩ — অ্যানালাইসিস"
            android:textColor="#D7E3F0"
            android:textSize="17sp"
            android:textStyle="bold" />

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:text="স্ক্যান শুরু দিলে স্ক্রিন ক্যাপচারের পারমিশন চাইবে। তারপর চার্ট অ্যাপে (TradingView ইত্যাদি) গেলে ভাসমান চিপ ও সিগন্যাল দেখা যাবে।"
            android:textColor="#8CA3BC"
            android:textSize="13sp" />

        <Button
            android:id="@+id/btnStart"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:text="স্ক্যান শুরু করুন" />

        <Button
            android:id="@+id/btnStop"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:text="বন্ধ করুন" />

        <TextView
            android:id="@+id/tvEngineStatus"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="14dp"
            android:fontFamily="monospace"
            android:textColor="#4FD8FF"
            android:textSize="12sp" />

        <!-- ইঞ্জিন স্ট্যাটাস প্যানেল -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="22dp"
            android:text="কীভাবে কাজ করে"
            android:textColor="#D7E3F0"
            android:textSize="15sp"
            android:textStyle="bold" />

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="6dp"
            android:text="• প্রতি স্ক্যানে স্ক্রিনের সর্বশেষ ফ্রেমটি নেওয়া হয়\\n• সবুজ/লাল পিক্সেল ঘনত্ব থেকে চার্ট-এলাকা শনাক্ত হয়\\n• প্রতিটি ক্যান্ডেলের বডি, উইক ও দিক আলাদা করা হয়\\n• ৪৪টি প্যাটার্ন-নিয়ম আপনার শেষ ক্যান্ডেলগুলোর সাথে মিলানো হয়\\n• মিল পেলে চার্টের উপরেই বক্স + লেবেল + সংকেত দেখানো হয়\\n• কোনো নির্ভরযোগ্য প্যাটার্ন না মিললে সততার সাথে NEUTRAL দেখায়"
            android:textColor="#8CA3BC"
            android:lineSpacingMultiplier="1.5"
            android:textSize="13sp" />

    </LinearLayout>
</ScrollView>`,
  },
  {
    id: "launcher-icon",
    file: "ic_launcher.xml",
    path: "TradeLensAI/app/src/main/res/drawable/ic_launcher.xml",
    lang: "xml",
    group: "res",
    desc: "অ্যাপের আইকন — সম্পূর্ণ ভেক্টর (টেক্সট-ভিত্তিক), তাই কোনো PNG বা mipmap লাগে না। ম্যানিফেস্ট এটিই রেফারেন্স করে। চাইলে pathData বদলে নিজের ডিজাইন বানাতে পারেন।",
    place: "res/drawable ফোল্ডারে ic_launcher.xml নামে নতুন ফাইল বানিয়ে এটি বসান (drawable ফোল্ডার না থাকলে বানিয়ে নিন)।",
    code: `<?xml version="1.0" encoding="utf-8"?>
<!-- ভেক্টর লঞ্চার আইকন — বাইনারি PNG ছাড়াই আইকন -->
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">

    <!-- ডার্ক পটভূমি -->
    <path
        android:fillColor="#0B1119"
        android:pathData="M0,0h108v108h-108z" />

    <!-- বুলিশ ক্যান্ডেল ১ -->
    <path
        android:strokeColor="#1ED18A"
        android:strokeWidth="3.5"
        android:strokeLineCap="round"
        android:pathData="M30,24 L30,82" />
    <path
        android:fillColor="#1ED18A"
        android:pathData="M23,40 h14 v24 h-14 z" />

    <!-- বিয়ারিশ ক্যান্ডেল -->
    <path
        android:strokeColor="#FF5C6C"
        android:strokeWidth="3.5"
        android:strokeLineCap="round"
        android:pathData="M54,34 L54,86" />
    <path
        android:fillColor="#FF5C6C"
        android:pathData="M47,44 h14 v28 h-14 z" />

    <!-- বুলিশ ক্যান্ডেল ২ -->
    <path
        android:strokeColor="#1ED18A"
        android:strokeWidth="3.5"
        android:strokeLineCap="round"
        android:pathData="M78,18 L78,70" />
    <path
        android:fillColor="#1ED18A"
        android:pathData="M71,26 h14 v20 h-14 z" />
</vector>`,
  },
];
