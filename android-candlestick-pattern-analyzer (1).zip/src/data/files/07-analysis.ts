import type { FileDoc } from "../types";

export const analysisFiles: FileDoc[] = [
  {
    id: "candle-model",
    file: "Candle.kt",
    path: "TradeLensAI/app/src/main/java/com/tradelens/ai/analysis/Candle.kt",
    lang: "kotlin",
    group: "engine",
    desc: "ক্যান্ডেলের ডেটা-মডেল — open/high/low/close সহ বডি, উইক ও অনুপাত-ভিত্তিক প্রপার্টি। প্যাটার্ন-ইঞ্জিনের সব গণিত এই মডেলের উপর চলে।",
    place: "java/com/tradelens/ai-তে analysis নামে New Package → তার ভিতরে New Class → Candle। Direction enum এই ফাইলেই থাকবে।",
    code: `package com.tradelens.ai.analysis

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** ক্যান্ডেলের দিক */
enum class Direction { BULLISH, BEARISH, NEUTRAL }

/**
 * একটি ক্যান্ডেলের সম্পূর্ণ জ্যামিতিক তথ্য।
 *
 * মানগুলো "চার্ট-ইউনিট" — অর্থাৎ আসল টাকার দাম নয়, চিত্রের
 * উচ্চতা-ভিত্তিক মান। প্যাটার্ন শনাক্তকরণে নমুনার অনুপাতই
 * (বডি বনাম উইক বনাম রেঞ্জ) গুরুত্বপূর্ণ, দাম নয় — তাই এই
 * পদ্ধতি যে কোনো ব্রোকার, যে কোনো টাইমফ্রেমে সমান সঠিক।
 *
 * শর্ত: high ≥ low সবসময়; open/close এর মধ্যে থাকে।
 */
data class Candle(
    val index: Int,          // তালিকার অবস্থান (শেষ উপাদান = সর্বশেষ ক্যান্ডেল)
    val open: Float,
    val high: Float,
    val low: Float,
    val close: Float,
    val direction: Direction
) {
    /** বডির আকার */
    val body: Float get() = abs(close - open)

    /** উইকসহ পূর্ণ উচ্চতা */
    val range: Float get() = high - low

    /** উপরের উইক */
    val upperWick: Float get() = high - max(open, close)

    /** নিচের উইক */
    val lowerWick: Float get() = min(open, close) - low

    /** বডির উপর/নিচ/মাঝ প্রান্ত (দিক-নির্বিশেষে) */
    val bodyHigh: Float get() = max(open, close)
    val bodyLow: Float get() = min(open, close)
    val bodyMid: Float get() = (open + close) / 2f

    val isBullish: Boolean get() = direction == Direction.BULLISH
    val isBearish: Boolean get() = direction == Direction.BEARISH

    /** বডি রেঞ্জের কত অংশ (0..1) — দোজি = ~0, মারুবোজু = ~1 */
    val bodyRatio: Float get() = if (range <= 0f) 0f else body / range
    val upperWickRatio: Float get() = if (range <= 0f) 0f else upperWick / range
    val lowerWickRatio: Float get() = if (range <= 0f) 0f else lowerWick / range
}`,
  },
  {
    id: "pattern-result",
    file: "PatternResult.kt",
    path: "TradeLensAI/app/src/main/java/com/tradelens/ai/analysis/PatternResult.kt",
    lang: "kotlin",
    group: "engine",
    desc: "সংকেত-এনাম (৫-স্তরের: শক্তিশালী ক্রয় → শক্তিশালী বিক্রয়) ও প্যাটার্ন-ফলাফলের মডেল — বাংলা নাম, কনফিডেন্স, ব্যাখ্যাসহ।",
    place: "java/com/tradelens/ai/analysis প্যাকেজে New Class → PatternResult। Signal enum এই ফাইলেরই অংশ।",
    code: `package com.tradelens.ai.analysis

/**
 * ট্রেডিং সংকেত — ৫ স্তর।
 * strength স্বাক্ষরিত: +2 শক্তিশালী ক্রয় … −2 শক্তিশালী বিক্রয়।
 */
enum class Signal(val labelBn: String, val strength: Int) {
    STRONG_BUY("শক্তিশালী ক্রয়", 2),
    BUY("ক্রয়", 1),
    NEUTRAL("অপেক্ষা করুন", 0),
    SELL("বিক্রয়", -1),
    STRONG_SELL("শক্তিশালী বিক্রয়", -2)
}

/**
 * একটি শনাক্ত হওয়া প্যাটার্নের সম্পূর্ণ ফলাফল।
 * confidence = ০–১০০ — জ্যামিতিক মিল, প্রবণতা-প্রেক্ষাপট ও
 * ক্যান্ডেল-আকারের ওজন মিলিয়ে গণনা করা।
 */
data class PatternResult(
    val patternName: String,     // ইংরেজি নাম (Bullish Engulfing)
    val patternNameBn: String,   // বাংলা নাম (বুলিশ এনগালফিং)
    val signal: Signal,          // দিকনির্দেশনা
    val confidence: Int,         // 0..100
    val candleCount: Int,        // প্যাটার্নে জড়িত ক্যান্ডেল-সংখ্যা
    val descriptionBn: String,   // এক লাইনে ব্যাখ্যা
    val quality: Float           // আদর্শ আকৃতির সাথে মিল (0..1)
)`,
  },
  {
    id: "frame-analyzer",
    file: "FrameAnalyzer.kt",
    path: "TradeLensAI/app/src/main/java/com/tradelens/ai/analysis/FrameAnalyzer.kt",
    lang: "kotlin",
    group: "engine",
    desc: "পুরো পাইপলাইনের অর্কেস্ট্রেটর: Bitmap → ChartDetector → CandleExtractor → Candle-রূপান্তর → PatternEngine → ওভারলের জন্য স্ক্রিন-কোঅর্ডিনেটে হাইলাইট তৈরি। প্রতিটি স্ক্যান এই ক্লাস দিয়েই এক লাইনে চলে।",
    place: "java/com/tradelens/ai/analysis প্যাকেজে New Class → FrameAnalyzer। AnalysisReport ডেটা-ক্লাসও এই ফাইলে।",
    code: `package com.tradelens.ai.analysis

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import com.tradelens.ai.detection.CandleBox
import com.tradelens.ai.detection.CandleExtractor
import com.tradelens.ai.detection.ChartDetector

/**
 * এক ফ্রেম সম্পর্কে সবকিছু — ওভারলে/নোটিফিকেশন এটিই খায়।
 */
data class AnalysisReport(
    val status: Status,
    val candleCount: Int,
    val candleTrend: Int,                    // -1 ডাউন / 0 সাইড / +1 আপ
    val result: PatternResult?,              // null = সৎভাবে "প্যাটার্ন নেই"
    val highlights: List<Highlight>,         // স্ক্রিন-পিক্সেলে বক্স
    val lastCandleX: Float? = null,
    val scannedAt: Long = System.currentTimeMillis()
) {
    enum class Status { NO_CHART, TOO_FEW_CANDLES, FOUND }

    data class Highlight(
        val rect: RectF,         // স্ক্রিন-পিক্সেল কোঅর্ডিনেট
        val label: String,       // বাংলা প্যাটার্ন-নাম
        val confidence: Int,
        val color: Int,          // ARGB — থিম থেকে শেখা বুল/বিয়ার রঙ
        val sentiment: Int       // +1 ক্রয় / -1 বিক্রয় / 0 নিরপেক্ষ
    )
}

/**
 * বিশ্লেষণ-পাইপলাইন অর্কেস্ট্রেটর।
 *
 *     Bitmap
 *       └─ ChartDetector.buildMask()      → চার্ট-এলাকা + পিক্সেল-শ্রেণি
 *            └─ CandleExtractor.extract() → CandleBox তালিকা (জ্যামিতি)
 *                 └─ toCandles()          → Candle (প্রাইস-স্পেস)
 *                      └─ PatternEngine.analyze() → প্যাটার্ন + সংকেত
 *
 * কোথাও অনুমান-ভিত্তিক "ভুয়া" আউটপুট নেই — প্রতিটি ধাপ ব্যর্থ হলে
 * স্পষ্ট স্ট্যাটাস ফেরত দেয় (NO_CHART / TOO_FEW_CANDLES)।
 */
class FrameAnalyzer {

    private val engine = PatternEngine()

    fun analyze(frame: Bitmap): AnalysisReport {
        // ধাপ ১: চার্ট আছেই কিনা?
        val mask = ChartDetector.buildMask(frame)
            ?: return AnalysisReport(AnalysisReport.Status.NO_CHART, 0, 0, null, emptyList())

        // ধাপ ২: আলাদা ক্যান্ডেলগুলো বের করি
        val boxes = CandleExtractor.extract(mask)
            ?: return AnalysisReport(
                AnalysisReport.Status.TOO_FEW_CANDLES, 0, 0, null, emptyList()
            )

        // ধাপ ৩: জ্যামিতি → প্রাইস-স্পেস Candle
        val candles = toCandles(boxes, mask.bounds.bottom)
        val trend = PatternEngine.trendOf(candles, 0)

        // ধাপ ৪: প্যাটার্ন-ইঞ্জিন
        val result = engine.analyze(candles)

        // ধাপ ৫: ওভারলের জন্য স্ক্রিন-কোঅর্ডিনেট হাইলাইট
        val scale = mask.scaleToScreen
        val highlights = if (result == null) emptyList()
        else listOf(makeHighlight(boxes, result, scale, mask.bullColor, mask.bearColor))

        val lastX = boxes.last().centerX * scale

        return AnalysisReport(
            AnalysisReport.Status.FOUND,
            candles.size,
            trend,
            result,
            highlights,
            lastX
        )
    }

    /** শেষ result.candleCount সংখ্যক বক্সকে একটি মার্জড হাইলাইটে রূপান্তর। */
    private fun makeHighlight(
        boxes: List<CandleBox>,
        result: PatternResult,
        scale: Float,
        bullColor: Int,
        bearColor: Int
    ): AnalysisReport.Highlight {
        val n = result.candleCount.coerceAtMost(boxes.size)
        val sub = boxes.subList(boxes.size - n, boxes.size)

        var left = Float.MAX_VALUE
        var top = Float.MAX_VALUE
        var right = Float.MIN_VALUE
        var bottom = Float.MIN_VALUE
        for (b in sub) {
            left = minOf(left, b.left.toFloat())
            right = maxOf(right, b.right + 1f)
            top = minOf(top, b.top.toFloat())
            bottom = maxOf(bottom, b.bottom.toFloat())
        }

        val padX = (right - left) / n * 0.45f
        val padY = 10f / scale

        val sentiment = result.signal.strength.coerceIn(-1, 1)
        val color = when {
            sentiment > 0 -> bullColor
            sentiment < 0 -> bearColor
            else -> Color.rgb(245, 183, 76)    // নিরপেক্ষ = অ্যাম্বার
        }

        return AnalysisReport.Highlight(
            RectF(
                (left - padX) * scale,
                (top - padY) * scale,
                (right + padX) * scale,
                (bottom + padY) * scale
            ),
            result.patternNameBn,
            result.confidence,
            color,
            sentiment
        )
    }

    /**
     * CandleBox (পিক্সেল) → Candle (প্রাইস-স্পেস)।
     * y-অক্ষ উল্টে দিই: স্ক্রিনে উপরে = বড় মান = বেশি দাম।
     */
    private fun toCandles(boxes: List<CandleBox>, axisBottom: Int): List<Candle> {
        val out = ArrayList<Candle>(boxes.size)
        for (i in boxes.indices) {
            val b = boxes[i]
            val high = (axisBottom - b.top).toFloat()
            val low = (axisBottom - b.bottom).toFloat()
            val bodyTop = (axisBottom - b.bodyTop).toFloat()
            val bodyBottom = (axisBottom - b.bodyBottom).toFloat()

            val o: Float
            val c: Float
            when (b.cls) {
                ChartDetector.CLS_BULL -> {          // নিচে ওপেন → উপরে ক্লোজ
                    o = bodyBottom; c = bodyTop
                }
                ChartDetector.CLS_BEAR -> {          // উপরে ওপেন → নিচে ক্লোজ
                    o = bodyTop; c = bodyBottom
                }
                else -> {                            // দিক অনিশ্চিত (দোজি)
                    val m = (bodyTop + bodyBottom) / 2f
                    o = m; c = m
                }
            }

            val dir = when (b.cls) {
                ChartDetector.CLS_BULL -> Direction.BULLISH
                ChartDetector.CLS_BEAR -> Direction.BEARISH
                else -> Direction.NEUTRAL
            }
            out.add(Candle(i, o, high, low, c, dir))
        }
        return out
    }
}`,
  },
];
