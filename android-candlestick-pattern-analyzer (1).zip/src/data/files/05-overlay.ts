import type { FileDoc } from "../types";

export const overlayFiles: FileDoc[] = [
  {
    id: "overlay-controller",
    file: "OverlayController.kt",
    path: "TradeLensAI/app/src/main/java/com/tradelens/ai/overlay/OverlayController.kt",
    lang: "kotlin",
    group: "overlay",
    desc: "দুটি ওভারলে উইন্ডো পরিচালনা করে: (১) পূর্ণ-স্ক্রিন টাচ-পাসথ্রু সিগন্যাল-লেয়ার যেখানে প্যাটার্ন-বক্স আঁকা হয় — এতে আঙুল চার্ট অ্যাপে বাধাহীনভাবে কাজ করে; (২) টেনে সরানো যায় এমন ভাসমান চিপ — ট্যাপে বিশ্লেষণ pause/resume।",
    place: "java/com/tradelens/ai-তে overlay নামে New Package বানিয়ে তার ভিতরে New Class → OverlayController।",
    code: `package com.tradelens.ai.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.tradelens.ai.analysis.AnalysisReport
import com.tradelens.ai.capture.CaptureService
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * ওভারলে ম্যানেজার — CaptureService নিজেই এটি ঘড়িয়ে রাখে।
 *
 * দুটি উইন্ডো:
 *   ① SignalLayer (OverlayView) — MATCH_PARENT, তবে FLAG_NOT_TOUCHABLE:
 *      প্যাটার্ন-বক্স/লেবেল আঁকে, কিন্তু স্পর্শ নিচের চার্ট অ্যাপে চলে যায়।
 *      আপনার ট্রেডিং-এ কোনো বাধা নেই।
 *   ② FloatingChip — ছোট ভাসমান স্ট্যাটাস-চিপ: টেনে সরান, ট্যাপে pause/resume।
 *
 * আলাদা OverlayService রাখিনি ইচ্ছাকৃতভাবে — Android 14-এ ব্যাকগ্রাউণ্ড
 * সার্ভিস থেকে উইন্ডো-আপডেট সীমাবদ্ধ; এক সার্ভিসেই সব নির্ভরযোগ্য।
 */
class OverlayController(private val service: Service) {

    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var layer: OverlayView? = null
    private var chip: View? = null
    private var chipText: TextView? = null
    private var chipDot: View? = null

    fun attach() {
        main.post {
            if (layer != null) return@post
            addSignalLayer()
            addChip()
        }
    }

    // ── ① পূর্ণ-স্ক্রিন, স্পর্শ-পাসথ্রু সিগন্যাল লেয়ার ──────────
    private fun addSignalLayer() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // NOT_TOUCHABLE ⇒ আঙুল বিনা-বাধায় নিচের অ্যাপে যায়
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        val view = OverlayView(service)
        layer = view
        wm.addView(view, params)
    }

    // ── ② টান-যোগ্য ভাসমান চিপ ──────────────────────────────────
    private fun addChip() {
        val dotBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#8CA3BC"))
        }
        val dot = View(service).apply {
            background = dotBg
            layoutParams = LinearLayout.LayoutParams(dp(9), dp(9)).apply {
                setMargins(0, 0, dp(7), 0)
            }
        }
        val tv = TextView(service).apply {
            textSize = 12.5f
            setTextColor(Color.parseColor("#D7E3F0"))
            text = "প্রস্তুত"
        }
        val capsule = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(Color.parseColor("#EB0B1119"))
            setStroke(dp(1), Color.parseColor("#331ED18A"))
        }
        val row = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(14), dp(8))
            background = capsule
            addView(dot)
            addView(tv)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(120)
        }

        // টানা + ট্যাপ শনাক্তকরণ
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        row.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX; downRawY = ev.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX
                    val dy = ev.rawY - downRawY
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        params.x = startX + dx.roundToInt()
                        params.y = startY + dy.roundToInt()
                        try { wm.updateViewLayout(row, params) } catch (_: Throwable) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) CaptureService.toggle(service) // ট্যাপ = pause/resume
                    true
                }
                else -> false
            }
        }

        chip = row
        chipText = tv
        chipDot = dot
        wm.addView(row, params)
    }

    // ── বিশ্লেষণ-ফল প্রতিফলন (যে থ্রেড থেকেই ডাকা নিরাপদ) ────────
    fun update(report: AnalysisReport) {
        main.post {
            layer?.setReport(report)
            val tv = chipText ?: return@post
            when (report.status) {
                AnalysisReport.Status.NO_CHART -> {
                    tv.text = "চার্ট খুঁজছি…"
                    setDot("#8CA3BC")
                }
                AnalysisReport.Status.TOO_FEW_CANDLES -> {
                    tv.text = "ক্যান্ডেল কম — জুম-আউট করুন"
                    setDot("#F5B74C")
                }
                AnalysisReport.Status.FOUND -> {
                    val r = report.result
                    if (r == null) {
                        tv.text = "" + report.candleCount + " ক্যান্ডেল • NEUTRAL"
                        setDot("#4FD8FF")
                    } else {
                        tv.text = r.patternNameBn + " " + r.confidence + "%"
                        setDot(
                            when {
                                r.signal.strength > 0 -> "#1ED18A"
                                r.signal.strength < 0 -> "#FF5C6C"
                                else -> "#F5B74C"
                            }
                        )
                    }
                }
            }
        }
    }

    fun setPaused(pausedNow: Boolean) {
        main.post {
            layer?.setPaused(pausedNow)
            chipText?.text = if (pausedNow) "বিরতি — ট্যাপে চালু" else "চার্ট খুঁজছি…"
            setDot(if (pausedNow) "#8CA3BC" else "#1ED18A")
        }
    }

    fun detach() {
        main.post {
            layer?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
            chip?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
            layer = null; chip = null; chipText = null; chipDot = null
        }
    }

    private fun setDot(hex: String) {
        (chipDot?.background as? GradientDrawable)?.setColor(Color.parseColor(hex))
    }

    private fun dp(v: Int): Int = (v * service.resources.displayMetrics.density).roundToInt()
}`,
  },
  {
    id: "overlay-view",
    file: "OverlayView.kt",
    path: "TradeLensAI/app/src/main/java/com/tradelens/ai/overlay/OverlayView.kt",
    lang: "kotlin",
    group: "overlay",
    desc: "যেখানে আসল আঁকাআঁকি হয় — শনাক্ত প্যাটার্নের চারপাশে পালসিং বক্স, প্যাটার্নের নামে অবিশ্বাস্য লেবেল-পিল, তীর-চিহ্ন, সর্বশেষ ক্যান্ডেলে ড্যাশড লাইন এবং নিচে-বামে সংকেত-সামারি ব্যাজ। সবই Canvas-এ হাতে আঁকা, কোনো image নেই।",
    place: "java/com/tradelens/ai/overlay প্যাকেজে New Class → OverlayView (View extends করে)।",
    code: `package com.tradelens.ai.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.LinearInterpolator
import com.tradelens.ai.analysis.AnalysisReport
import kotlin.math.roundToInt

/**
 * সিগন্যাল-লেয়ারের আসল আঁকিবুঁকি।
 *
 * আঁকা হয়:
 *   • শনাক্ত প্যাটার্নের ক্যান্ডেলগুলো ঘিরে পালসিং বৃত্তাকার বক্স
 *   • বক্সের উপরে ডার্ক-পিলে প্যাটার্নের বাংলা নাম + কনফিডেন্স %
 *   • সংকেত-দিক অনুযায়ী তীর (উপরে = ক্রয়, নিচে = বিক্রয়)
 *   • সর্বশেষ ক্যান্ডেলে উল্লম্ব ড্যাশড লাইন
 *   • নিচে-বামে সামারি ব্যাজ: "সংকেত: শক্তিশালী ক্রয় • ৮৭%"
 *
 * কিছুই ইমেজ নয় — সব Canvas প্রিমিটিভ, তাই ফ্রেম-রেটে কোনো চাপ নেই।
 */
class OverlayView(context: Context) : View(context) {

    private var report: AnalysisReport? = null
    private var paused = false
    private var pulse = 0.85f

    private val boxStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(2.2f)
    }
    private val boxFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val pillBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = dpF(12.5f)
        isFakeBoldText = true
    }
    private val smallText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B9CBDD")
        textSize = dpF(11f)
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1f)
        color = Color.parseColor("#554FD8FF")
        pathEffect = DashPathEffect(floatArrayOf(dpF(7f), dpF(6f)), 0f)
    }

    // মৃদু পালস — ফ্রেম-আপডেট ছাড়াই বক্স "জীবন্ত" লাগে
    private val pulseAnim = ValueAnimator.ofFloat(0.62f, 1f).apply {
        duration = 950
        repeatMode = ValueAnimator.REVERSE
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            pulse = it.animatedValue as Float
            invalidate()
        }
        start()
    }

    fun setReport(r: AnalysisReport) {
        report = r
        invalidate()
    }

    fun setPaused(p: Boolean) {
        paused = p
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val r = report ?: return
        if (paused) return
        if (r.status != AnalysisReport.Status.FOUND) return

        // ── ১) প্যাটার্ন-হাইলাইট বক্সগুলো ────────────────────────
        for (h in r.highlights) {
            val base = h.color
            boxFill.color = withAlpha(base, (26 * pulse).roundToInt() + 8)
            canvas.drawRoundRect(h.rect, dpF(9f), dpF(9f), boxFill)

            boxStroke.color = withAlpha(base, (255 * pulse).roundToInt())
            canvas.drawRoundRect(h.rect, dpF(9f), dpF(9f), boxStroke)

            drawLabel(canvas, h)
            drawArrow(canvas, h)
        }

        // ── ২) সর্বশেষ ক্যান্ডেলের ড্যাশড লাইন ───────────────────
        r.lastCandleX?.let { x ->
            canvas.drawLine(x, dpF(30f), x, height - dpF(30f), dashPaint)
        }

        // ── ৩) সামারি ব্যাজ ─────────────────────────────────────
        drawSummary(canvas, r)
    }

    // বক্সের উপরে ডার্ক-পিলে বাংলা লেবেল
    private fun drawLabel(canvas: Canvas, h: AnalysisReport.Highlight) {
        val label = h.label + "  " + h.confidence + "%"
        textPaint.textSize = dpF(12.5f)
        val tw = textPaint.measureText(label)
        val padH = dpF(10f)
        val pillH = dpF(26f)
        var left = h.rect.left
        if (left + tw + padH * 2 > width) left = width - tw - padH * 2 - dpF(4f)
        if (left < dpF(4f)) left = dpF(4f)
        var top = h.rect.top - pillH - dpF(6f)
        if (top < dpF(6f)) top = h.rect.bottom + dpF(6f)

        pillBg.color = Color.parseColor("#E60B1119")
        canvas.drawRoundRect(left, top, left + tw + padH * 2, top + pillH, pillH / 2, pillH / 2, pillBg)
        boxStroke.color = h.color
        boxStroke.strokeWidth = dpF(1f)
        canvas.drawRoundRect(left, top, left + tw + padH * 2, top + pillH, pillH / 2, pillH / 2, boxStroke)
        boxStroke.strokeWidth = dpF(2.2f)

        canvas.drawText(label, left + padH, top + pillH - dpF(8.5f), textPaint)
    }

    // সংকেত-দিকের তীর
    private fun drawArrow(canvas: Canvas, h: AnalysisReport.Highlight) {
        val size = dpF(9f)
        val cx = h.rect.right - dpF(6f)
        val path = Path()
        boxFill.color = h.color
        if (h.sentiment > 0) {
            val cy = h.rect.bottom + dpF(10f)
            path.moveTo(cx, cy - size)
            path.lineTo(cx - size * 0.75f, cy + size * 0.5f)
            path.lineTo(cx + size * 0.75f, cy + size * 0.5f)
        } else if (h.sentiment < 0) {
            val cy = h.rect.top - dpF(10f)
            path.moveTo(cx, cy + size)
            path.lineTo(cx - size * 0.75f, cy - size * 0.5f)
            path.lineTo(cx + size * 0.75f, cy - size * 0.5f)
        } else return
        path.close()
        canvas.drawPath(path, boxFill)
    }

    private fun drawSummary(canvas: Canvas, r: AnalysisReport) {
        val res = r.result
        val trendTxt = when (r.candleTrend) {
            1 -> "ট্রেন্ড: আপ"; -1 -> "ট্রেন্ড: ডাউন"; else -> "ট্রেন্ড: সাইড"
        }
        val line1 = if (res == null) "সংকেত: NEUTRAL" else "সংকেত: " + res.signal.labelBn + " • " + res.confidence + "%"
        val line2 = "" + r.candleCount + " ক্যান্ডেল • " + trendTxt

        smallText.textSize = dpF(11.5f)
        val w1 = smallText.measureText(line1)
        val w2 = smallText.measureText(line2)
        val bw = maxOf(w1, w2) + dpF(22f)
        val bh = dpF(46f)
        val left = dpF(12f)
        val bottom = height - dpF(52f)

        pillBg.color = Color.parseColor("#D90B1119")
        canvas.drawRoundRect(left, bottom - bh, left + bw, bottom, dpF(10f), dpF(10f), pillBg)

        val accent = when {
            res == null -> Color.parseColor("#8CA3BC")
            res.signal.strength > 0 -> Color.parseColor("#1ED18A")
            res.signal.strength < 0 -> Color.parseColor("#FF5C6C")
            else -> Color.parseColor("#F5B74C")
        }
        boxFill.color = accent
        canvas.drawRoundRect(left, bottom - bh, left + dpF(3.5f), bottom, dpF(2f), dpF(2f), boxFill)

        canvas.drawText(line1, left + dpF(11f), bottom - bh + dpF(18f), smallText)
        canvas.drawText(line2, left + dpF(11f), bottom - bh + dpF(35f), smallText)
    }

    private fun withAlpha(color: Int, alpha: Int): Int {
        return Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
    }

    private fun dpF(v: Float): Float = v * resources.displayMetrics.density

    override fun onDetachedFromWindow() {
        pulseAnim.cancel()
        super.onDetachedFromWindow()
    }
}`,
  },
];
