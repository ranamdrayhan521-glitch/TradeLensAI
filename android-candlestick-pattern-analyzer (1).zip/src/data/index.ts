import type { FileDoc, GroupMeta } from "./types";
import { buildFiles } from "./files/01-build";
import { manifestResFiles } from "./files/02-manifest-res";
import { activityFiles } from "./files/03-activity";
import { captureFiles } from "./files/04-capture";
import { overlayFiles } from "./files/05-overlay";
import { detectionFiles } from "./files/06-detection";
import { analysisFiles } from "./files/07-analysis";
import { patternEngineFiles } from "./files/08-pattern-engine";
import { workflowFiles } from "./files/09-workflow";

export const groups: GroupMeta[] = [
  { id: "build", title: "বিল্ড কনফিগ", icon: "wrench" },
  { id: "res", title: "ম্যানিফেস্ট ও রিসোর্স", icon: "file-cog" },
  { id: "app", title: "মূল স্ক্রিন", icon: "smartphone" },
  { id: "capture", title: "ক্যাপচার ইঞ্জিন", icon: "scan" },
  { id: "overlay", title: "ভাসমান ওভারলে", icon: "layers" },
  { id: "detect", title: "চার্ট ডিটেকশন", icon: "crosshair" },
  { id: "engine", title: "প্যাটার্ন ইঞ্জিন", icon: "brain" },
];

export const allFiles: FileDoc[] = [
  ...workflowFiles,
  ...buildFiles,
  ...manifestResFiles,
  ...activityFiles,
  ...captureFiles,
  ...overlayFiles,
  ...detectionFiles,
  ...analysisFiles,
  ...patternEngineFiles,
];

export const fileById = new Map(allFiles.map((f) => [f.id, f]));

export const PATTERN_RULE_COUNT = 44;

/* ───────────────────────── ফোল্ডার ট্রি ───────────────────────── */

export interface TreeNode {
  name: string;
  type: "dir" | "file";
  fileId?: string;
  note?: string;
  children?: TreeNode[];
}

export const projectTree: TreeNode = {
  name: "TradeLensAI",
  type: "dir",
  children: [
    {
      name: ".github/workflows",
      type: "dir",
      children: [
        { name: "android-build.yml", type: "file", fileId: "gh-actions", note: "পুশ করলেই ক্লাউডে APK তৈরি" },
      ],
    },
    { name: "settings.gradle", type: "file", fileId: "settings-gradle" },
    { name: "build.gradle", type: "file", fileId: "root-gradle", note: "প্রজেক্ট-লেভেল (Module:app নয়!)" },
    { name: "gradle.properties", type: "file", fileId: "gradle-props" },
    {
      name: "app",
      type: "dir",
      children: [
        { name: "build.gradle", type: "file", fileId: "app-gradle", note: "Module:app এখানে" },
        { name: "proguard-rules.pro", type: "file", fileId: "proguard" },
        {
          name: "src/main",
          type: "dir",
          children: [
            { name: "AndroidManifest.xml", type: "file", fileId: "manifest" },
            {
              name: "java/com.tradelens.ai",
              type: "dir",
              children: [
                { name: "MainActivity.kt", type: "file", fileId: "main-activity" },
                {
                  name: "capture",
                  type: "dir",
                  children: [
                    { name: "CaptureService.kt", type: "file", fileId: "capture-service", note: "ProjectionStore এই ফাইলেই" },
                    { name: "FrameProcessor.kt", type: "file", fileId: "frame-processor" },
                    { name: "CaptureNotification.kt", type: "file", fileId: "capture-notification" },
                  ],
                },
                {
                  name: "overlay",
                  type: "dir",
                  children: [
                    { name: "OverlayController.kt", type: "file", fileId: "overlay-controller" },
                    { name: "OverlayView.kt", type: "file", fileId: "overlay-view" },
                  ],
                },
                {
                  name: "detection",
                  type: "dir",
                  children: [
                    { name: "ChartDetector.kt", type: "file", fileId: "chart-detector", note: "FrameMask এই ফাইলেই" },
                    { name: "CandleExtractor.kt", type: "file", fileId: "candle-extractor" },
                  ],
                },
                {
                  name: "analysis",
                  type: "dir",
                  children: [
                    { name: "Candle.kt", type: "file", fileId: "candle-model", note: "Direction enum এই ফাইলেই" },
                    { name: "PatternResult.kt", type: "file", fileId: "pattern-result", note: "Signal enum এই ফাইলেই" },
                    { name: "PatternEngine.kt", type: "file", fileId: "pattern-engine", note: "৪৪টি প্যাটার্ন-নিয়ম" },
                    { name: "FrameAnalyzer.kt", type: "file", fileId: "frame-analyzer", note: "AnalysisReport এই ফাইলেই" },
                  ],
                },
              ],
            },
            {
              name: "res",
              type: "dir",
              children: [
                {
                  name: "values",
                  type: "dir",
                  children: [
                    { name: "strings.xml", type: "file", fileId: "strings" },
                    { name: "themes.xml", type: "file", fileId: "themes" },
                  ],
                },
                {
                  name: "layout",
                  type: "dir",
                  children: [{ name: "activity_main.xml", type: "file", fileId: "layout-main" }],
                },
                {
                  name: "drawable",
                  type: "dir",
                  children: [{ name: "ic_launcher.xml", type: "file", fileId: "launcher-icon", note: "ভেক্টর আইকন — PNG লাগে না" }],
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};

/* ───────────────────────── সেটআপ ধাপসমূহ ───────────────────────── */

export interface SetupStep {
  no: string;
  title: string;
  desc: string;
  fileIds: string[];
  tip?: string;
}

export const setupSteps: SetupStep[] = [
  {
    no: "১",
    title: "AIDE-তে নতুন প্রজেক্ট বানান",
    desc: "AIDE খুলুন → New Android App (Gradle)। App name: TradeLensAI, Package name: com.tradelens.ai, Minimum SDK: API 29 (Android 10)। প্রজেক্ট বানিয়ে নিন।",
    fileIds: [],
    tip: "প্যাকেজ নাম অন্য রাখলে app/build.gradle-এর namespace ও applicationId — এবং প্রতিটি .kt ফাইলের প্রথম package লাইন সেই নামেই বদলাতে হবে।",
  },
  {
    no: "২",
    title: "বিল্ড ফাইল ৪টি বদলান",
    desc: "রুট ফোল্ডারের settings.gradle, build.gradle, gradle.properties এবং app ফোল্ডারের build.gradle — নিচের কোড-সেকশনের ১–৪ নম্বর ফাইল দেখে বদলে দিন।",
    fileIds: ["settings-gradle", "root-gradle", "gradle-props", "app-gradle", "proguard"],
    tip: "দুটি build.gradle আছে খেয়াল করুন: প্রজেক্ট-লেভেল (রুটে) শুধু প্লাগিন ভার্সন ধারণ করে, অ্যাপ-লেভেলে (app/) সব কনফিগ থাকে।",
  },
  {
    no: "৩",
    title: "ম্যানিফেস্ট ও রিসোর্স বসান",
    desc: "app/src/main/AndroidManifest.xml পুরো বদলে দিন। তারপর res/values/strings.xml, themes.xml এবং res/layout/activity_main.xml বসান। পারমিশন ৪টি ম্যানিফেস্টেই ঘোষিত।",
    fileIds: ["manifest", "strings", "themes", "layout-main", "launcher-icon"],
  },
  {
    no: "৪",
    title: "MainActivity রিপ্লেস করুন",
    desc: "java/com.tradelens.ai ফোল্ডারে আগে থেকে থাকা MainActivity.kt খুলে পুরো কোড মুছে নতুনটি বসান।",
    fileIds: ["main-activity"],
  },
  {
    no: "৫",
    title: "৪টি প্যাকেজ বানান",
    desc: "java/com.tradelens.ai-তে Right Click → New → Package দিয়ে ঠিক এই নামে ৪টি প্যাকেজ বানান: capture, overlay, detection, analysis। নাম বানান-সহ মিলতে হবে, নাহলে import error আসবে।",
    fileIds: [],
    tip: "AIDE-তে প্যাকেজ বানাতে: java ফোল্ডারে যান → com → tradelens → ai → মেনু থেকে New Package।",
  },
  {
    no: "৬",
    title: "capture প্যাকেজে ৩টি ফাইল",
    desc: "CaptureService.kt (সবচেয়ে গুরুত্বপূর্ণ — ProjectionStore এই ফাইলের নিচে আছে, আলাদা ফাইল লাগবে না), FrameProcessor.kt, CaptureNotification.kt বানিয়ে কোড বসান।",
    fileIds: ["capture-service", "frame-processor", "capture-notification"],
  },
  {
    no: "৭",
    title: "overlay, detection ও analysis প্যাকেজ",
    desc: "overlay-তে OverlayController.kt + OverlayView.kt; detection-এ ChartDetector.kt + CandleExtractor.kt; analysis-এ Candle.kt + PatternResult.kt + PatternEngine.kt + FrameAnalyzer.kt। প্রতিটি ফাইলের ঊর্ধ্বে লেখা বর্ণনায় বলা আছে কোন ক্লাস/enum একই ফাইলে থাকবে।",
    fileIds: ["overlay-controller", "overlay-view", "chart-detector", "candle-extractor", "candle-model", "pattern-result", "frame-analyzer", "pattern-engine"],
  },
  {
    no: "৮",
    title: "সিঙ্ক, বিল্ড ও রান",
    desc: "AIDE-এর টুলবার থেকে Refresh/Sync দিন, ডিপেন্ডেন্সি ডাউনলোড হতে দিন (ওয়াইফাই লাগবে)। তারপর Run। ফোনে অ্যাপ খুলে ২টি পারমিশন দিন → 'স্ক্যান শুরু করুন' → স্ক্রিন ক্যাপচারের পারমিশন দিন → চার্ট/ব্রোকার অ্যাপে যান।",
    fileIds: [],
    tip: "TradingView বা যে চার্টে FLAG_SECURE নেই সেটিতে স্ক্যান করুন। কিছু ব্রোকার-অ্যাপ স্ক্রিন-সুরক্ষা চালু রাখে — সেখানে ওই অ্যাপের সেটিংস থেকে 'Screen capture'/'স্ক্রিনশট' অনুমতি চালু করুন।",
  },
];

/* ─────────────────── স্ক্রিন-ক্যাপচার ফিক্স কার্ড ─────────────────── */

export interface FixCard {
  no: string;
  problem: string;
  fix: string;
}

export const captureFixes: FixCard[] = [
  {
    no: "১",
    problem: "পুরনো/ক্যাশে করা পারমিশন-টোকেন পুনর্ব্যবহার — Android 14+ এ ক্যাপচার নীরবে ব্যর্থ হয়",
    fix: "প্রতিবার স্ক্যান শুরুতে নতুন createScreenCaptureIntent() লঞ্চ হয় এবং রেজাল্টের Intent সরাসরি ProjectionStore স্ট্যাটিক হোল্ডারে রাখা হয় — Intent-extra দিয়ে parcel করার সময় টোকেন নষ্ট হওয়ার সমস্যাও এতে নেই।",
  },
  {
    no: "২",
    problem: "SecurityException: Media projections require a foreground service of type MEDIA_PROJECTION",
    fix: "কঠোর ক্রম মানা হয়: ① ServiceCompat.startForeground(…, FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) → ② getMediaProjection()। ম্যানিফেস্টে FOREGROUND_SERVICE_MEDIA_PROJECTION পারমিশন + service-এ foregroundServiceType=\"mediaProjection\" আবশ্যক — তিনটিই কোডে আছে।",
  },
  {
    no: "৩",
    problem: "তির্যক/স্ট্রেচড/কালো ছবি আসা — GPU buffer-এর rowStride padding হ্যান্ডল না করলে",
    fix: "FrameProcessor.toBitmap() প্রথমে padding-সহ চওড়া Bitmap বানায়, তারপর crop করে পরিষ্কার ফ্রেম দেয়।",
  },
  {
    no: "৪",
    problem: "৩–৪ ফ্রেম পরেই ক্যাপচার থেমে যাওয়া — Image.close() না করা থেকে BufferQueue ভরে যায়",
    fix: "প্রতিটি ফ্রেমে finally ব্লকে image.close() গ্যারান্টিযুক্ত; থ্রোটলিংয়ে বাদ পড়া ফ্রেমও close করা হয়।",
  },
  {
    no: "৫",
    problem: "Android 14-এ ক্র্যাশ: registerCallback ছাড়া createVirtualDisplay",
    fix: "VirtualDisplay বানানোর আগে MediaProjection.Callback রেজিস্টার করা হয়; সিস্টেম ক্যাপচার বন্ধ করলে সার্ভিস নিজেই পরিষ্কারভাবে থেমে যায়।",
  },
  {
    no: "৬",
    problem: "স্ক্রিন ঘোরালে (portrait↔landscape) কালো বা অর্ধেক ক্যাপচার",
    fix: "OrientationEventListener দিয়ে পরিবর্তন শনাক্ত করে VirtualDisplay নতুন মাপেও পুনর্নির্মাণ করা হয়।",
  },
];

/* ───────────────────────── FAQ ───────────────────────── */

export interface FaqItem {
  q: string;
  a: string;
}

export const faqs: FaqItem[] = [
  {
    q: "সব দেখাচ্ছে কিন্তু প্যাটার্ন কিছুই মিলছে না — সবসময় NEUTRAL কেন?",
    a: "ইঞ্জিন ইচ্ছাকৃতভাবে রক্ষণশীল: প্রতিটি নিয়মে প্রবণতা-গেট (যেমন হাতুড়ে কেবল ডাউনট্রেন্ডে) ও ন্যূনতম ৫০ কনফিডেন্স থ্রেশহোল্ড আছে। শক্ত প্যাটার্ন না থাকলে NEUTRAL দেখানোই সঠিক আচরণ — এটি জোর করে সংকেত বানায় না। চার্ট জুম-আউট করে ২০–৩০টি ক্যান্ডেল দৃশ্যমান রাখলে মিল অনেক বেড়ে যায়।",
  },
  {
    q: "ক্যাপচার চলছে কিন্তু স্ক্রিন একদম কালো",
    a: "সেই চার্ট/ব্রোকার অ্যাপটি FLAG_SECURE (স্ক্রিন-সুরক্ষা) চালু করেছে — সুরক্ষিত স্ক্রিন Android নিজেই কালো করে দেয়, এটি আমাদের বাগ নয়। সমাধান: ব্রোকার অ্যাপের সেটিংসে 'স্ক্রিনশট/স্ক্রিন ক্যাপচার' অনুমতি চালু করুন, অথবা TradingView-মতো চার্ট-অ্যাপ (বা মোবাইল ব্রাউজারে chart) ব্যবহার করুন।",
  },
  {
    q: "ফ্লোটিং চিপ দেখা যাচ্ছে না",
    a: "ওভারলে পারমিশন (Display over other apps) বন্ধ হয়ে যেতে পারে। অ্যাপে ফিরে স্ট্যাটাস দেখুন — ২ ধাপের প্রথমটি সবুজ কিনা মিলিয়ে নিন। MI/Xiaomi-তে অতিরিক্ত 'Display pop-up windows while running in background' পারমিশন আলাদা দিতে হয়।",
  },
  {
    q: "AIDE-তে dependency sync error",
    a: "দুটি খুব কমন কারণ: (১) নেট নেই — প্রথম সিঙ্কে লাইব্রেরি ডাউনলোড হয়, ভালো ওয়াইফাই দিন; (২) settings.gradle-এ repositories block ঠিক নেই — ফাইল #১ হুবহু বসান। এরপরও সমস্যা হলে AGP ভার্সন 8.1.4-এর বদলে 7.4.2 ও Kotlin 1.9.10 দিয়ে দেখুন।",
  },
  {
    q: "ক্যান্ডেলের রং আমার অ্যাপে ভিন্ন (সাদা/নীল)",
    a: "ChartDetector-এর classify() ফাংশনে hue-পরিসর দেওয়া আছে — সবুজ/টিল/সাদা = বুলিশ, লাল/ম্যাজেন্টা = বিয়ারিশ। আপনার অ্যাপের ঠিক রঙ জানতে চাইলে কমেন্ট করা স্যাম্পলার-লগ চালু করে দেখে নিজের hue রেঞ্জ বসিয়ে নিতে পারবেন — একটি লাইনের পরিবর্তন।",
  },
  {
    q: "এটা কি বৈধ? ব্রোকারের সার্ভারে কিছু করে?",
    a: "সম্পূর্ণ বৈধ ও নিরাপদ। অ্যাপটি শুধুমাত্র আপনার নিজের ফোনের স্ক্রিনের ছবি (আপনার স্বীকৃতিতে MediaProjection দিয়ে) দেখে গাণিতিক বিশ্লেষণ করে। কোনো ব্রোকার অ্যাপের ভেতরের ডেটা, API, মেমরি বা নেটওয়ার্কে হস্তক্ষেপ করে না, কোনো কিছু হ্যাক/বাইপাস করে না, স্বয়ংক্রিয় ট্রেডও নেয় না।",
  },
];
