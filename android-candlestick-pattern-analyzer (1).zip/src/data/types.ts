export type Lang = "kotlin" | "xml" | "groovy" | "text";

export interface FileDoc {
  id: string;
  file: string;
  path: string;
  lang: Lang;
  group: string;
  desc: string;
  place: string;
  code: string;
}

export interface GroupMeta {
  id: string;
  title: string;
  icon: string;
}
