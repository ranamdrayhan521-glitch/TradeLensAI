export interface MiniCandle {
  o: number;
  h: number;
  l: number;
  c: number;
  ctx?: boolean;
}

export interface LibraryPattern {
  id: string;
  name: string;
  nameBn: string;
  bias: "bullish" | "bearish" | "neutral";
  count: number;
  desc: string;
  candles: MiniCandle[];
}

const downCtx: MiniCandle[] = [
  { o: 16, h: 16.4, l: 13.8, c: 14, ctx: true },
  { o: 14, h: 14.5, l: 11.6, c: 12, ctx: true },
  { o: 12, h: 12.3, l: 9.4, c: 10, ctx: true },
];
const upCtx: MiniCandle[] = [
  { o: 4, h: 6.4, l: 3.7, c: 6, ctx: true },
  { o: 6, h: 8.6, l: 5.7, c: 8, ctx: true },
  { o: 8, h: 10.6, l: 7.7, c: 10, ctx: true },
];
const flatCtx: MiniCandle[] = [
  { o: 8, h: 8.9, l: 7.1, c: 8.4, ctx: true },
  { o: 8.4, h: 9.2, l: 7.6, c: 7.9, ctx: true },
  { o: 7.9, h: 8.6, l: 7.2, c: 8.1, ctx: true },
];

export const libraryPatterns: LibraryPattern[] = [
  /* ── একক ── */
  { id: "doji", name: "Doji", nameBn: "দোজি", bias: "neutral", count: 1, desc: "ওপেন-ক্লোজ প্রায় সমান — বাজারের পূর্ণ দ্বিধা।", candles: [...flatCtx, { o: 10, h: 12.4, l: 7.6, c: 10.15 }] },
  { id: "long-doji", name: "Long-Legged Doji", nameBn: "লং-লেগড দোজি", bias: "neutral", count: 1, desc: "দুই দিকেই লম্বা উইক — চরম সিদ্ধান্তহীনতা।", candles: [...flatCtx, { o: 10, h: 14.6, l: 5.4, c: 10.1 }] },
  { id: "dragonfly", name: "Dragonfly Doji", nameBn: "ড্রাগনফ্লাই দোজি", bias: "bullish", count: 1, desc: "লম্বা নিচের উইক, শূন্য উপরের উইক — বিক্রি প্রত্যাখ্যাত।", candles: [...downCtx, { o: 10, h: 10.25, l: 4.4, c: 10.05 }] },
  { id: "gravestone", name: "Gravestone Doji", nameBn: "গ্রেভস্টোন দোজি", bias: "bearish", count: 1, desc: "লম্বা উপরের উইক — কেনা প্রত্যাখ্যাত।", candles: [...upCtx, { o: 10, h: 15.6, l: 9.8, c: 10.02 }] },
  { id: "hammer", name: "Hammer", nameBn: "হাতুড়ে", bias: "bullish", count: 1, desc: "ডাউনট্রেন্ডে ছোট বডি + ২× নিচের উইক।", candles: [...downCtx, { o: 9.6, h: 10.1, l: 3.6, c: 9.9 }] },
  { id: "inv-hammer", name: "Inverted Hammer", nameBn: "ইনভার্টেড হাতুড়ে", bias: "bullish", count: 1, desc: "ডাউনট্রেন্ডে উপরের লম্বা উইক — প্রথম প্রতিরোধ।", candles: [...downCtx, { o: 6.2, h: 12.6, l: 6.0, c: 6.8 }] },
  { id: "hanging", name: "Hanging Man", nameBn: "হ্যাংগিং ম্যান", bias: "bearish", count: 1, desc: "আপট্রেন্ডে হাতুড়ে-আকৃতি — বিপদ-সংকেত।", candles: [...upCtx, { o: 10.4, h: 10.9, l: 4.6, c: 10.1 }] },
  { id: "shooting", name: "Shooting Star", nameBn: "শুটিং স্টার", bias: "bearish", count: 1, desc: "আপট্রেন্ডে উপরের লম্বা উইক — উর্ধ্ব প্রত্যাখ্যান।", candles: [...upCtx, { o: 10.6, h: 16.8, l: 10.4, c: 9.9 }] },
  { id: "maru-b", name: "Bullish Marubozu", nameBn: "বুলিশ মারুবোজু", bias: "bullish", count: 1, desc: "উইকহীন পূর্ণ সবুজ বডি — পূর্ণ দখল।", candles: [...flatCtx, { o: 6, h: 13.1, l: 5.95, c: 13 }] },
  { id: "maru-s", name: "Bearish Marubozu", nameBn: "বিয়ারিশ মারুবোজু", bias: "bearish", count: 1, desc: "উইকহীন পূর্ণ লাল বডি।", candles: [...flatCtx, { o: 14, h: 14.05, l: 6.9, c: 7 }] },
  { id: "spintop", name: "Spinning Top", nameBn: "স্পিনিং টপ", bias: "neutral", count: 1, desc: "ছোট বডি দুই পাশে উইক — সমান লড়াই।", candles: [...flatCtx, { o: 9.2, h: 12.6, l: 7.4, c: 10 }] },
  { id: "belt-b", name: "Bullish Belt Hold", nameBn: "বুলিশ বেল্ট হোল্ড", bias: "bullish", count: 1, desc: "লো-এ খুলে টানা উপরে।", candles: [...downCtx, { o: 6, h: 11.6, l: 5.98, c: 11.2 }] },
  { id: "belt-s", name: "Bearish Belt Hold", nameBn: "বিয়ারিশ বেল্ট হোল্ড", bias: "bearish", count: 1, desc: "হাই-এ খুলে টানা নিচে।", candles: [...upCtx, { o: 14, h: 14.02, l: 8.6, c: 9 }] },

  /* ── দ্বৈত ── */
  { id: "eng-b", name: "Bullish Engulfing", nameBn: "বুলিশ এনগালফিং", bias: "bullish", count: 2, desc: "সবুজ বডি লাল বডিকে পুরো গিলেছে।", candles: [...downCtx, { o: 9, h: 9.6, l: 7.4, c: 7.8 }, { o: 7.5, h: 11.4, l: 7.2, c: 11.1 }] },
  { id: "eng-s", name: "Bearish Engulfing", nameBn: "বিয়ারিশ এনগালফিং", bias: "bearish", count: 2, desc: "লাল বডি সবুজ বডিকে পুরো গিলেছে।", candles: [...upCtx, { o: 9.4, h: 11.2, l: 9.1, c: 11 }, { o: 11.3, h: 11.6, l: 7.6, c: 7.9 }] },
  { id: "har-b", name: "Bullish Harami", nameBn: "বুলিশ হারামি", bias: "bullish", count: 2, desc: "লম্বা লালের ভিতরে ছোট ক্যান্ডেল।", candles: [...downCtx, { o: 10, h: 10.4, l: 5.4, c: 5.7 }, { o: 6.4, h: 8.2, l: 6.1, c: 8 }] },
  { id: "har-s", name: "Bearish Harami", nameBn: "বিয়ারিশ হারামি", bias: "bearish", count: 2, desc: "লম্বা সবুজের ভিতরে ছোট ক্যান্ডেল।", candles: [...upCtx, { o: 6, h: 11.2, l: 5.7, c: 11 }, { o: 10.6, h: 10.9, l: 9, c: 9.2 }] },
  { id: "harx-b", name: "Bullish Harami Cross", nameBn: "বুলিশ হারামি ক্রস", bias: "bullish", count: 2, desc: "হারামি + দোজি — বিক্রির টলোমলানি।", candles: [...downCtx, { o: 10, h: 10.4, l: 5.4, c: 5.7 }, { o: 7.2, h: 8.6, l: 5.9, c: 7.25 }] },
  { id: "harx-s", name: "Bearish Harami Cross", nameBn: "বিয়ারিশ হারামি ক্রস", bias: "bearish", count: 2, desc: "হারামি + দোজি — কেনার অনিশ্চয়তা।", candles: [...upCtx, { o: 6, h: 11.2, l: 5.7, c: 11 }, { o: 9.8, h: 11, l: 8.4, c: 9.85 }] },
  { id: "pierce", name: "Piercing Line", nameBn: "পিয়ার্সিং লাইন", bias: "bullish", count: 2, desc: "লাল বডির অর্ধেকের উপরে ক্লোজ।", candles: [...downCtx, { o: 10, h: 10.3, l: 6, c: 6.4 }, { o: 5.9, h: 9.1, l: 5.5, c: 8.9 }] },
  { id: "darkcloud", name: "Dark Cloud Cover", nameBn: "ডার্ক ক্লাউড কভার", bias: "bearish", count: 2, desc: "সবুজ বডির অর্ধেকের নিচে ক্লোজ।", candles: [...upCtx, { o: 7, h: 11, l: 6.7, c: 10.7 }, { o: 11.1, h: 11.4, l: 7.9, c: 8.2 }] },
  { id: "tweez-b", name: "Tweezer Bottom", nameBn: "টুইজার বটম", bias: "bullish", count: 2, desc: "দুবার একই লো প্রত্যাখ্যাত।", candles: [...downCtx, { o: 9, h: 9.3, l: 6, c: 6.4 }, { o: 6.5, h: 9.4, l: 6.05, c: 9.2 }] },
  { id: "tweez-t", name: "Tweezer Top", nameBn: "টুইজার টপ", bias: "bearish", count: 2, desc: "দুবার একই হাই প্রত্যাখ্যাত।", candles: [...upCtx, { o: 8, h: 12, l: 7.7, c: 11.7 }, { o: 11.6, h: 12.02, l: 8.6, c: 9 }] },
  { id: "match", name: "Matching Low", nameBn: "ম্যাচিং লো", bias: "bullish", count: 2, desc: "দুই লালের ক্লোজ সমান — সাপোর্ট।", candles: [...downCtx, { o: 9.4, h: 9.7, l: 6.5, c: 6.8 }, { o: 7.6, h: 8, l: 6.35, c: 6.82 }] },
  { id: "kick-b", name: "Kicking Bullish", nameBn: "কিকিং বুলিশ", bias: "bullish", count: 2, desc: "মারুবোজু→গ্যাপ-আপ মারুবোজু।", candles: [...flatCtx, { o: 9, h: 9.05, l: 6.95, c: 7 }, { o: 8.6, h: 12.1, l: 8.58, c: 12 }] },
  { id: "kick-s", name: "Kicking Bearish", nameBn: "কিকিং বিয়ারিশ", bias: "bearish", count: 2, desc: "মারুবোজু→গ্যাপ-ডাউন মারুবোজু।", candles: [...flatCtx, { o: 7, h: 9.05, l: 6.95, c: 9 }, { o: 7.4, h: 7.42, l: 4, c: 4.1 }] },

  /* ── ত্রৈ ── */
  { id: "morning", name: "Morning Star", nameBn: "মর্নিং স্টার", bias: "bullish", count: 3, desc: "লাল→তারা→সবুজ: ক্লাসিক উলটো।", candles: [...downCtx, { o: 9.4, h: 9.6, l: 5.8, c: 6.1 }, { o: 5.6, h: 6.3, l: 5.2, c: 5.9 }, { o: 6.4, h: 10.4, l: 6.2, c: 10.2 }] },
  { id: "evening", name: "Evening Star", nameBn: "ইভিনিং স্টার", bias: "bearish", count: 3, desc: "সবুজ→তারা→লাল: ক্লাসিক উলটো।", candles: [...upCtx, { o: 7, h: 10.8, l: 6.7, c: 10.6 }, { o: 11, h: 11.4, l: 10.5, c: 11.1 }, { o: 10.4, h: 10.6, l: 6.4, c: 6.7 }] },
  { id: "morning-d", name: "Morning Doji Star", nameBn: "মর্নিং দোজি স্টার", bias: "bullish", count: 3, desc: "তারাটি দোজি — আরও শক্তিশালী।", candles: [...downCtx, { o: 9.4, h: 9.6, l: 5.8, c: 6.1 }, { o: 5.7, h: 6.5, l: 5, c: 5.75 }, { o: 6.5, h: 10.8, l: 6.3, c: 10.5 }] },
  { id: "evening-d", name: "Evening Doji Star", nameBn: "ইভিনিং দোজি স্টার", bias: "bearish", count: 3, desc: "তারাটি দোজি — আরও শক্তিশালী।", candles: [...upCtx, { o: 7, h: 10.8, l: 6.7, c: 10.6 }, { o: 11.1, h: 11.9, l: 10.6, c: 11.15 }, { o: 10.3, h: 10.5, l: 6.2, c: 6.5 }] },
  { id: "baby-b", name: "Abandoned Baby (Bull)", nameBn: "অ্যাবান্ডন্ড বেবি", bias: "bullish", count: 3, desc: "বিচ্ছিন্ন দোজি — পর্যাপ্ত শক্তিশালী উলটো।", candles: [...downCtx, { o: 9.4, h: 9.6, l: 6.4, c: 6.7 }, { o: 5.5, h: 6.1, l: 4.9, c: 5.55 }, { o: 6.9, h: 11, l: 6.6, c: 10.7 }] },
  { id: "tristar", name: "Tri-Star Bottom", nameBn: "ট্রাই-স্টার বটম", bias: "bullish", count: 3, desc: "পরপর তিন দোজি — বিক্রির শেষ।", candles: [...downCtx, { o: 8.6, h: 9.9, l: 7.4, c: 8.65 }, { o: 7.8, h: 8.9, l: 6.6, c: 7.85 }, { o: 8.4, h: 9.4, l: 7.2, c: 8.45 }] },
  { id: "soldiers", name: "Three White Soldiers", nameBn: "থ্রি হোয়াইট সোলজার্স", bias: "bullish", count: 3, desc: "পরপর তিন শক্ত সবুজ — অবিরাম চাপ।", candles: [...flatCtx, { o: 6, h: 8.6, l: 5.7, c: 8.4 }, { o: 8, h: 10.8, l: 7.8, c: 10.6 }, { o: 10.1, h: 12.9, l: 9.9, c: 12.7 }] },
  { id: "crows", name: "Three Black Crows", nameBn: "থ্রি ব্ল্যাক ক্রো", bias: "bearish", count: 3, desc: "পরপর তিন শক্ত লাল — বিক্রি-ঢল।", candles: [...flatCtx, { o: 12.6, h: 12.8, l: 10.1, c: 10.3 }, { o: 10.6, h: 10.8, l: 8.1, c: 8.3 }, { o: 8.5, h: 8.7, l: 6.1, c: 6.3 }] },
  { id: "t-in-up", name: "Three Inside Up", nameBn: "থ্রি ইনসাইড আপ", bias: "bullish", count: 3, desc: "হারামি + ভাঙন নিশ্চিতকরণ।", candles: [...downCtx, { o: 10, h: 10.3, l: 5.6, c: 5.9 }, { o: 6.5, h: 8.4, l: 6.2, c: 8.2 }, { o: 8.6, h: 11, l: 8.3, c: 10.8 }] },
  { id: "t-in-dn", name: "Three Inside Down", nameBn: "থ্রি ইনসাইড ডাউন", bias: "bearish", count: 3, desc: "বিয়ারিশ হারামির নিশ্চিতকরণ।", candles: [...upCtx, { o: 6, h: 10.6, l: 5.7, c: 10.4 }, { o: 9.8, h: 10, l: 7.8, c: 8 }, { o: 7.6, h: 7.9, l: 5, c: 5.3 }] },
  { id: "t-out-up", name: "Three Outside Up", nameBn: "থ্রি আউটসাইড আপ", bias: "bullish", count: 3, desc: "এনগালফিং + নিশ্চিতকরণ।", candles: [...downCtx, { o: 8, h: 8.4, l: 6.6, c: 6.9 }, { o: 6.6, h: 9.4, l: 6.3, c: 9.2 }, { o: 9.5, h: 11.4, l: 9.2, c: 11.2 }] },
  { id: "t-out-dn", name: "Three Outside Down", nameBn: "থ্রি আউটসাইড ডাউন", bias: "bearish", count: 3, desc: "বিয়ারিশ এনগালফিং + নিশ্চিতকরণ।", candles: [...upCtx, { o: 8, h: 10, l: 7.7, c: 9.8 }, { o: 10.1, h: 10.4, l: 6.9, c: 7.2 }, { o: 6.9, h: 7.2, l: 4.9, c: 5.1 }] },
  { id: "sandwich", name: "Stick Sandwich", nameBn: "স্টিক স্যান্ডউইচ", bias: "bullish", count: 3, desc: "সমান ক্লোজে দুই লাল — সাপোর্ট।", candles: [...downCtx, { o: 9.4, h: 9.6, l: 6.8, c: 7 }, { o: 7.5, h: 10, l: 7.2, c: 9.8 }, { o: 9, h: 9.2, l: 6.9, c: 7.05 }] },

  /* ── পাঁচ-ক্যান্ডেল ── */
  { id: "rising3", name: "Rising Three Methods", nameBn: "রাইজিং থ্রি মেথডস", bias: "bullish", count: 5, desc: "আপট্রেন্ড ধারাবাহিক — ছোট বিরতির পর ভাঙন।", candles: [...upCtx, { o: 8, h: 13, l: 7.8, c: 12.8 }, { o: 12.2, h: 12.6, l: 10.9, c: 11.2 }, { o: 11.4, h: 11.8, l: 10.2, c: 10.6 }, { o: 10.8, h: 11.2, l: 9.6, c: 10 }, { o: 10.4, h: 14.2, l: 10.2, c: 14 }] },
  { id: "falling3", name: "Falling Three Methods", nameBn: "ফলিং থ্রি মেথডস", bias: "bearish", count: 5, desc: "ডাউনট্রেন্ড ধারাবাহিক।", candles: [...downCtx, { o: 13, h: 13.2, l: 8, c: 8.2 }, { o: 8.8, h: 10, l: 8.5, c: 9.7 }, { o: 9.5, h: 10.6, l: 9.1, c: 10.3 }, { o: 10, h: 11, l: 9.6, c: 10.8 }, { o: 10.5, h: 10.7, l: 6.6, c: 6.8 }] },
];

export const tickerNames = libraryPatterns.map((p) => p.nameBn);
