import type { Lang } from "../data/types";

export type TokType =
  | "kw"
  | "str"
  | "com"
  | "num"
  | "type"
  | "fn"
  | "ann"
  | "tag"
  | "attr"
  | "op"
  | "plain";

export interface Tok {
  t: TokType;
  s: string;
}

const KOTLIN_KW =
  "\\b(?:package|import|class|object|interface|fun|val|var|if|else|when|for|while|do|return|try|catch|finally|companion|data|enum|sealed|private|public|protected|internal|override|open|abstract|lateinit|vararg|init|get|set|const|by|lazy|this|super|true|false|null|is|in|as|throw|out|infix|operator|suspend|inner|constructor|apply|also|let|run|with|it)\\b";

const GROOVY_KW =
  "\\b(?:plugins|id|version|apply|implementation|api|android|defaultConfig|buildTypes|compileOptions|kotlinOptions|dependencies|true|false|include|pluginManagement|dependencyResolutionManagement|repositoriesMode|repositories|google|mavenCentral|gradlePluginPortal|project|rootProject|namespace|compileSdk|minSdk|targetSdk|applicationId|versionCode|versionName|minifyEnabled|proguardFiles|sourceCompatibility|targetCompatibility|jvmTarget|getDefaultProguardFile|buildFeatures|viewBinding|set|release|debug)\\b";

const SHARED =
  "(\\/\\*[\\s\\S]*?\\*\\/)|(\\/\\/[^\\n]*)|(\"(?:[^\"\\\\\\n]|\\\\.)*\")|(@[A-Za-z_][\\w]*)|(\\b0x[0-9A-Fa-f]+\\b|\\b\\d+(?:\\.\\d+)?[fLd]?\\b)";

function makeCodeRe(kw: string): RegExp {
  return new RegExp(
    SHARED +
      "|(" + kw + ")|(\\b[A-Z_][A-Za-z0-9_]*\\b)|([a-zA-Z_][\\w]*)(?=\\s*\\()",
    "g"
  );
}

const RE_KOTLIN = makeCodeRe(KOTLIN_KW);
const RE_GROOVY = makeCodeRe(GROOVY_KW);

const RE_XML = new RegExp(
  "(\\<\\!--[\\s\\S]*?--\\>)|(\"[^\"\\n]*\")|(\\<\\/?[A-Za-z0-9_:\\.\\-]+|\\/\\?\\>|\\?\\>|\\>)|([A-Za-z0-9_:\\.\\-]+)(?=\\s*\\=)",
  "g"
);

function scan(re: RegExp, code: string, map: (m: RegExpExecArray) => Tok): Tok[] {
  const out: Tok[] = [];
  let last = 0;
  re.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(code)) !== null) {
    if (m.index > last) out.push({ t: "plain", s: code.slice(last, m.index) });
    out.push(map(m));
    last = m.index + m[0].length;
    if (m[0].length === 0) re.lastIndex++;
  }
  if (last < code.length) out.push({ t: "plain", s: code.slice(last) });
  return out;
}

export function tokenize(code: string, lang: Lang): Tok[] {
  if (lang === "text") return [{ t: "plain", s: code }];
  if (lang === "xml") {
    return scan(RE_XML, code, (m) => ({
      t: m[1] ? "com" : m[2] ? "str" : m[3] ? "tag" : "attr",
      s: m[0],
    }));
  }
  const re = lang === "groovy" ? RE_GROOVY : RE_KOTLIN;
  return scan(re, code, (m) => {
    const t: TokType = m[1]
      ? "com"
      : m[2]
        ? "com"
        : m[3]
          ? "str"
          : m[4]
            ? "ann"
            : m[5]
              ? "num"
              : m[6]
                ? "kw"
                : m[7]
                  ? "type"
                  : "fn";
    return { t, s: m[0] };
  });
}

/** টোকেন-স্ট্রিমকে লাইন অ্যারেতে ভাঙে (রেন্ডারের সুবিধার জন্য) */
export function toLines(toks: Tok[]): Tok[][] {
  const lines: Tok[][] = [[]];
  for (const tok of toks) {
    const parts = tok.s.split("\n");
    parts.forEach((p, i) => {
      if (i > 0) lines.push([]);
      if (p.length > 0) lines[lines.length - 1].push({ t: tok.t, s: p });
    });
  }
  return lines;
}

export function toBn(n: number | string): string {
  const d = "০১২৩৪৫৬৭৮৯";
  return String(n).replace(/[0-9]/g, (c) => d[Number(c)]);
}
